#BISMILLAH NGERUN BOT#
from linepy import *
from BEAPI import BEAPI
from justgood import imjustgood
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import ChatRoomAnnouncementContents
from akad.ttypes import ChatRoomAnnouncement
from thrift import transport, protocol, server
from datetime import datetime, timedelta
import pytz, pafy, livejson, time, asyncio, random, multiprocessing, timeit, sys, json, ctypes, tweepy, codecs, threading, glob, re, ast, six, os, subprocess, wikipedia, atexit, goslate, urllib, urllib.parse, urllib3, string, tempfile, shutil, unicodedata
from humanfriendly import format_timespan, format_size, format_number, format_length
import html5lib
import requests,json,urllib3
from random import randint
from bs4 import BeautifulSoup
from gtts import gTTS
from googletrans import Translator
import youtube_dl
from time import sleep
import pyimgflip
from zalgo_text import zalgo
from threading import Thread,Event
import requests,uvloop
import wikipedia as wiki
import subprocess as cmd
requests.packages.urllib3.disable_warnings()
loop = uvloop.new_event_loop()
from Naked.toolshed.shell import execute_js 
from threading import Thread

cl = LINE("misbahwates@gmail.com","bagas123",appName ="DESKTOPWIN\t5.20.2\tWindows\t10")
cl.log("Auth Token : " + str(cl.authToken))

k1 = LINE("wahyunibella36@gmail.com","bagas123")
k1.log("Auth Token : " + str(k1.authToken))

sw = LINE("moybella20@gmail.com","bagas123")
sw.log("Auth Token : " + str(sw.authToken))
print ("•===> sᴜᴄᴄᴇs ʟᴏɢɪɴ 2ᴀᴊs...")
print ("•=====> ʙᴏᴛ ʀᴜɴɴ...")

oepoll = OEPoll(cl)
call = cl
creator = ["ub36cd37c4a625d36b64db845bddbd79d","uc6a9419232bf540bbca6ab4174c9f660"]
owner = ["ub36cd37c4a625d36b64db845bddbd79d","uc6a9419232bf540bbca6ab4174c9f660"]
admin = ["ub36cd37c4a625d36b64db845bddbd79d","uc6a9419232bf540bbca6ab4174c9f660"]
staff = ["ub36cd37c4a625d36b64db845bddbd79d","uc6a9419232bf540bbca6ab4174c9f660"]
Tumbal = ["ub36cd37c4a625d36b64db845bddbd79d","uc6a9419232bf540bbca6ab4174c9f660"]

lineProfile = cl.getProfile()
lineProfile = k1.getProfile()
lineProfile = sw.getProfile()
mid = cl.getProfile().mid
Amid = k1.getProfile().mid
Zmid = sw.getProfile().mid
KAC = [cl,k1,sw]
Bots = [mid,Amid,Zmid]
Saints = admin + owner + staff
Team = creator + owner + admin + staff + Bots
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)
Setbot4 = codecs.open("user.json","r","utf-8")
premium = json.load(Setbot4)

protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
welcome = []
targets = []
protectname = []
prohibitedWords = ['Asu', 'Jancuk', 'Tai', 'Kickall', 'Ratakan', 'Cleanse']
userTemp = {}
userKicked = []
msg_dict = {}
msg_dict1 = {}
dt_to_str = {}
temp_flood = {}
groupName = {}
groupImage = {}
list = []
ban_list = []
offbot = []

settings = {
    "welcome": False,
    "leave": False,
    "mid": False,
    "Aip": True,
    "keyCommand": "dent",
    "commentPost": "ʜᴀᴅɪʀ ʟɪᴋᴇ ᴄᴏᴍᴇɴᴛ ɢᴇss \nby: ɑժѵҽղԵꪊƦꫀ 😂",
    "replySticker": False,
    "jumbostickerOn": False,
    "stickerOn": False,
    "sharesmule": False,
    "nCall": False,
    "checkContact": False,
    "postEndUrl": {},
    "postingan":{},
    "checkPost": False,
    "autoRead": False,
    "autoJoinTicket": False,
    "setKey": False,    
    "restartPoint": False,
    "checkSticker": False,
    "userMentioned": False,
    "messageSticker": False,
    "changeGroupPicture": [],
    "keyCommand": "",
    "AddstickerTag": {
        "sid": "",
        "spkg": "",
        "status": False
            },
    "Addsticker":{
            "name": "",
            "status":False
            },
    "stk":{},
    "selfbot":True,
    "Images":{},
    "Img":{},
    "Addimage":{
            "name": "",
            "status":False
            },
    "Videos":{},
    "Addaudio":{
            "name": "",
            "status":False
            },
    "Addvideo":{
            "name": "",
            "status":False
            },
    "myProfile": {
        "displayName": "",
        "coverId": "",
        "pictureStatus": "",
        "statusMessage": ""
    },
    "mimic": {
        "copy": False,
        "status": False,
        "target": {}
    }, 
    "unsendMessage": False,
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changevp": False,
    "changeCover":False,
    "changePicture":False,
    "changeProfileVideo": False,
    "ChangeVideoProfilevid":{},
    "ChangeVideoProfilePicture":{},
    "displayName": "",
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.200.32.99 Safari/537.36"
    ]
}

wait = {
    "limit": 1,
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "checkmid": False,
    "getMid": False,
    "invite":False,
    "Invi":False,
    "staff":{},
    "voom": False,
    "likePost": True,
    "welcomeOn": False,
    "leaveMsg": False,
    "likeOn": True,
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "readPoint":{},
    "readMember":{},
    "lang":False,
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":True,
    "tumbal":True,
    "key":True,
    "facebook":True,
    "jumbosticker":False,
    "spamcall": True,
    "Busy": False,
    "tiktok":False,
    "ytube":True,
    "sharesmule": True,
    "notifsmule":False,
    "smule":False,
    "nCall":False,
    "backup":True,
    "contact":False,
    "autoRead": False,
    "autoBlock": False,
    "autoJoin":True,
    "autoAdd":True,
    'autoCancel':{"on":True, "members":1},
    "autoReject":False,
    "autoLeave":False,
    "cctv":False,
    "cctm":False,
    "detectMention":False,
    "detectMention2":False,
    "detectMention3": False,
    "detectMention4": False,
    "detectMention5": False,
    "detectMention6": False,
    "detectMention7": False,
    "detectMention8": False,
    "detectMention9": False,
    "Mentionkick":False,
    "welcomeOn":False,
    "Unsend":False,
    "sticker":False,
    "smule":False,
    "selfbot":True,
    "selfbot2":True,
    "animated": True,
    "dell":"cok",
    "flexghost":" ᴀssᴀʟᴀᴍᴜᴀʟᴀɪᴋᴜᴍ",
    "JANJUK":"kowe",
    "NGENTOT":"memek",
    "mention":"ɴɢɪɴᴛɪᴘ ᴀᴊᴀ ᴛᴇʀᴜs",
    "mention2":" ᴍᴀsᴜᴋ ᴋᴀᴋ",
    "Respontag":"  ʜᴇʟᴏ ʙʀᴏᴏ",
    "Respontag2":" ᴀᴅᴀ ʏᴀɴɢ ʙɪsᴀ ᴅɪʙᴀɴᴛᴜ",
    "welcome":"Met Gabung,Salam kompak selalu Ea broo",
    "autoLeave":" ᴍᴇᴛ ᴊᴀʟᴀɴ sᴏʙᴀᴛᴋᴜ ",
    "comment":"salam kenal ea guys\ndari Aku Yg jadi temanMu\n\nhttp://wa.me/+6285707063716",
    "message1":"makasih udah Add aku Lurr...",
}
protect = {
    "pqr":[],
    "pinv":[],
    "proall":[],
    "antijs":[],
    "protect":[]
}

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctm = {
    "cyduk1":{},
    "point1":{},
    "sidermem1":{}
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

myProfile = {
	"displayName": "",
	"statusMessage": "",
	"pictureStatus": ""
}
try:
    with open("Log_data.json","r",encoding="utf_8_sig") as f:
        msg_dict = json.loads(f.read())
except:
    print("Couldn't read Log data")
    
clProfile = cl.getProfile()
myProfile["displayName"] = clProfile.displayName
myProfile["statusMessage"] = clProfile.statusMessage
myProfile["pictureStatus"] = clProfile.pictureStatus

contact = cl.getProfile()
backup = cl.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus


imagesOpen = codecs.open("image.json","r","utf-8")
images = json.load(imagesOpen)
videosOpen = codecs.open("video.json","r","utf-8")
videos = json.load(videosOpen)
stickersOpen = codecs.open("sticker.json","r","utf-8")
stickers = json.load(stickersOpen)
audiosOpen = codecs.open("audio.json","r","utf-8")
audios = json.load(audiosOpen)
mulai = time.time()

msg_dict = {}
msg_dict1 = {}

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
           
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))

def NoteCreate(to,cmd,msg):
    h = []
    s = []
    if cmd == 'note':
        sakui = cl.getProfile()
        group = cl.getGroup(msg.to);nama = [contact.mid+'||//{}'.format(contact.displayName) for contact in group.members];nama.remove(sakui.mid+'||//{}'.format(sakui.displayName))
        data = nama
        k = len(data)//500
        for aa in range(k+1):
            nos = 0
            if aa == 0:dd = '╭「 ᴀʙsᴇɴsɪ ᴍᴇᴍʙᴇʀ ɢʀᴜᴘ 」─';no=aa
            else:dd = '';no=aa*500
            msgas = dd
            for i in data[aa*500 : (aa+1)*500]:
                no+=1
                if no == len(data):msgas+='\n├{}. @\n╰─「 Adventure™ 」─'.format(no)
                else:msgas+='\n├{}. @'.format(no)
            msgas = msgas
            for i in data[aa*500 : (aa+1)*500]:
                gg = []
                dd = ''
                for ss in msgas:
                    if ss == '@':
                        dd += str(ss)
                        gg.append(dd.index('@'))
                        dd = dd.replace('@',' ')
                    else:
                        dd += str(ss)
                s.append({'type': "RECALL", 'start': gg[nos], 'end': gg[nos]+1, 'mid': str(i.split('||//')[0])})
                nos +=1
            h = cl.createPostGroup(msgas,msg.to,holdingTime=None,textMeta=s)
    else:
        cmd = cmd.replace(msg.text[:12],'')
        if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mentionees = mention['MENTIONEES']
            no = 0
            for mention in mentionees:
                ask = no
                nama = str(ais.getContact(mention["M"]))
                h.append(str(cmd.replace('@{}'.format(nama),'@')))
                for b in h:
                    cmd = str(b)
                gg = []
                dd = ''
                for ss in cmd:
                    if ss == '@':
                        dd += str(ss)
                        gg.append(dd.index('@'))
                        dd = dd.replace('@',' ')
                    else:
                        dd += str(ss)
                s.append({'type': "RECALL", 'start': gg[no], 'end': gg[no]+1, 'mid': str(mention["M"])})
                no +=1
        h = cl.createPostGroup(cmd,msg.to,holdingTime=None,textMeta=s)
        
def autolike():
    for zx in range(0,500):
      hasil = cl.activity(limit=500)
      if hasil['result']['posts'][zx]['postInfo']['liked'] == True:
        try:
          cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          cl.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postid'],wait["comment"])
          print ("✪[]► Like Success")
        except:
          pass
      else:
          print ("Already Liked")
          
def delExpire():
    if temp_flood != {}:
        for tmp in temp_flood:
            if temp_flood[tmp]["expire"] == True:
                if time.time() - temp_flood[tmp]["time"] >= 3*10:
                    temp_flood[tmp]["expire"] = False
                    temp_flood[tmp]["time"] = time.time()
                    try:
                        sendTextTemplate901(tmp, "Bot is active again🤗")
                    except Exception as error:
                        logError(error)          
    
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

#delete log if pass more than 24 hours
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]
        
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > timedelta(1):
            if "path" in msg_dict[data]:
                cl.deleteFile(msg_dict[data]["path"])
            del msg_dict[data]

def logError(text):
    cl.log("[ ERROR ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("logError.txt","a") as error:
        error.write("\n[ {} ] {}".format(str(time), text))

def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        import urllib,request
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

from BEAPI import *

def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.1)        
            page = page[end_content:]
    return items

def downloadImageWithURL (mid):
    contact = cl.getContact(mid)
    if contact.videoProfile == None:
        cl.cloneContactProfile(mid)
    else:
        profile = cl.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = cl.getProfileDetail(mid)['result']['objectId']
    cl.updateProfileCoverById(coverId)
    
def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
    
def sendImage(to, path, name="image"):
    try:
        if settings["server"] == "VPS":
            cl.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)
#remot tagall
def RemotOlengKiller(to, BotsOleng):
    try:
        AbiOleng = ""
        MuhazirOlengKiller = "Total {} Janda \n1.".format(str(len(BotsOleng)))
        Desah = []
        TapokPipit = 1
        JilatMpek = 2
        for Sedot in BotsOleng:
            MuhazirOleng = "@x\n"
            Wikwik = str(len(MuhazirOlengKiller))
            Ngentot = str(len(MuhazirOlengKiller) + len(MuhazirOleng) - 1)
            AbiOleng = {'S':Wikwik, 'E':Ngentot, 'M':Sedot}
            Desah.append(AbiOleng)
            MuhazirOlengKiller += MuhazirOleng
            if TapokPipit < len(BotsOleng):
                TapokPipit += 1
                MuhazirOlengKiller += "%i. " % (JilatMpek)
                JilatMpek=(JilatMpek+1)
            else:
                try:
                    TapokPipit = "\n[ {} ]".format(str(AbiOlengKiller.getGroup(to).name))
                except:
                    TapokPipit = "\n[ Success ]"
        cl.sendMessage(to, MuhazirOlengKiller, {'MENTION': str('{"MENTIONEES":' + json.dumps(Desah) + '}')}, 0)
    except Exception as error:
        logError(error)

def changeProfileVideo(to):
    if settings['changevp']['picture'] == True:
        return cl.sendMessage(to, "Foto tidak ditemukan")
    elif settings['changevp']['video'] == True:
        return cl.sendMessage(to, "Video tidak ditemukan")
    else:
        path = settings['changevp']['video']
        files = {'file': open(path, 'rb')}
        obs_params = cl.genOBSParams({'oid': cl.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return cl.sendMessage(to, "Gagal update profile")
        path_p = settings['changevp']['picture']
        settings['changevp']['status'] = True
        cl.updateProfilePicture(path_p, 'vp')
                     
def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = cl.genOBSParams({'oid': mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4', 'name': 'GEGE.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        cl.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile %s"%str(e))

def cloneProfile(mid):
    contact = cl.getContact(mid)
    if contact.videoProfile == None:
        cl.cloneContactProfile(mid)
    else:
        profile = cl.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = cl.getProfileDetail(mid)['result']['objectId']
    cl.updateProfileCoverById(coverId)

def restoreProfile():
    profile = cl.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settings['myProfile']['pictureStatus']
        cl.updateProfileAttribute(8, profile.pictureStatus)
        cl.updateProfile(profile)
    else:
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    cl.updateProfileCoverById(coverId)

def mentionMembers(to, mid):
    try:
        arrData = ""
        ginfo = cl.getGroup(to)
        textx = "╔═════[ Sider Members ]═══════\n║ Sini Gabung Chat ka 😊..\n╠☛ 1."
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "╠☛  {}. ".format(str(no))
            else:
                textx += "╚══════════════════\n╔══════════════════\n  「 ᴛᴏᴛᴀʟ ᴍᴇᴍʙᴇʀ : {} 」\n╚══════════════════".format(str(len(mid)))
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMentionPutra(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))    

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = (str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1 )
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
       # cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = " ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
       # cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def leaveMembers(to, mid):
    try:
        arrData = ""
        textx = "".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n┗━━[ {} ]".format(str(aditmadzs.getGroup(to).name))
                except:
                    no = "\n┗━━[ Success ]"
    #    cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error)) 

def sendMentionPutra(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))    
    
def sendMentionV2(to, text="", mids=[], name="", url="", iconlink=""):
    arrData = ""
    arr = []
    mention = "@Put "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 9
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 9
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}'),'AGENT_NAME': name,'AGENT_LINK': url,'AGENT_ICON': iconlink },0)

def sendMention(to, mid, firstmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x \n"
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        today = datetime.today()
        future = datetime(2018,3,1)
        hari = (str(future - today))
        comma = hari.find(",")
        hari = hari[:comma]
        teman = cl.getAllContactIds()
        gid = cl.getGroupIdsJoined()
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        eltime = time.time() - mulai
        bot = runtime(eltime)
        text += mention+"jam : "+datetime.strftime(timeNow,'%H:%M:%S')+" wib\nNama Group : "+str(len(gid))+"\nTeman : "+str(len(teman))+"\nExpired : In "+hari+"\n Version :「Gaje Bots」  \nTanggal : "+datetime.strftime(timeNow,'%Y-%m-%d')+"\nRuntime : \n • "+bot
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention1(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)                     
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendTemplates(to, data):
    data = data
    url = "https://api.line.me/message/v3/share"
    headers = {}
    headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 8.1.0; Redmi Note 5 Build/OPM1.171019.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/67.0.3396.87 Mobile Safari/537.36 Line/8.1.1'  
    headers['Content-Type'] = 'application/json'  
    headers['Authorization'] = 'Bearer eyJhbGciOiJIUzI1NiJ9.5uMcEEHahauPb5_MKAArvGzEP8dFOeVQeaMEUSjtlvMV9uuGpj827IGArKqVJhiGJy4vs8lkkseiNd-3lqST14THW-SlwGkIRZOrruV4genyXbiEEqZHfoztZbi5kTp9NFf2cxSxPt8YBUW1udeqKu2uRCApqJKzQFfYu3cveyk.GoRKUnfzfj7P2uAX9vYQf9WzVZi8MFcmJk8uFrLtTqU'
    sendPost = requests.post(url, data=json.dumps(data), headers=headers)
    print(sendPost)
    return sendPost


#=====DEF HELP MENU =======
def sendTextTemplate25(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "SelfbotV3",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#20B2AA" #999999"
    },
    "footer": {
      "backgroundColor": "#ff0000" #0000" #cc9999"
    }
  },
  "type": "bubble",
  "size": "nano",
      "body": {
  "contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#ff0000"            
      },
      {
        "type": "separator",
        "color": "#ff0000"      
      },
      {         
         "contents": [
          {   
          "type": "separator",
          "color": "#ff0000"
            },
           {
            "contents": [
              {
            "text": "Adventure club", #ᴘᴇʟᴀᴋᴜ:{} ".format(cl.getContact(mid).displayName),
           "size": "xxs",
           "align": "center",
           "color": "#ffff00",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ff0000"
         },
         {
       "contents": [              
         { 
           "type": "separator",
           "color": "#ff0000"
            },
           {
            "contents": [
              {
            "text": " ", #format(cl.getContact(sender).displayName),
           "size": "xs",
           "align": "center",
           "color": "#000000",
           "wrap": True,
           "weight": "bold",
           "type": "text"
           },
           {
          "text": text,
           "size": "xxs",
          # "align": "center",
           "color": "#000000",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ff0000"
         },
         {          
        "contents": [
          {
            "type": "separator",
            "color": "#ff0000"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com"
            },
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://wa.me/+6285707063716",             
           }, 
            "flex": 1            
          },
          {
        "type": "image",
            "url": "https://i.ibb.co/kSMSnWn/20190427-191235.png", #camerahttps://i.ibb.co/hVWDsp8/20190428-232907.png", #smulehttps://i.ibb.co/8YfQVtr/20190427-185626.png", #callinghttps://kepriprov.go.id/assets/img/icon/phone.png", #phone
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/camera/"
          },
            "flex": 1
            },
          {
          "type": "image",
            "url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/_BowWow",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ff0000"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)
def sendTextTemplate002(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "mengirimkan file",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/37tfY5s/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
            "flex": 1,
            "offsetTop": "-10px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/37tfY5s/ezgif-com-gif-maker-1.png",
                "size": "full",
                "aspectRatio": "2:6",
                "aspectMode": "cover",
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "400px",
            "offsetTop": "400px",
            "offsetStart": "0px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "30px",
                "offsetStart": "5px",
                "wrap": True,
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/cNNRQk4/ezgif-com-gif-maker.png",
                    "size": "md",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "-22px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/d2wWZL9/ezgif-com-gif-maker-2.png",
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover",
                      }
                    ],
                    "position": "absolute",
                    "width": "18px",
                    "height": "18px",
                    "borderWidth": "1px",
                    "borderColor": "#00ff00",
                    "cornerRadius": "2px",
                    "offsetTop": "0px",
                    "offsetStart": "1px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/d2wWZL9/ezgif-com-gif-maker-2.png",
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover",
                      }
                    ],
                    "position": "absolute",
                    "width": "18px",
                    "height": "18px",
                    "borderWidth": "1px",
                    "borderColor": "#00ff00",
                    "cornerRadius": "2px",
                    "offsetTop": "0px",
                    "offsetEnd": "1px"
                  }
                ],
                "position": "absolute",
                "width": "140px",
                "height": "20px",
                "borderWidth": "1px",
                "borderColor": "#00ff00",
                "cornerRadius": "5px",
                "offsetTop": "1px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Adventure club",
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "25px"
                  }
                ],
                "position": "absolute",
                "width": "140px",
                "height": "20px",
                "borderWidth": "1px",
                "borderColor": "#00ff00",
                "cornerRadius": "5px",
                "offsetTop": "763px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "146px",
            "height": "786px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px",
        "flex": 1,
        "spacing": "xl",
        "backgroundColor": "#000000",
        "borderWidth": "2px",
        "borderColor": "#00ff00",
        "cornerRadius": "10px",
        "height": "800px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
def sendTextTemplate003(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "mengirimkan pesan",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "mega",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:4",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/Lp62473/ezgif-com-gif-maker.png",
                "size": "full",
                "aspectRatio": "2:5",
                "aspectMode": "cover",
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Adventure club",
                    "size": "xs",
                    "color": "#ff0000",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "25px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "20px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "5px",
                "offsetTop": "565px",
                "offsetStart": "70px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xs",
                    "color": "#00ff00",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "5px",
                    "offsetStart": "5px"
                  }
                ],
                "position": "absolute",
                "width": "250px",
                "height": "560px"
              }
            ],
            "position": "absolute",
            "width": "290px",
            "height": "590px",
            "borderWidth": "2px",
            "borderColor": "#ffffff",
            "cornerRadius": "10px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px",
        "height": "600px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
def sendTextTemplate010(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "Mengirimkan surat",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/DL9SzvX/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/DL9SzvX/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "8:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/vQygHZ0/ezgif-com-gif-maker.png",
                        "size": "xl",
                        "aspectRatio": "8:2",
                        "aspectMode": "cover",
                        "offsetTop": "-8px"
                      }
                    ],
                    "position": "absolute",
                    "width": "146px",
                    "height": "18px",
                    "backgroundColor": "#b08800",
                    "borderWidth": "1px",
                    "borderColor": "#000000",
                    "cornerRadius": "5px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "22px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "1px",
                "offsetStart": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/DL9SzvX/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:3",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": text,
                        "size": "full",
                        "aspectMode": "cover",
                        "aspectRatio": "2:3"
                      }
                    ],
                    "position": "absolute",
                    "width": "58px",
                    "height": "78px",
                    "borderWidth": "1px",
                    "borderColor": "#000000",
                    "cornerRadius": "5px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "62px",
                "height": "82px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "24px",
                "offsetStart": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/DL9SzvX/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "⏰:"+ datetime.strftime(timeNow,'%H:%M:%S'),
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic"
                      }
                    ],
                    "position": "absolute",
                    "width": "82px",
                    "height": "16px",
                    "backgroundColor": "#0000ff",
                    "borderWidth": "1px",
                    "borderColor": "#000000",
                    "cornerRadius": "5px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "86px",
                "height": "20px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "24px",
                "offsetEnd": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/DL9SzvX/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "📅:"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic"
                      }
                    ],
                    "position": "absolute",
                    "width": "82px",
                    "height": "16px",
                    "backgroundColor": "#ff0000",
                    "borderWidth": "1px",
                    "borderColor": "#000000",
                    "cornerRadius": "5px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "86px",
                "height": "20px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "45px",
                "offsetEnd": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/YBLJ1Lv/ezgif-com-gif-maker-1.png",
                    "size": "xxs",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "86px",
                "height": "40px",
                "offsetTop": "65px",
                "backgroundColor": "#000000",
                "offsetEnd": "1px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/DL9SzvX/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:3",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "📀",
                        "size": "xs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic",
                        "offsetStart": "2px"
                      },
                      {
                        "type": "text",
                        "text": "📀",
                        "size": "xs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic",
                        "offsetStart": "2px",
                        "offsetTop": "5px"
                      },
                      {
                        "type": "text",
                        "text": "📀",
                        "size": "xs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic",
                        "offsetTop": "10px",
                        "offsetStart": "2px"
                      }
                    ],
                    "position": "absolute",
                    "width": "146px",
                    "height": "72px",
                    "backgroundColor": "#0cbcb0",
                    "borderWidth": "1px",
                    "borderColor": "#000000",
                    "cornerRadius": "5px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "76px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "106px",
                "offsetStart": "1px"
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "184px",
            "backgroundColor": "#bbcc00",
            "borderWidth": "1px",
            "borderColor": "#000000",
            "cornerRadius": "8px",
            "offsetTop": "2px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/qxnJVSG/ezgif-com-gif-maker-1.png",
                "size": "md",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "30px"
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "190px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/hVmT0Cq/ezgif-com-gif-maker.png",
                "size": "md",
                "aspectRatio": "6:6",
                "aspectMode": "cover",
                "offsetTop": "110px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "190px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/kccc28M/ezgif-com-gif-maker-6.png",
                "size": "xxs",
                "aspectRatio": "2:2",
                "aspectMode": "cover",
                "offsetTop": "80px",
                "offsetStart": "-5px"
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "190px"
          }
        ],
        "paddingAll": "0px",
        "height": "190px",
        "borderWidth": "1px",
        "borderColor": "#000000",
        "cornerRadius": "10px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
def sendTextTemplate011(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "Mengirimkan File",
                                       "contents":
{
  "type": "bubble",
  "size": "micro",
  "hero": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "animated": True,
        "url": "https://i.ibb.co/0BhBrKQ/ezgif-com-gif-maker.png",
        "size": "full",
        "aspectRatio": "2:3",
        "aspectMode": "cover",
        "gravity": "top"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/FxpT0x8/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectRatio": "2:2",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/VmJTWvb/ezgif-com-gif-maker-2.png",
                "size": "lg",
                "aspectRatio": "8:1",
                "aspectMode": "cover",
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "20px",
            "backgroundColor": "#03303acc",
            "offsetTop": "54px",
            "borderWidth": "1px",
            "borderColor": "#0cfbb0",
            "offsetStart": "0px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "xxs",
                "color": "#bbcfcc",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "50px",
            "offsetTop": "0px",
            "offsetStart": "0px"
          }
        ],
        "position": "absolute",
        "width": "154px",
        "height": "74px",
        "borderWidth": "1px",
        "borderColor": "#0cfbb0",
        "cornerRadius": "8px",
        "offsetTop": "2px",
        "offsetStart": "2px"
      }
    ],
    "height": "80px",
    "borderWidth": "1px",
    "borderColor": "#000000",
    "cornerRadius": "10px"
  },
  "action": {
    "type": "uri",
    "label": "action",
    "uri": "http://wa.me/+6285707063716",
  }
}
}
    cl.postTemplate(to, data)
def sendTextTemplate006(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "Menunggu Link",
                                       "contents":
{
  "type": "bubble",
  "size": "micro",
  "hero": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "animated": True,
        "url": "https://i.ibb.co/PC0GrXZ/ezgif-com-gif-maker-1.png",
        "size": "full",
        "gravity": "top",
        "aspectRatio": "2:2",
        "aspectMode": "cover",
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/6chJwhf/ezgif-com-gif-maker.png",
                "size": "full",
                "aspectRatio": "6:4",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "100px",
            "offsetTop": "0px",
            "offsetStart": "0px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/BKJwN57/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "8:2",
                "aspectMode": "cover",
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "120px",
                "height": "50px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "50px",
            "offsetTop": "98px",
            "borderWidth": "1px",
            "borderColor": "#ffffff"
          }
        ],
        "position": "absolute",
        "width": "150px",
        "height": "140px",
        "borderWidth": "2px",
        "borderColor": "#ffffff",
        "cornerRadius": "5px",
        "offsetTop": "5px",
        "offsetStart": "5px"
      }
    ],
    "height": "150px"
  },
  "action": {
    "type": "uri",
    "label": "action",
    "uri": "http://wa.me/+6285707063716",
  }
}
}
    cl.postTemplate(to, data) 
def sendTextTemplate111(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "Menyebut mu",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/LZxGpYW/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/DC7z9Jn/ezgif-com-gif-maker-3.png",
                "size": "full",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/cNNRQk4/ezgif-com-gif-maker.png",
                    "size": "xxl",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "-20px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "30px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "BROADCAST",
                    "size": "md",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "30px",
                "offsetTop": "1px",
                "offsetStart": "25px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "40px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/RND842Y/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "2:4",
                "aspectMode": "cover",
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "5px",
                    "offsetStart": "5px"
                  }
                ],
                "position": "absolute",
                "width": "145px",
                "height": "190px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "190px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "45px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#000000",
        "cornerRadius": "10px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    },
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/LZxGpYW/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                "size": "full",
                "aspectRatio": "2:4",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Adventure club",
                    "size": "xs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "10px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "30px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "5px",
                "offsetTop": "200px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "228px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#000000",
        "cornerRadius": "10px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
#========temp==========
def sendTextTemplate9070(to, text):
    data = {
                            "type": "text",
                            "text": text,
                            "sentBy": {
                            "label": "Adventure",
                            "iconUrl": "https://i.ibb.co/bNBqP5T/07-39-38-9550611aa1fd2611b1d6f286a4e812bf.gif",
                            "linkUrl": "http://wa.me/+6285707063716"}}
    cl.postTemplate(to, data)
def sendTextTemplate90767(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "Mari makan Dulu",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/59j6Jt4/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "4:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/KyN30hn/ezgif-com-gif-maker-3.png",
                "size": "5xl",
                "aspectRatio": "8:6",
                "aspectMode": "cover",
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/ZG4jqV0/ezgif-com-gif-maker-1.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                    "offsetTop": "2px"
                  }
                ],
                "position": "absolute",
                "width": "154px",
                "height": "20px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [],
                "position": "absolute",
                "width": "154px",
                "height": "84px",
                "backgroundColor": "#77776666"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": wait,
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "118px",
                "height": "58px",
                "offsetTop": "22px",
                "offsetStart": "32px"
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "84px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "height": "90px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
def sendTextTemplate944(to, text):
    data = {
                            "type": "text",
                            "text": text,
                            "sentBy": {
                            "label": "BROADCAST",
                            "iconUrl": "https://i.ibb.co/bNBqP5T/07-39-38-9550611aa1fd2611b1d6f286a4e812bf.gif",
                            "linkUrl": "http://wa.me/+6285707063716"}}
    cl.postTemplate(to, data)
#=========DEF
def sendTextTemplate906(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "Mengirim FILE",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/59j6Jt4/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "4:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/KyN30hn/ezgif-com-gif-maker-3.png",
                "size": "5xl",
                "aspectRatio": "8:6",
                "aspectMode": "cover",
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/ZG4jqV0/ezgif-com-gif-maker-1.png",
                    "size": "full",
                    "aspectRatio": "6:4",
                    "aspectMode": "cover",
                    "offsetTop": "2px"
                  }
                ],
                "position": "absolute",
                "width": "154px",
                "height": "60px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [],
                "position": "absolute",
                "width": "154px",
                "height": "84px",
                "backgroundColor": "#77773333"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/z4gYmC3/ezgif-com-gif-maker-2.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "20px",
                    "height": "20px",
                    "offsetTop": "5px",
                    "offsetStart": "5px",
                    "cornerRadius": "100px"
                  }
                ],
                "position": "absolute",
                "width": "30px",
                "height": "30px",
                "cornerRadius": "100px",
                "offsetTop": "51px",
                "offsetStart": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "wrap": True,
                    "offsetTop": "2px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "118px",
                "height": "65px",
                "offsetTop": "15px",
                "offsetStart": "32px"
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "84px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "height": "90px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
def sendTextTemplate900(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "RoomNya kok kosong",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/y8qYcrc/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/ykmxR0P/ezgif-com-gif-maker.png",
                "size": "xxl",
                "aspectRatio": "6:2",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "140px",
                "height": "15px",
                "offsetTop": "0px",
                "offsetStart": "20px"
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "44px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "height": "50px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
def sendTextTemplate990(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "Kojom On",
                                       "contents": 
{
  "type": "bubble",
  "size": "micro",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
             #   "type": "text",
             #   "text": ".",
              #  "color": "#ffffff"
                  "type": "image",
                 "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                 "size": "full",
                 "aspectRatio": "1:3",
                 "aspectMode": "cover"
              }
            ],
            "cornerRadius": "10px",
            "height": "68px",
            "borderColor": "#ff7f00",
            "borderWidth": "2px",
            "offsetTop": "-20px",
            "offsetStart": "10px"
          }
        ],
        "spacing": "xl",
        "paddingAll": "20px",
        "height": "114px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": text,
            "size": "xxs",
            "color": "#ffffff",
            "wrap": True,
            "offsetTop": "-1px",
            "offsetStart": "15px"
          }
        ],
        "position": "absolute",
        "borderColor": "#ff7f00",
        "borderWidth": "2px",
        "cornerRadius": "8px",
        "backgroundColor": "#000000",
        "offsetTop": "10px",
        "offsetStart": "40px",
        "width": "114px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "Bot LINE update",
            "size": "xs",
            "color": "#ffffff",
            "wrap": True,
            "offsetStart": "10px"
          }
        ],
        "position": "absolute",
        "backgroundColor": "#000000",
        "borderWidth": "2px",
        "borderColor": "#ff7f00",
        "cornerRadius": "8px",
        "offsetTop": "35px",
        "offsetStart": "40px",
        "width": "114px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
            "gravity": "top",
            "size": "full",
            "aspectRatio": "1:1",
            "aspectMode": "cover",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "http://wa.me/+6285707063716",
            }
          }
        ],
        "position": "absolute",
        "borderWidth": "2px",
        "borderColor": "#ff7f00",
        "cornerRadius": "100px",
        "height": "55px",
        "width": "55px",
        "offsetTop": "6px"
      }
    ],
    "paddingAll": "0px",
    "borderWidth": "2px",
    "borderColor": "#ff7f00",
    "cornerRadius": "10px",
    "height": "72px",
    "backgroundColor": "#000000"
  },
  "styles": {
    "body": {
      "backgroundColor": "#ff7f00"
    }
    },
  }
}
    cl.postTemplate(to, data)
def sendTextTemplate901(to, text):
    data = {
                            "type": "text",
                            "text": text,
                            "sentBy": {
                            "label": "Adventure",
                            "iconUrl": "https://i.ibb.co/bNBqP5T/07-39-38-9550611aa1fd2611b1d6f286a4e812bf.gif",
                            "linkUrl": "http://wa.me/+6285707063716"}}
    cl.postTemplate(to, data)
#=========DEF COMEN PUBLIK=======
def sendTextTemplate300(to, text): #Def baca: 1
    data = {
                                       "type": "flex",
                                       "altText": "Selfbot_Line",
                                       "contents": {
"type": "carousel",
"contents": [
{
"type": "bubble",
"size": "nano",
"body": {
"backgroundColor": "#00ff00",
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image",
"url": "https://i.ibb.co/8BS4WxD/images-2-1595704390352.png", 
"gravity": "bottom",
"size": "full",
"aspectMode": "cover",
"aspectRatio": "4:5",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=ucebba675be5aa9e5733bfb2084aea5a7",
"type": "uri",
}
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image",
"url": "https://i.ibb.co/8BS4WxD/images-2-1595704390352.png",
"gravity": "bottom",
"size": "full",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u2a0df60f692f0907140ce22aefb32edd",
"type": "uri",
}}],
"position": "absolute",
"cornerRadius": "10px",
"offsetTop": "0px",
"offsetStart": "0px",
"height": "145px",
"width": "105px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image",
"url": "https://i.ibb.co/8BS4WxD/images-2-1595704390352.png",
"gravity": "bottom",
"size": "full",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=ucebba675be5aa9e5733bfb2084aea5a7",
"type": "uri",
}}],
"position": "absolute",
"cornerRadius": "10px",
"offsetTop": "0px",
"offsetStart": "0px",
"height": "145px",
"width": "105px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image",
"url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQNbHeKfKZ9ITF6-xfqowdmMB3nvzZHwsnny59tKTZRecWqFqny",
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u2a0df60f692f0907140ce22aefb32edd",
"type": "uri",
}}],
"position": "absolute",
"cornerRadius": "10px",
"offsetTop": "0px",
"offsetStart": "0px",
"height": "145px",
"width": "105px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "Line update", 
"align": "center",
"color": "#ff0000",
"size": "xxs",
"weight": "bold",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "4px",
"offsetTop": "0px",
#"backgroundColor": #"#ffd700",
"offsetStart": "5px",
"height": "14px",
"width": "45px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://i.gifer.com/THMv.gif", #https://thumbs.gfycat.com/RawThirstyJanenschia-size_restricted.gif",
"size": "full",
"action": {
"type": "uri",
"uri": "https://wa.me/089530777767",
},         
"flex": 0
}
],
"position": "absolute",
"offsetTop": "13px",
"offsetStart": "115px",
"height": "43px",
"width": "25px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
"size": "xl",
"action": {
"type": "uri",
"uri": "line://nv/timeline",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
"size": "full",
"action": {
"type": "uri",
"uri": "http://wa.me/+6285707063716",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
"size": "xl",
"action": {
"type": "uri",
"uri": "Https://smule.com/_BowWow",
},
"flex": 0
}
],
"position": "absolute",
"offsetTop": "5px",
"offsetStart": "90px",
"height": "180px",
"width": "32px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "⏰"+ datetime.strftime(timeNow,'%H:%M:%S'),
"weight": "bold",
"color": "#93ff00",
#"align": "center",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "4px",
"offsetTop": "100px",
"backgroundColor": "#4b4b4b",
"offsetStart": "5px",
"height": "16px",
"width": "61px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "🚹{} ".format(contact.displayName),
"weight": "bold",
"color": "#93ff00",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "4px",
"offsetTop": "130px",
#"backgroundColor": "#000000",
"offsetStart": "5px",
"height": "18px",
"width": "121px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": text,
"weight": "bold",
"color": "#ff0000",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "4px",
"offsetTop": "165px",
#"backgroundColor": "#ac00c8",
"offsetStart": "20px",
"height": "16px",
"width": "121px"
}
],
#"backgroundColor": "#",
"paddingAll": "0px"
}
},
]
}
}
    cl.postTemplate(to, data)

def sendTextTemplate(to, text):
    data = {
            "type": "flex",
            "altText": "LINE update",
            "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#2f2f4f"
    }
  },
  "type": "bubble",
  "size": "micro",
  "body": {
    "contents": [
      {
        "contents": [
          {
            "contents": [
             {
            "type": "separator",
            "color": "#33ffff"            
            },
            {
            "contents": [
            {
            "type": "separator",
            "color": "#33ffff" 
   },
   {
            "text": text,
           "size": "xxs",
           "color": "#00ff00",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)


def sendTextTemplate1010(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "Audio yt",
                                       "contents":
{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/WfHJw7r/ezgif-com-gif-maker-2.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "4:4",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/TcM9Cy4/ezgif-com-gif-maker.png",
                "size": "full",
                "aspectRatio": "6:3",
                "aspectMode": "cover",
                "offsetTop": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "5px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "15px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "2px",
                "offsetTop": "0px",
                "offsetStart": "1px"
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "44px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/TgR7PYb/ezgif-com-gif-maker-1.png",
                "size": "full",
                "aspectRatio": "3:2",
                "aspectMode": "cover",
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "50px"
          }
        ],
        "paddingAll": "0px",
        "height": "50px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
    cl.postTemplate(to, data)

def sendTextTemplate1(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "Selfbot_Line",
                                        "contents": {
"styles": {"body": {
"backgroundColor": "#ff0000"
},
"footer": 
{"backgroundColor": "#000000"
}},
"type": "bubble",
"size": "nano",
"body":
{
"contents": [
{
"contents": [
{
"type": "separator",
"color": "#ffff00"
},{
"type": "separator",
"color": "#ffff00"
},{
"contents": [
{
"type": "separator",
"color": "#ffff00"
},{
"contents": [
{
"text": text,
"size": "xxs",
"align": "center",
"color": "#000000",
"wrap": True,
"weight": "bold",
"type": "text"
}],
"type": "box",
"spacing": "xs",
"layout": "vertical"
},{
"type": "separator",
"color": "#ffff00"
}],
"type": "box",
"layout": "horizontal"
},{
"type": "separator",
"color": "#ffff00"
},{
"contents": [
          {
            "type": "separator",
            "color": "#ffff00"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com"
            },
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://wa.me/+6285707063716",             
           }, 
            "flex": 1            
          },
          {
        "type": "image",
            "url": "https://i.ibb.co/kSMSnWn/20190427-191235.png", #camerahttps://i.ibb.co/hVWDsp8/20190428-232907.png", #smulehttps://i.ibb.co/8YfQVtr/20190427-185626.png", #callinghttps://kepriprov.go.id/assets/img/icon/phone.png", #phone
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/camera/"
          },
            "flex": 1
            },
          {
          "type": "image",
            "url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/_BowWow",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffff00"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffff00"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)

def sendTextTemplate2(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "Line Update..",
                                        "contents": {
  "styles": {"body": {
            "backgroundColor": "#000000"},"footer": {"backgroundColor": "#000000"}},
            "type": "bubble","size": "micro","body": {"contents": [{"contents": [{
             "type": "separator","color": "#ffffff"},{"type": "separator","color": "#ffffff"
              },{"contents": [{   "type": "separator","color": "#ffffff"
              },{"contents": [
              {"text": text, "size": "xxs",
              "color": "#00ff00","wrap": True,"weight": "bold","type": "text"
              }],"type": "box","spacing": "md","layout": "vertical"},{
              "type": "separator","color": "#ffffff"}],"type": "box","layout": "horizontal"},{"type": "separator","color": "#ffffff"},{
              "contents": [
          {
            "type": "separator",
            "color": "#ffffff"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com"
            },
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://wa.me/+6285707063716",             
           }, 
            "flex": 1            
          },
          {
        "type": "image",
            "url": "https://i.ibb.co/kSMSnWn/20190427-191235.png", #camerahttps://i.ibb.co/hVWDsp8/20190428-232907.png", #smulehttps://i.ibb.co/8YfQVtr/20190427-185626.png", #callinghttps://kepriprov.go.id/assets/img/icon/phone.png", #phone
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/camera/"
          },
            "flex": 1
            },
          {
          "type": "image",
            "url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://smule.com/_BowWow",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)
def sendTextTemplate902(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "loading chat",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    },
    "footer": {
      "backgroundColor": "#2f2f4f"
    }
  },
  "type": "bubble",
 "size": "micro",
      "body": {
  "contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#ff0000"            
      },
      {
        "type": "separator",
        "color": "#ff0000"  
      },
      {         
         "contents": [
          {
          "type": "separator",
          "color": "#ff0000"   
      },
      {
            "contents": [
              {
              "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          },{
 "type": "text",
"text": "sᴇʟғʙᴏᴛ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ᴛᴇᴍᴘʟᴀᴛᴇ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ᴠᴇʀsɪ³",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ff0000"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#ff0000"
         },
         {
            "text": "BOT",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ff0000"
           },
             {
            "text": "LI",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ff0000"
           },
             {
            "text": "NE™",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
            },
         {
        "type": "separator",
        "color": "#ff0000"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         },
         {
       "contents": [
          {
           "type": "separator",
           "color": "#ff0000"
          },
          {
          "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
            "type": "image",
            "size": "xxs",
            "flex": 0
          },
          {
        "type": "separator",
        "color": "#ff0000"
      },
      {      
       "contents": [              
          {
"type": "text",
"text": "NOTIF SMULE",
"weight": "bold",
"color": "#33ffff",
"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#33ffff"
},{
"type": "text",
"text": "🕙"+ datetime.strftime(timeNow,'%H:%M:%S'+"🕙"),
"weight": "bold",
"color": "#ccffff",
"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#ff0000"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"
      },
      {
        "type": "separator",
         "color": "#ff0000"
       },
       {     
       "contents": [           
         { 
           "type": "separator",
           "color": "#ff0000"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#ff0000"
            },
           {
          "type": "text",
"text": "{}".format(cl.getContact(mid).displayName),
"weight": "bold",
"color": "#ffff00",
"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ff0000"
         },
         {          
         "contents": [
         { 
           "type": "separator",
           "color": "#ff0000"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#ff0000"
            },
           {
          "text": text,
           "size": "xxs",
          "align": "center",
           "color": "#ffff00",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ff0000"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#ff0000"
         },
         {
            "text": "BOT",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ff0000"
           },
             {
            "text": "LI",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ff0000"
           },
             {
            "text": "NE™",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
          },
         {
        "type": "separator",
        "color": "#ff0000"
         }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         },
         {
      "contents": [
          {
            "type": "separator",
            "color": "#ff0000"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com",
           }, 
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://wa.me/+6285707063716",             
           }, 
            "flex": 1            
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/ZHtFDts/20190427-185307.png", #chathttps://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/chat" #"http://line.me/ti/p/~banchat525",
            },         
            "flex": 1          
            },
          {
          "type": "image",
            "url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/_BowWow",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
          },
            "flex": 1           
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ff0000"
        },{
        "contents": [         
              {
            "type": "separator",
            "color": "#ff0000"
            },
             {          
            "contents": [
               {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
    },{
 "type": "text",
"text": "REZIMA",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "BOTS",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "TEAM",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator", #batas APK
        "color": "#ff0000"     
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)
        
def sendTextTemplate903(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "MENGIRIMKAN ZIP",
                                       "contents": {
  "type": "carousel",
  "contents": [
    {                                      
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:1",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "size": "xs",
                "color": "#2bff44",
              }
            ],
            "position": "absolute",
            "width": "125px",
            "height": "1px",
            "backgroundColor": "#5eff7e",
            "offsetTop": "25px",
            "offsetStart": "15px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "NOTIF SMULE",
                "size": "xxs",
                "color": "#ff0000",
                "weight": "bold",
                "style": "normal",
                "align": "center"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "15px",
            "offsetTop": "1px",
            "offsetStart": "1px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": "#2bff44",
                "size": "xxs"
              }
            ],
            "position": "absolute",
            "width": "125px",
            "height": "1px",
            "backgroundColor": "#5eff7e",
            "offsetTop": "200px",
            "offsetStart": "15px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure",
                "size": "xxs",
                "style": "normal",
                "weight": "bold",
                "align": "center",
                "color": "#ff0000",
              }
            ],
            "position": "absolute",
            "width": "148px",
            "height": "25px",
            "offsetTop": "1px",
            "offsetStart": "35px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "xxs",
                "weight": "bold",
                "color": "#ffff00",
                "style": "normal",
                "wrap": True,
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "offsetTop": "10px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "3px",
        "borderColor": "#ff0000",
        "cornerRadius": "15px"
      },
      "styles": {
        "body": {         
         "backgroundColor": "#ffffff"
        }
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
        
def sendTextTemplate904(to, text):
    data = {
                                       "type": "flex",
                                       "altText": "LOADING CHAT",
                                       "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/zVkvMkQ/07-25-06-ff8693ae1bd3bb8c182752715c1a10e8.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/5R3rBR3/ezgif-com-gif-maker-3-1-1.png",
                "size": "full",
                "aspectRatio": "2:3",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "158px",
            "height": "238px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "BROADCAST",
                "size": "xl",
                "color": "#000000",
                "weight": "bold",
                "gravity": "top",
                "offsetTop": "0px",
                "offsetStart": "8px"
              }
            ],
            "position": "absolute",
            "width": "145px",
            "height": "30px",
            "borderWidth": "1px",
            "borderColor": "#000000",
            "cornerRadius": "0px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure ™",
                "size": "sm",
                "color": "#ff0000",
                "weight": "bold",
                "gravity": "top",
                "offsetTop": "0px",
                "offsetStart": "14px"
              }
            ],
            "position": "absolute",
            "width": "120px",
            "height": "20px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "0px",
            "offsetTop": "205px",
            "offsetStart": "19px"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "text",
                "text": text,
                "size": "sm",
                "color": "#000000",
                "weight": "bold",
                "wrap": True,
                "gravity": "top"
              }
            ],
            "position": "absolute",
            "offsetTop": "45px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "1px",
        "borderColor": "#ffffff",
        "cornerRadius": "10px"
      }
    }
  ]
}
}
    cl.postTemplate(to, data)
    
def sendTextTemplate905(to, text):
    data = {
                                        "type": "flex",
                                        "altText": "MENGIRIMKAN PESAN",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#00ff00"
    },
    "footer": {
      "backgroundColor": "#2f2f4f"
    }
  },
  "type": "bubble",
 "size": "micro",
      "body": {
  "contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#ff0000"            
      },
      {
        "type": "separator",
        "color": "#ff0000"  
      },
      {         
         "contents": [
          {
          "type": "separator",
          "color": "#ff0000"   
      },
      {
            "contents": [
              {
              "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          },{
 "type": "text",
"text": "sᴇʟғʙᴏᴛ",
"weight": "bold",
"color": "#000000",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ᴛᴇᴍᴘʟᴀᴛᴇ",
"weight": "bold",
"color": "#000000",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ᴠᴇʀsɪ³",
"weight": "bold",
"color": "#000000",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ff0000"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#ff0000"
         },
         {
            "text": "BOT",
            "size": "xxs",
            "color": "#000000",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ff0000"
           },
             {
            "text": "LI",
            "size": "xxs",
            "color": "#000000",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ff0000"
           },
             {
            "text": "NE™",
            "size": "xxs",
            "color": "#000000",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
            },
         {
        "type": "separator",
        "color": "#ff0000"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         },
         {
       "contents": [
          {
           "type": "separator",
           "color": "#ff0000"
          },
          {
          "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
            "type": "image",
            "size": "xxs",
            "flex": 0
          },
          {
        "type": "separator",
        "color": "#ff0000"
      },
      {      
       "contents": [              
          {
"type": "text",
"text": "LIVE VIDEO",
"weight": "bold",
"color": "#000000",
"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#ff0000"
},{
"type": "text",
"text": "🕙"+ datetime.strftime(timeNow,'%H:%M:%S'+"🕙"),
"weight": "bold",
"color": "#000000",
"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#ff0000"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"
      },
      {
        "type": "separator",
         "color": "#ff0000"
       },
       {     
       "contents": [           
         { 
           "type": "separator",
           "color": "#ff0000"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#ff0000"
            },
           {
          "type": "text",
"text": "{}".format(cl.getContact(mid).displayName),
"weight": "bold",
"color": "#000000",
"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ff0000"
         },
         {          
         "contents": [
         { 
           "type": "separator",
           "color": "#ff0000"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#ff0000"
            },
           {
          "text": text,
           "size": "xxs",
          "align": "center",
           "color": "#000000",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ff0000"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#ff0000"
         },
         {
            "text": "BOT",
            "size": "xxs",
            "color": "#000000",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ff0000"
           },
             {
            "text": "LI",
            "size": "xxs",
            "color": "#000000",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#ff0000"
           },
             {
            "text": "NE™",
            "size": "xxs",
            "color": "#000000",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
          },
         {
        "type": "separator",
        "color": "#ff0000"
         }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         },
         {
      "contents": [
          {
            "type": "separator",
            "color": "#ff0000"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com",
           }, 
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://wa.me/+6285707063716",             
           }, 
            "flex": 1            
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/ZHtFDts/20190427-185307.png", #chathttps://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/chat" #"http://line.me/ti/p/~banchat525",
            },         
            "flex": 1          
            },
          {
          "type": "image",
            "url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/_BowWow",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
          },
            "flex": 1           
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ff0000"
        },{
        "contents": [         
              {
            "type": "separator",
            "color": "#ff0000"
            },
             {          
            "contents": [
               {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
    },{
 "type": "text",
"text": "Adventure",
"weight": "bold",
"color": "#ff0000",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "BOTS",
"weight": "bold",
"color": "#ff0000",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "TEAM",
"weight": "bold",
"color": "#ff0000",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#ff0000"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator", #batas APK
        "color": "#ff0000"     
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    cl.postTemplate(to, data)
   #Def Musik
   
def sendTextTemplate10(to, text):
    data = {
                                "type": "flex",
                                "altText": "MUSIC HOT",
                                "contents": {
"type": "carousel",
"contents": [
{
"type": "bubble",
"size": "nano",
"body": {
"backgroundColor": "#00ff00",
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 1
"url": "https://content.skyscnr.com/m/7d3992c451e6cf6c/original/color.gif?imbypass=true",
"size": "full",
"aspectMode": "cover",
"aspectRatio": "4:5",
"gravity": "bottom",
"action": {
"uri": "line://nv/profilePopup/mid=ucebba675be5aa9e5733bfb2084aea5a7",
"type": "uri",
}
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://content.skyscnr.com/m/7d3992c451e6cf6c/original/color.gif?imbypass=true",
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=ucebba675be5aa9e5733bfb2084aea5a7",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:3",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=ucebba675be5aa9e5733bfb2084aea5a7",
"type": "uri",
}
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "140px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "Hiburan",
"align": "center",
"color": "#000000",
"weight": "bold",
"size": "xxs",
"weight": "bold",
"offsetTop": "1px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "9px",
"backgroundColor": "#ffd700",
"offsetStart": "7px",
"height": "15px",
"width": "45px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://thumbs.gfycat.com/UnkemptWhiteKakapo-max-1mb.gif",
"size": "xxl",
"action": {
"type": "uri",
"uri": "https://wa.me/089530777767",
},         
"flex": 0
}
],
"position": "absolute",
"offsetTop": "5px",
"offsetStart": "92px",
"height": "43px",
"width": "22px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://thumbs.gfycat.com/UnkemptWhiteKakapo-max-1mb.gif",
"size": "xxl",
"action": {
"type": "uri",
"uri": "https://joox.com"
},         
"flex": 0
}
],
"position": "absolute",
"offsetTop": "5px",
"offsetStart": "67px",
"height": "43px",
"width": "22px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #dsini
{
"type": "image",
"url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
"size": "xl",
"action": {
"type": "uri",
"uri": "Https://smule.com/_BowWow",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/ZHtFDts/20190427-185307.png",
"size": "xl",
"action": {
"type": "uri",
"uri": "line://nv/chat",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
"size": "full",
"action": {
"type": "uri",
"uri": "http://wa.me/+6285707063716",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
"size": "full",
"action": {
"type": "uri",
"uri": "https://youtube.com",
},
"flex": 0
}
],
"position": "absolute",
"offsetTop": "25px",
"offsetStart": "5px",
"height": "180px",
"width": "25px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "🕙 "+ datetime.strftime(timeNow,'%H:%M:%S'),
"weight": "bold",
"color": "#ffffff",
#"align": "center",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "98px",
"backgroundColor": "#ff0000",
"offsetStart": "50px",
"height": "16px",
"width": "63px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": text, #📆 "+ datetime.strftime(timeNow,'%Y-%m-%d'),
"weight": "bold",
"color": "#ffffff",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "115px",
"backgroundColor": "#0000ff",
"offsetStart": "33px",
"height": "14px",
"width": "80px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "🔰 Adventure_ʙᴏᴛᴢ",
"weight": "bold",
"color": "#00ff00",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "5px",
"offsetTop": "130px",
#"backgroundColor": "#33ffff",
"offsetStart": "8px",
"height": "50px",
"width": "110px"
}
],
#"backgroundColor": "#",
"paddingAll": "0px"
}
},
]
}
}
    cl.postTemplate(to, data)
   
def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain['keyCommand']):
        cmd = pesan.replace(Setmain['keyCommand'],"")
    else:
        cmd = "command"
    return cmd

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoBlock"] == True:
                cl.blockContact(op.param1)
                cl.sendMessage(op.param1,"┌──────────────────┐\n • ᴛʜᴀɴᴋᴢ ғᴏʀ ᴀᴅᴅ ᴍᴇ \n • ᴍᴀᴀғ ᴀᴜᴛᴏʙʟᴏᴄᴋ sᴀʏᴀ ᴀᴋᴛɪғ├──────────────────★.★.★.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.👿.👿.👿 ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n❌.??️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.!!")
                #cl.sendMessage(op.param1,"ᴛʜᴀɴᴋᴢ ғᴏʀᴅ ᴀᴅᴅ ᴍᴇ\n ᴍᴀᴀғ ᴀᴜᴛᴏʙʟᴏᴄᴋ sᴀʏᴀ ᴀᴋᴛɪғ")

        if op.type == 11:
            if op.param1 in protectqr:
                try:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            cl.reissueGroupTicket(op.param1)
                            X = cl.getGroup(op.param1)
                            X.preventJoinByTicket = False
                            cl.updateGroup(X)
                            Ti = cl.reissueGroupTicket(op.param1)
                            k1.acceptGroupInvitationByTicket(op.param1,Ti)                           
                            k1.sendMessage(op.param1,"Wah kiker mainan qr minta di Di Keplak")                            
                            k1.kickoutFromGroup(op.param1,[op.param2])
                            wait["blacklist"][op.param2] = True
                            X = k1.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            k1.updateGroup(X)
                            k1.leaveGroup(op.param1)                                            
                            cl.inviteIntoGroup(op.param1,[Amid])
                except:
                    pass
          
        if op.type == 13:
            if op.param1 in protectinvite:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:                	
                    try:                          
                        cl.kickoutFromGroup(op.param1,[op.param2])                        
                        wait["blacklist"][op.param2] = True
                    except:
                        pass
 	  
        if op.type == 13:
            if op.param1 in protectinvite:
                if op.param2 not in Bots and op.param2 not in admin and op.param2 not in staff:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Bots and _mid not in admin and _mid not in staff:
                                cl.cancelGroupInvitation(op.param1,[_mid])
                                cl.kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass
                        	
        if op.type == 13:
            if wait["backup"] ==False:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    try:
                        if op.param3 in Bots or op.param3 in owner or op.param3 in admin or op.param2 in staff:
                            pass
                        else:
                            if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                try:
                                    inv1 = op.param3.replace('\x1e',',')
                                    inv2 = inv1.split(',')
                                    for _mid in inv2:
                                        if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in staff:
                                            cl.cancelGroupInvitation(op.param1,[_mid])
                                            cl.kickoutFromGroup(op.param1,[op.param2])
                                            wait["blacklist"][op.param2] = True
                                except:
                                    pass
                            else:pass
                    except:
                        pass
        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        group = cl.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            if _mid in wait["blacklist"]:
                                cl.cancelGroupInvitation(op.param1,[_mid])
                                cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass

        if op.type == 13:
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        group = cl.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            if _mid in wait["blacklist"]:
                                cl.cancelGroupInvitation(op.param1,[_mid])
                                cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass

        if op.type == 13: 
            if op.param2 in wait["blacklist"]:
                try:
                    cl.kickoutFromGroup(op.param1,[op.param2])                   
                    print ("Anda masuk daftar hitam")
                except:
                    pass
        
        if op.type == 13:
            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        sendTextTemplate1(op.param1,"eмooн..." +str(ginfo.name))
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        sendTextTemplate1(op.param1,"Pamit dulu..." + str(ginfo.name))
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
                if msg.contentType == 6:
                  if wait["nCall"] == True:
                    if msg._from not in Bots:
                        try:
                            contact = cl.getContact(sender)
                            group = cl.getGroup(msg.to)
                            cover = cl.getProfileCoverURL(sender)
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            if msg.toType == 2:                
                                b = msg.contentMetadata['GC_EVT_TYPE']
                                c = msg.contentMetadata["GC_MEDIA_TYPE"]
                                if c == "VIDEO" and b == "S":
                                    tz = pytz.timezone("Asia/Jakarta")
                                    timeNow = datetime.now(tz=tz)
                                    arg = "ɢʀᴏᴜᴘ {} call".format(c)
                                    a1 = "{}".format(str(contact.displayName))
                                    a2 = "{}".format(datetime.strftime(timeNow,'%H:%M'))
                                    a3 = "{}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                    data = {
                                        "type": "flex",
                                        "altText": "assalamualaikum",
                                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/8MKgPwd/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:4",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/gJffXXQ/09-20-11-40cf459176b92a35ae858e949304bd72.jpg",
                "size": "full",
                "gravity": "top",
                "aspectRatio": "2:5",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Bn5hhdg/20210619-082528.png",
                    "size": "xxl",
                    "aspectRatio": "4:6",
                    "aspectMode": "cover"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": arg,
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic"
                      }
                    ],
                    "position": "absolute",
                    "width": "65px",
                    "height": "15px",
                    "offsetStart": "2px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "20px",
                    "height": "20px",
                    "borderWidth": "1px",
                    "borderColor": "#ffffff",
                    "cornerRadius": "100px",
                    "offsetTop": "3px",
                    "offsetStart": "65px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "16px",
                    "height": "16px",
                    "cornerRadius": "100px",
                    "offsetTop": "60px",
                    "offsetStart": "3px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": a1,
                        "size": "xxs",
                        "color": "#ffffff"
                      }
                    ],
                    "position": "absolute",
                    "width": "100px",
                    "height": "15px",
                    "offsetTop": "53px",
                    "offsetStart": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": a2,
                        "size": "xxs"
                      }
                    ],
                    "position": "absolute",
                    "width": "50px",
                    "height": "15px",
                    "offsetTop": "112px",
                    "offsetStart": "93px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Cie mau modus",
                        "size": "xs",
                        "color": "#000000"
                      }
                    ],
                    "position": "absolute",
                    "width": "100px",
                    "height": "15px",
                    "offsetTop": "202px",
                    "offsetStart": "15px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "300px",
                "offsetTop": "17px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": a2,
                    "size": "xxs",
                    "color": "#ffffff",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/SJ03tb5/ezgif-com-gif-maker-1.png",
                    "size": "xxs",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "20px",
                "height": "20px",
                "offsetTop": "2px",
                "offsetEnd": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/xhMCwKW/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:4",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "300px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "240px",
            "borderWidth": "2px",
            "borderColor": "#ccbb00",
            "cornerRadius": "6px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#ccbb00",
        "cornerRadius": "10px",
        "height": "250px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                                    cl.postTemplate(msg.to, data)
                                if c == 'AUDIO' and b == "S":
                                    tz = pytz.timezone("Asia/Jakarta")
                                    timeNow = datetime.now(tz=tz)
                                    arg = "ɢʀᴏᴜᴘ {} call".format(c)
                                    satu = "{}".format(str(contact.displayName))
                                    dua = "{}".format(datetime.strftime(timeNow,'%H:%M'))
                                    tiga = "{}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                    data = {
                                        "type": "flex",
                                        "altText": "ayo naik",
                                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/8MKgPwd/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:4",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/gJffXXQ/09-20-11-40cf459176b92a35ae858e949304bd72.jpg",
                "size": "full",
                "gravity": "top",
                "aspectRatio": "2:5",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/GWF8xMn/20210619-104739.png",
                    "size": "xxl",
                    "aspectRatio": "4:6",
                    "aspectMode": "cover"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": arg,
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic"
                      }
                    ],
                    "position": "absolute",
                    "width": "65px",
                    "height": "15px",
                    "offsetStart": "2px",
                    "backgroundColor": "#ffffff"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "10px",
                    "height": "10px",
                    "borderWidth": "1px",
                    "borderColor": "#ffffff",
                    "cornerRadius": "100px",
                    "offsetTop": "14px",
                    "offsetStart": "3px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "16px",
                    "height": "16px",
                    "cornerRadius": "100px",
                    "offsetTop": "60px",
                    "offsetStart": "3px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": satu,
                        "size": "xxs",
                        "color": "#ffffff"
                      }
                    ],
                    "position": "absolute",
                    "width": "100px",
                    "height": "15px",
                    "offsetTop": "53px",
                    "offsetStart": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": dua,
                        "size": "xxs"
                      }
                    ],
                    "position": "absolute",
                    "width": "50px",
                    "height": "15px",
                    "offsetTop": "112px",
                    "offsetStart": "93px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Panggilan alam gaib",
                        "size": "xxs",
                        "color": "#000000"
                      }
                    ],
                    "position": "absolute",
                    "width": "100px",
                    "height": "15px",
                    "offsetTop": "202px",
                    "offsetStart": "15px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": satu,
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "regular"
                      }
                    ],
                    "position": "absolute",
                    "width": "46px",
                    "height": "15px",
                    "offsetTop": "26px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "300px",
                "offsetTop": "17px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": dua,
                    "size": "xxs",
                    "color": "#ffffff",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/SJ03tb5/ezgif-com-gif-maker-1.png",
                    "size": "xxs",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "20px",
                "height": "20px",
                "offsetTop": "2px",
                "offsetEnd": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/xhMCwKW/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:4",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "300px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "240px",
            "borderWidth": "2px",
            "borderColor": "#ccbb00",
            "cornerRadius": "6px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#ccbb00",
        "cornerRadius": "10px",
        "height": "250px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                                    cl.postTemplate(msg.to, data)
                                if c == 'LIVE' and b == 'S':
                                    tz = pytz.timezone("Asia/Jakarta")
                                    timeNow = datetime.now(tz=tz)
                                    arg = "ɢʀᴏᴜᴘ {} call".format(c)
                                    c1 = "{}".format(str(contact.displayName))
                                    c2 = "{}".format(datetime.strftime(timeNow,'%H:%M'))
                                    c3 = "{}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                    data = {
                                        "type": "flex",
                                        "altText": "artist Line live",
                                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/8MKgPwd/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:4",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/gJffXXQ/09-20-11-40cf459176b92a35ae858e949304bd72.jpg",
                "size": "full",
                "gravity": "top",
                "aspectRatio": "2:5",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/bLhgXZ2/20210619-082752.png",
                    "size": "xxl",
                    "aspectRatio": "4:6",
                    "aspectMode": "cover"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": arg,
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic"
                      }
                    ],
                    "position": "absolute",
                    "width": "65px",
                    "height": "15px",
                    "offsetStart": "2px",
                    "backgroundColor": "#ffffff"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "20px",
                    "height": "20px",
                    "borderWidth": "1px",
                    "borderColor": "#ffffff",
                    "cornerRadius": "100px",
                    "offsetTop": "2px",
                    "offsetStart": "65px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "16px",
                    "height": "16px",
                    "cornerRadius": "100px",
                    "offsetTop": "60px",
                    "offsetStart": "3px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": c1,
                        "size": "xxs",
                        "color": "#ffffff"
                      }
                    ],
                    "position": "absolute",
                    "width": "100px",
                    "height": "15px",
                    "offsetTop": "53px",
                    "offsetStart": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": c2,
                        "size": "xxs"
                      }
                    ],
                    "position": "absolute",
                    "width": "50px",
                    "height": "15px",
                    "offsetTop": "112px",
                    "offsetStart": "93px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "ciee artisnya naik",
                        "size": "xxs",
                        "color": "#000000"
                      }
                    ],
                    "position": "absolute",
                    "width": "100px",
                    "height": "15px",
                    "offsetTop": "202px",
                    "offsetStart": "15px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "300px",
                "offsetTop": "17px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": c2,
                    "size": "xxs",
                    "color": "#ffffff",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/SJ03tb5/ezgif-com-gif-maker-1.png",
                    "size": "xxs",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "20px",
                "height": "20px",
                "offsetTop": "2px",
                "offsetEnd": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/xhMCwKW/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:4",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "300px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "240px",
            "borderWidth": "2px",
            "borderColor": "#ccbb00",
            "cornerRadius": "6px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#ccbb00",
        "cornerRadius": "10px",
        "height": "250px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                                    cl.postTemplate(msg.to, data)
                                else:
                                    mills = int(msg.contentMetadata["DURATION"])
                                    seconds = (mills/1000)%60
                                    if c == "VIDEO" and b == "E":
                                   # 	tz = pytz.timezone("Asia/Jakarta")
                                  #      timeNow = datetime.now(tz=tz)
                                        arg ="ɢʀᴏᴜᴘ {} call".format(c)
                                        b1 = "{}".format(str(contact.displayName))
                                        b2 = "{}".format(datetime.strftime(timeNow,'%H:%M'))
                                        b3 = "{}".format(seconds)
                                        data = {
                                        "type": "flex",
                                        "altText": "Adventure Line",
                                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/8MKgPwd/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:4",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/gJffXXQ/09-20-11-40cf459176b92a35ae858e949304bd72.jpg",
                "size": "full",
                "gravity": "top",
                "aspectRatio": "2:5",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/1Gq8jcG/20210619-083407.png",
                    "size": "xxl",
                    "aspectRatio": "4:6",
                    "aspectMode": "cover"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": arg,
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic"
                      }
                    ],
                    "position": "absolute",
                    "width": "65px",
                    "height": "15px",
                    "offsetStart": "2px",
                    "backgroundColor": "#ffffff"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "20px",
                    "height": "20px",
                    "borderWidth": "1px",
                    "borderColor": "#ffffff",
                    "cornerRadius": "100px",
                    "offsetTop": "2px",
                    "offsetStart": "65px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "16px",
                    "height": "16px",
                    "cornerRadius": "100px",
                    "offsetTop": "60px",
                    "offsetStart": "3px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": b1,
                        "size": "xxs",
                        "color": "#ffffff"
                      }
                    ],
                    "position": "absolute",
                    "width": "100px",
                    "height": "15px",
                    "offsetTop": "53px",
                    "offsetStart": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": b2,
                        "size": "xxs"
                      }
                    ],
                    "position": "absolute",
                    "width": "50px",
                    "height": "15px",
                    "offsetTop": "138px",
                    "offsetStart": "47px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "kang modus turun",
                        "size": "xxs",
                        "color": "#000000"
                      }
                    ],
                    "position": "absolute",
                    "width": "100px",
                    "height": "15px",
                    "offsetTop": "202px",
                    "offsetStart": "15px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "300px",
                "offsetTop": "17px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": b2,
                    "size": "xxs",
                    "color": "#ffffff",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/SJ03tb5/ezgif-com-gif-maker-1.png",
                    "size": "xxs",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "20px",
                "height": "20px",
                "offsetTop": "2px",
                "offsetEnd": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/xhMCwKW/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:4",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "300px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "240px",
            "borderWidth": "2px",
            "borderColor": "#ccbb00",
            "cornerRadius": "6px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#ccbb00",
        "cornerRadius": "10px",
        "height": "250px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                                        cl.postTemplate(msg.to, data)
                                    if c == "AUDIO" and b == "E":
                                        tz = pytz.timezone("Asia/Jakarta")
                                        timeNow = datetime.now(tz=tz)
                                        arg ="ɢʀᴏᴜᴘ {} call".format(c)
                                        empat = "{}".format(str(contact.displayName))
                                        lima = "{}".format(datetime.strftime(timeNow,'%H:%M'))
                                        enam = "{}".format(seconds)
                                        data = {
                                        "type": "flex",
                                        "altText": "para jones up",
                                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/8MKgPwd/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:4",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/gJffXXQ/09-20-11-40cf459176b92a35ae858e949304bd72.jpg",
                "size": "full",
                "gravity": "top",
                "aspectRatio": "2:5",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/7S099zS/20210619-083323.png",
                    "size": "xxl",
                    "aspectRatio": "4:6",
                    "aspectMode": "cover"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": arg,
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic"
                      }
                    ],
                    "position": "absolute",
                    "width": "65px",
                    "height": "15px",
                    "offsetStart": "2px",
                    "backgroundColor": "#ffffff"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "10px",
                    "height": "10px",
                    "borderWidth": "1px",
                    "borderColor": "#ffffff",
                    "cornerRadius": "100px",
                    "offsetTop": "14px",
                    "offsetStart": "3px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "16px",
                    "height": "16px",
                    "cornerRadius": "100px",
                    "offsetTop": "60px",
                    "offsetStart": "3px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": empat,
                        "size": "xxs",
                        "color": "#ffffff"
                      }
                    ],
                    "position": "absolute",
                    "width": "100px",
                    "height": "15px",
                    "offsetTop": "53px",
                    "offsetStart": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": lima,
                        "size": "xxs"
                      }
                    ],
                    "position": "absolute",
                    "width": "50px",
                    "height": "15px",
                    "offsetTop": "138px",
                    "offsetStart": "46px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Panggilan gaib berakhir",
                        "size": "xxs",
                        "color": "#000000"
                      }
                    ],
                    "position": "absolute",
                    "width": "100px",
                    "height": "15px",
                    "offsetTop": "202px",
                    "offsetStart": "15px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": empat,
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "regular"
                      }
                    ],
                    "position": "absolute",
                    "width": "46px",
                    "height": "15px",
                    "offsetTop": "26px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "300px",
                "offsetTop": "17px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": lima,
                    "size": "xxs",
                    "color": "#ffffff",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/SJ03tb5/ezgif-com-gif-maker-1.png",
                    "size": "xxs",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "20px",
                "height": "20px",
                "offsetTop": "2px",
                "offsetEnd": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/xhMCwKW/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:4",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "300px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "240px",
            "borderWidth": "2px",
            "borderColor": "#ccbb00",
            "cornerRadius": "6px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#ccbb00",
        "cornerRadius": "10px",
        "height": "250px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                                        cl.postTemplate(msg.to, data)
                                    if c == "LIVE" and b == "E":
                                        tz = pytz.timezone("Asia/Jakarta")
                                        timeNow = datetime.now(tz=tz)
                                        arg ="ɢʀᴏᴜᴘ {} call".format(c)
                                        d1 = "{}".format(str(contact.displayName))
                                        d2 = "{}".format(datetime.strftime(timeNow,'%H:%M'))
                                        d3 = "{}".format(seconds)
                                        data = {
                                        "type": "flex",
                                        "altText": "Artis terjatuh",
                                        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/8MKgPwd/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:4",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/gJffXXQ/09-20-11-40cf459176b92a35ae858e949304bd72.jpg",
                "size": "full",
                "gravity": "top",
                "aspectRatio": "2:5",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/9rZ7v12/20210619-083510.png",
                    "size": "xxl",
                    "aspectRatio": "4:6",
                    "aspectMode": "cover"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": arg,
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic"
                      }
                    ],
                    "position": "absolute",
                    "width": "65px",
                    "height": "15px",
                    "offsetStart": "2px",
                    "backgroundColor": "#ffffff"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "20px",
                    "height": "20px",
                    "borderWidth": "1px",
                    "borderColor": "#ffffff",
                    "cornerRadius": "100px",
                    "offsetTop": "2px",
                    "offsetStart": "65px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "16px",
                    "height": "16px",
                    "cornerRadius": "100px",
                    "offsetTop": "60px",
                    "offsetStart": "3px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": d1,
                        "size": "xxs",
                        "color": "#ffffff"
                      }
                    ],
                    "position": "absolute",
                    "width": "100px",
                    "height": "15px",
                    "offsetTop": "53px",
                    "offsetStart": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": d2,
                        "size": "xxs"
                      }
                    ],
                    "position": "absolute",
                    "width": "50px",
                    "height": "15px",
                    "offsetTop": "138px",
                    "offsetStart": "47px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "cie artisnya turun",
                        "size": "xxs",
                        "color": "#000000"
                      }
                    ],
                    "position": "absolute",
                    "width": "100px",
                    "height": "15px",
                    "offsetTop": "202px",
                    "offsetStart": "15px"
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "300px",
                "offsetTop": "17px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": d2,
                    "size": "xxs",
                    "color": "#ffffff",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "15px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/SJ03tb5/ezgif-com-gif-maker-1.png",
                    "size": "xxs",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "20px",
                "height": "20px",
                "offsetTop": "2px",
                "offsetEnd": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/xhMCwKW/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:4",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "300px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "240px",
            "borderWidth": "2px",
            "borderColor": "#ccbb00",
            "cornerRadius": "6px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#ccbb00",
        "cornerRadius": "10px",
        "height": "250px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                                        cl.postTemplate(msg.to, data)
                        except Exception as error:
                            print (error)

        if op.type == 13:
            if wait["autoJoin"] and mid in op.param3:
                group = cl.getGroup(op.param1)
                group.notificationDisabled = False
                cl.acceptGroupInvitation(op.param1)
                cl.updateGroup(group)
                ginfo = cl.getGroup(op.param1)
                cl.sendMessage(op.param1,"ᴛʜᴀɴᴋs ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ : " +str(ginfo.name))
                cl.sendMessage(op.param1,"")

        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if (wait["message1"] in [" "," ","\n",None]):
                        pass
                    else:
                        sendTextTemplate003(op.param1, "Terimakasih atas addnya\n ♻️♻️:NEW PROMO:♻️♻️\n \n \n \n ♻️:Edit flex full animated\n \n ♻️: Pembuatan flex animated\n \n ♻️:Jasa Ambil link gift\n \n ♻️Edit cover grup dll\n \n ♻️:Login sb template\n \n ♻️:Login sb ajs\n \n│http://wa.me/+6285707063716")

        if op.type == 13:
            if mid in op.param3:
               if wait["autoReject"] == True:
                   if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                       cl.rejectGroupInvitation(op.param1)

        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                try:
                    random.choice(KAC).cancelGroupInvitation(op.param1,[op.param3])
                    random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    wait["blacklist"][op.param2] = True
                except:
                    try:
                        group = cl.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _dn in gMembMids:
                          if _dn in wait["blacklist"]:
                            random.choice(KAC).cancelGroupInvitation(op.param1,[_dn])
                    except:
                        random.choice(KAC).cancelGroupInvitation(op.param1,[op.param3])
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        wait["blacklist"][op.param2] = True
                        
            if op.param3 in wait["blacklist"]:
                try:
                    random.choice(KAC).cancelGroupInvitation(op.param1,[op.param3])
                    random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    wait["blacklist"][op.param2] = True
                except:
                    try:
                        group = cl.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _dn in gMembMids:
                          if _dn in wait["blacklist"]:
                            random.choice(KAC).cancelGroupInvitation(op.param1,[_dn])
                    except:
                        random.choice(KAC).cancelGroupInvitation(op.param1,[op.param3])
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        wait["blacklist"][op.param2] = True

        if op.type == 17:
            if op.param2 in wait["blacklist"]:
               try:
                   random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                   cl.sendMessage(op.param1,"Kamu Habis nakal yoo..")
               except:
                   pass

        if op.type == 17:
            if op.param1 in protectjoin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                        	cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
#===============================#
                return
        if op.type == 19:
            if op.param1 in protectkick:
                if op.param2 in Bots or op.param2 in owner or op.param2 in admin or op.param2 in staff:
                    pass
                else:
                    try:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            wait["blacklist"][op.param2] = True
                            if op.param3 not in wait["blacklist"]:
                                try:
                                    cl.kickoutFromGroup(op.param1,[op.param2])
                                    cl.findAndAddContactsByMid(op.param3)
                                    cl.inviteIntoGroup(op.param1,[op.param3])
                                    cl.inviteIntoGroup(op.param1,[Amid])
                                    k1.acceptGroupInvitation(op.param1)
                                except:
                                    pass
                            else:pass
                        else:pass
                    except:
                        pass
                        
        if op.type == 19:
            if op.param1 in protectkick:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True                   
                    cl.kickoutFromGroup(op.param1,[op.param2]) 
                    cl.inviteIntoGroup(op.param1,[Amid])         
                    k1.acceptGroupInvitation(op.param1)
                else:
                	pass 
                
        if op.type == 19 or op.type == 32:
            if mid in op.param3:
            	if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                         k1.acceptGroupInvitation(op.param1)
                         sw.acceptGroupInvitation(op.param1)
                         k1.kickoutFromGroup(op.param1,[op.param2])
                         sw.inviteIntoGroup(op.param1,[mid])
                         cl.acceptGroupInvitation(op.param1)
                         k1.leaveGroup(op.param1)
                         sw.leaveGroup(op.param1)
                         cl.inviteIntoGroup(op.param1,[Amid,Zmid])
                         wait["blacklist"][op.param2] = True
                    except:
                    	pass

        if op.type == 19:
            if Amid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        random.choice(KAC).inviteIntoGroup(op.param1,[Amid])
                        k1.acceptGroupInvitation(op.param1)                        
                        k1.inviteIntoGroup(op.param1,[mid])
                        cl.acceptGroupInvitation(op.param1)
                    except:
                        pass
                                
        if op.type == 19:
            if Zmid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        random.choice(KAC).inviteIntoGroup(op.param1,[Zmid])
                        sw.acceptGroupInvitation(op.param1)
                    except:
                        pass

        if op.type == 32:
            if op.param1 in protectcancel:
              if op.param3 in Bots:    
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            cl.inviteIntoGroup(op.param1,[Amid,Zmid])
                    except:
                        pass
         
        if op.type == 32:
            if op.param1 in protectcancel:
              if op.param3 in Bots:    
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param2 not in wait["blacklist"]:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            cl.inviteIntoGroup(op.param1,[Amid,Zmid])
                    except:
                        pass
                        	
        if op.type == 32:
            if op.param3 in Amid:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                  wait["blacklist"][op.param2] = True
                  try:
                      if op.param3 not in wait["blacklist"]:
                          cl.kickoutFromGroup(op.param1,[op.param2])
                          cl.inviteIntoGroup(op.param1,[Amid])
                          cl.sendMessage(op.param1,"weh napa dicancel...")
                  except:
                      pass
                        	
        if op.type == 32:
            if op.param3 in Zmid:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                  wait["blacklist"][op.param2] = True
                  try:
                      if op.param3 not in wait["blacklist"]:
                          cl.kickoutFromGroup(op.param1,[op.param2])
                          cl.inviteIntoGroup(op.param1,[Zmid])
                          cl.sendMessage(op.param1,"weh napa dicancel...")
                  except:
                      pass
        if op.type == 32:
            if wait["backup"] == True:
              if op.param3 in Bots:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                           k1.acceptGroupInvitation(op.param1)
                           sw.acceptGroupInvitation(op.param1)
                           random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                           random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                           sw.leaveGroup(op.param1)
                           k1.leaveGroup(op.param1)
                           cl.inviteIntoGroup(op.param1,[Amid,Zmid])
                    except:
                    	pass
                return

        if op.type == 19 or op.type == 32:
            if mid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in creator:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        cl.acceptGroupInvitation(op.param1)
                        cl.inviteIntoGroup(op.param1,[op.param3])
                        cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                    	pass
                return

        if op.type == 19 or op.type == 32:
            if op.param3 in creator:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                cl.findAndAddContactsByMid(op.param3)
                cl.inviteIntoGroup(op.param1,[op.param3])
                cl.kickoutFromGroup(op.param1,[op.param2])
                wait["blacklist"][op.param2] = True

        if op.type == 19 or op.type == 32:
            if op.param3 in admin:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                cl.findAndAddContactsByMid(op.param3)
                cl.inviteIntoGroup(op.param1,[op.param3])
                cl.kickoutFromGroup(op.param1,[op.param2])
                wait["blacklist"][op.param2] = True

        if op.type == 55:            
            try:
                if op.param1 in read["readPoint"]:
                    if op.param2 in read["readMember"][op.param1]:
                        pass
                    else:
                        read["readMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass
                
        if op.type == 55:
            if op.param2 in wait["blacklist"]:
               try:
                   cl.kickoutFromGroup(op.param1,[op.param2])
                   cl.sendMessage(op.param1,"Kang js kena bL")
               except:
                   pass
#========Ajs back========#
        if op.type == 32:
            if op.param3 in Zmid:
              if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                  wait["blacklist"][op.param2] = True
                  try:
                      xyz = cl.getGroup(op.param1)
                      if xyz.invitee == None:pends = []
                      else:pends = [c.mid for c in xyz.invitee]
                      targp = []
                      for x in pends:
                    	  if x in Zmidbl["blacklist"]:
                    	      targp.append(x)
                      cms = 'dual.js gid={} token={}'.format(op.param1, cl.authToken)
                      mems = [c.mid for c in xyz.members]
                      targk = []
                      for x in mems:
                    	  if x in Zmidbl["blacklist"]:
                    	      targk.append(x)
                      for y in targp:
                    	  cms += ' uid={}'.format(y)
                      for y in targk:
                    	  cms += ' uik={}'.format(y)
                      print(cms)
                      success = execute_js(cms)
                      cl.inviteIntoGroup(op.param1, owner)
                  except:
                	  pass
                  return
#==========bts===========#
        if op.type == 65:
            if wait["Unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'ɢᴀᴍʙᴀʀʏᴀ ɪʟᴀɴɢ':
                                ginfo = cl.getGroup(at)
                                ika = cl.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "ᴘᴇsᴀɴ ᴅɪʜᴀᴘᴜs\nᴘᴇɴɢɪʀɪᴍ: "
                                ret_ = "ɴᴀᴍᴀ ɢʀᴜᴘ: {}".format(str(ginfo.name))
                                ret_ += "\nᴊᴀᴍ sʜᴀʀᴇ: {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ik = str(ika.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ika.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                cl.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                           else:
                                ginfo = cl.getGroup(at)
                                ika = cl.getContact(msg_dict[msg_id]["from"])
                                ika1 = "🚹{}".format(str(ika.displayName))
                                ika2 = "🏠:{}".format(str(ginfo.name))
                                ika3 = "🕙{}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                seber = "═══「 ᴘᴇsᴀɴ ᴅɪʜᴀᴘᴜs 」═══\n{}".format(str(msg_dict[msg_id]["text"]))
                                data = {
                                        "type": "flex",
                                        "altText": "pesan unsend",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#0000ff"
    },
    "footer": {
      "backgroundColor": "#2f2f4f"
    }
  },
  "type": "bubble",
 "size": "micro",
      "body": {
  "contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#33ffff"            
      },
      {
        "type": "separator",
        "color": "#33ffff"  
      },
      {         
         "contents": [
          {
          "type": "separator",
          "color": "#33ffff"   
      },
      {
            "contents": [
              {
              "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          },{
 "type": "text",
"text": "sᴇʟғʙᴏᴛ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ᴛᴇᴍᴘʟᴀᴛᴇ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ᴠᴇʀsɪ³",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
            "text": "📧📧📧",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🖼️🖼️🖼️",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "📧📧??",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         },
         {
       "contents": [
          {
           "type": "separator",
           "color": "#33ffff"
          },
          {
          "url": "https://obs.line-scdn.net/{}".format(str(ika.pictureStatus)),
            "type": "image",
            "size": "xxs",
            "flex": 0
          },
          {
        "type": "separator",
        "color": "#33ffff"
      },
      {      
       "contents": [              
          {
"type": "text",
"text": ika1,
"weight": "bold",
"color": "#33ffff",
"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#33ffff"
},{
"type": "text",
"text": ika3, #"🕙"+ datetime.strftime(timeNow,'%H:%M:%S'+"🕙"),
"weight": "bold",
"color": "#ccffff",
#"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#33ffff"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"
      },
      {
        "type": "separator",
         "color": "#33ffff"
       },
       {     
       "contents": [           
         { 
           "type": "separator",
           "color": "#33ffff"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#33ffff"
            },
           {
          "type": "text",
"text": ika2, #"{}".format(cl.getContact(mid).displayName),
"weight": "bold",
"color": "#ffff00",
#"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {          
         "contents": [
         { 
           "type": "separator",
           "color": "#33ffff"
            },
           {
            "contents": [
              {
              "type": "separator",
           "color": "#33ffff"
            },
           {
          "text": seber,
           "size": "xxs",
       #   "align": "center",
           "color": "#00ff00",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
       "contents": [
         {
        "type": "separator",
        "color": "#33ffff"
         },
         {
            "text": "📧📧📧",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "🖼️🖼️🖼️",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"
            },{
            "type": "separator",
            "color": "#33ffff"
           },
             {
            "text": "📧📧📧",
            "size": "xxs",
            "color": "#FF9900",
            "align": "center",
            "wrap": True,
            "weight": "bold",
            "type": "text"   
          },
         {
        "type": "separator",
        "color": "#33ffff"
         }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         },
         {
      "contents": [
          {
            "type": "separator",
            "color": "#33ffff"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com",
           }, 
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://wa.me/+6285707063716",             
           }, 
            "flex": 1            
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/ZHtFDts/20190427-185307.png", #chathttps://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/chat" #"http://line.me/ti/p/~bancat525",
            },         
            "flex": 1          
            },
          {
          "type": "image",
            "url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/_BowWow",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
          },
            "flex": 1           
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#33ffff"
        },{
        "contents": [         
              {
            "type": "separator",
            "color": "#33ffff"
            },
             {          
            "contents": [
               {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
    },{
 "type": "text",
"text": "ᴛʜᴀɴᴋᴢ ғᴏʀ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "sᴜᴘᴏʀᴛ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ᴛᴇᴀᴍ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
    "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#33ffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator", #batas APK
        "color": "#33ffff"     
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
                                cl.postTemplate(at, data)
                                cl.sendImage(at, msg_dict[msg_id]["data"])
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 65:
            if wait["Unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "╔══「✯sᴛɪᴄᴋᴇʀ ɪɴғᴏ✯」\n"
                                ret_ += "┣[]►??: {}".format(str(ryan.displayName))
                                ret_ += "\n┣[]►🏠: {}".format(str(ginfo.name))
                                ret_ += "\n┣[]►🕘: {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "\n╚══「✯ᴜɴsᴇɴᴅ ғɪɴɪsʜ✯」"
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                sendTextTemplate2(at, str(ret_))
                                cl.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)
        if op.type in [26]:
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0 and msg.toType == 0:
                if wait["Busy"] == True:
                   putra = cl.getContact(msg._from)
                   mids = [putra.mid]
                   a = ['Maaf q Sibuk','Coba pm sesaat kemudian','Hubungi pemadam api Terdekat 😁','Anda belum beruntung🤣']
                   b = random.choice(a)
                   cl.sendMention(to, b,mids)
        
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != cl.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    msg_dict[msg.id] = {"text": msg.text, "from": msg._from, "createdTime": msg.createdTime, "contentType": msg.contentType, "contentMetadata": msg.contentMetadata}
                if msg.contentType == 1:
                    path = cl.downloadObjectMsg(msg_id)
                    msg_dict[msg.id] = {"text":'ɢᴀᴍʙᴀʀʏᴀ ᴅɪʙᴀᴡᴀʜ',"data":path,"from":msg._from,"createdTime":msg.createdTime}
                if msg.contentType == 7:
                   stk_id = msg.contentMetadata["STKID"]
                   stk_ver = msg.contentMetadata["STKVER"]
                   pkg_id = msg.contentMetadata["STKPKGID"]
                   ret_ = "\n╔══「✯sᴛɪᴄᴋᴇʀ ɪɴғᴏ✯]"
                   ret_ += "\n┣[]►sᴛɪᴄᴋᴇʀ ɪᴅ: {}".format(stk_id)
                   ret_ += "\n┣[]►sᴛɪᴄᴋᴇʀ ᴠᴇʀsɪᴏɴ: {}".format(stk_ver)
                   ret_ += "\n┣[]►sᴛɪᴄᴋᴇʀ: {}".format(pkg_id)
                   ret_ += "\n┣[]►ᴜʀʟ:{}".format(pkg_id)
                   ret_ += "\n╚══「✯ᴜɴsᴇɴᴅ ғɪɴɪsʜ✯」"
                   query = int(stk_id)
                   if type(query) == int:
                            data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                            path = cl.downloadFileURL(data)
                            msg_dict1[msg.id] = {"text":str(ret_),"data":path,"from":msg._from,"createdTime":msg.createdTime}
#____________________________________________________________________
        if op.type == 17:
           #if op.param1 in welcome:
             if wait["welcomeOn"] == True:
             #   cl.updateGroup(group)
                contact = cl.getContact(op.param2)
                cover = cl.getProfileCoverURL(op.param2)
                welcomeMembers(op.param1, [op.param2])
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                data = {     
                                "type": "flex",
                                "altText": "assalamualaikum",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:2",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "26px",
                    "height": "26px",
                    "cornerRadius": "100px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "28px",
                "height": "28px",
                "cornerRadius": "100px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "WELCOME",
                        "size": "xxs",
                        "color": "#ff0000",
                         "offsetTop": "-2px",
                        "offsetStart": "20px"
                      }
                    ],
                    "position": "absolute",
                    "width": "98px",
                    "height": "12px",
                    "backgroundColor": "#000000",
                    "cornerRadius": "8px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "14px",
                "offsetTop": "13px",
                "offsetStart": "30px",
                "cornerRadius": "10px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:3",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:3",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "48px",
                    "height": "58px",
                    "offsetTop": "1px",
                    "offsetStart": "1px",
                    "cornerRadius": "3px"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "60px",
                "cornerRadius": "5px",
                "offsetTop": "32px",
                "offsetStart": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "👥:{}".format(cl.getContact(op.param2).displayName),
                        "size": "xxs",
                        "color": "#ffffff",
                        "offsetTop": "-1px",
                        "offsetStart": "1px"
                      }
                    ],
                    "position": "absolute",
                    "width": "98px",
                    "height": "12px",
                    "backgroundColor": "#000000",
                    "cornerRadius": "3px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "14px",
                "cornerRadius": "5px",
                "offsetTop": "32px",
                "offsetStart": "52px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "⏰:"+ datetime.strftime(timeNow,'%H:%M:%S'),
                        "size": "xxs",
                        "color": "#ffffff",
                        "offsetTop": "-1px",
                        "offsetStart": "1px"
                      }
                    ],
                    "position": "absolute",
                    "width": "98px",
                    "height": "12px",
                    "backgroundColor": "#000000",
                    "cornerRadius": "3px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "14px",
                "cornerRadius": "5px",
                "offsetTop": "46px",
                "offsetStart": "52px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "📅:"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                        "size": "xxs",
                        "color": "#ffffff",
                        "offsetTop": "-1px",
                        "offsetStart": "1px"
                      }
                    ],
                    "position": "absolute",
                    "width": "98px",
                    "height": "12px",
                    "backgroundColor": "#000000",
                    "cornerRadius": "3px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "14px",
                "cornerRadius": "5px",
                "offsetTop": "60px",
                "offsetStart": "52px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "SELAMAT DATANG LUR",
                        "size": "xxs",
                        "color": "#ffffff",
                        "offsetTop": "-1px",
                        "offsetStart": "1px"
                      }
                    ],
                    "position": "absolute",
                    "width": "98px",
                    "height": "12px",
                    "backgroundColor": "#000000",
                    "cornerRadius": "3px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "14px",
                "cornerRadius": "5px",
                "offsetTop": "74px",
                "offsetStart": "52px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "96px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "8px",
            "offsetTop": "1px",
            "offsetStart": "1px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/Xkwc61k/ezgif-com-gif-maker-2.png",
                "size": "sm",
                "aspectRatio": "2:2",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "100px",
            "offsetTop": "0px",
            "offsetStart": "0px"
          }
        ],
        "paddingAll": "0px",
        "height": "100px",
        "cornerRadius": "10px",
        "borderWidth": "1px",
        "borderColor": "#000000"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                cl.postTemplate(op.param1, data)
        if op.type == 15:
           #if op.param1 in welcome:
             if wait["leaveMsg"] == True:
             #   cl.updateGroup(group)
                contact = cl.getContact(op.param2)
                cover = cl.getProfileCoverURL(op.param2)
                welcomeMembers(op.param1, [op.param2])
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                data = {     
                                "type": "flex",
                                "altText": "innalilahi",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:2",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "26px",
                    "height": "26px",
                    "cornerRadius": "100px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "28px",
                "height": "28px",
                "cornerRadius": "100px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "MEMBER LEFT",
                        "size": "xxs",
                        "color": "#ff0000",
                        "offsetTop": "-2px",
                        "offsetStart": "20px"
                      }
                    ],
                    "position": "absolute",
                    "width": "98px",
                    "height": "12px",
                    "backgroundColor": "#000000",
                    "cornerRadius": "8px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "14px",
                "offsetTop": "13px",
                "offsetStart": "30px",
                "cornerRadius": "10px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:3",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:3",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "48px",
                    "height": "58px",
                    "offsetTop": "1px",
                    "offsetStart": "1px",
                    "cornerRadius": "3px"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "60px",
                "cornerRadius": "5px",
                "offsetTop": "32px",
                "offsetStart": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "👥:{}".format(cl.getContact(op.param2).displayName),
                        "size": "xxs",
                        "color": "#ffffff",
                        "offsetTop": "-1px",
                        "offsetStart": "1px"
                      }
                    ],
                    "position": "absolute",
                    "width": "98px",
                    "height": "12px",
                    "backgroundColor": "#000000",
                    "cornerRadius": "3px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "14px",
                "cornerRadius": "5px",
                "offsetTop": "32px",
                "offsetStart": "52px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "⏰:"+ datetime.strftime(timeNow,'%H:%M:%S'),
                        "size": "xxs",
                        "color": "#ffffff",
                        "offsetTop": "-1px",
                        "offsetStart": "1px"
                      }
                    ],
                    "position": "absolute",
                    "width": "98px",
                    "height": "12px",
                    "backgroundColor": "#000000",
                    "cornerRadius": "3px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "14px",
                "cornerRadius": "5px",
                "offsetTop": "46px",
                "offsetStart": "52px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "📅:"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                        "size": "xxs",
                        "color": "#ffffff",
                        "offsetTop": "-1px",
                        "offsetStart": "1px"
                      }
                    ],
                    "position": "absolute",
                    "width": "98px",
                    "height": "12px",
                    "backgroundColor": "#000000",
                    "cornerRadius": "3px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "14px",
                "cornerRadius": "5px",
                "offsetTop": "60px",
                "offsetStart": "52px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "BAPERAN LEAVE AJA",
                        "size": "xxs",
                        "color": "#ffffff",
                        "offsetTop": "-1px",
                        "offsetStart": "1px"
                      }
                    ],
                    "position": "absolute",
                    "width": "98px",
                    "height": "12px",
                    "backgroundColor": "#000000",
                    "cornerRadius": "3px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "14px",
                "cornerRadius": "5px",
                "offsetTop": "74px",
                "offsetStart": "52px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "96px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "8px",
            "offsetTop": "1px",
            "offsetStart": "1px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/Xkwc61k/ezgif-com-gif-maker-2.png",
                "size": "sm",
                "aspectRatio": "2:2",
                "aspectMode": "cover"
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "100px",
            "offsetTop": "0px",
            "offsetStart": "0px"
          }
        ],
        "paddingAll": "0px",
        "height": "100px",
        "cornerRadius": "10px",
        "borderWidth": "1px",
        "borderColor": "#000000"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                cl.postTemplate(op.param1, data)

        #===cctv
        if op.type == 55:
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        contact = cl.getContact(op.param2)
                        cover = cl.getProfileCoverURL(op.param2)
                        tz = pytz.timezone("Asia/Jakarta")
                        timeNow = datetime.now(tz=tz)
                        warna1 = ("#00ff00","#ffff00","#0000ff","#ff00ff","#00FFFF","#800000","#FF7F00","#BF00FF")
                        warnanya1 = random.choice(warna1)
                        foto1 = ("https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png","https://i.ibb.co/Xs9Jtyr/ezgif-com-gif-maker.png","https://i.ibb.co/r4NMzr2/ezgif-com-gif-maker-1.png","https://i.ibb.co/rFfr3N4/ezgif-com-gif-maker-2.png","https://i.ibb.co/2WwgNBX/ezgif-com-gif-maker-3.png")
                        foto2 = ("https://i.ibb.co/y6cdp2X/ezgif-com-gif-maker-3.png","https://i.ibb.co/sjcgTHr/ezgif-com-gif-maker-4.png","https://i.ibb.co/2jvwXdf/ezgif-com-gif-maker-5.png","https://i.ibb.co/CstR9Q1/ezgif-com-gif-maker-6.png","https://i.ibb.co/RBW4LBr/ezgif-com-gif-maker-7.png")
                        f1 = random.choice(foto1)
                        f2 = random.choice(foto2)
                        foto3 = ("https://i.ibb.co/DYBJ14f/ezgif-com-gif-maker-1.png","https://i.ibb.co/023DpDP/ezgif-com-gif-maker-2.png","https://i.ibb.co/KLC3FjS/ezgif-com-gif-maker-3.png")
                        foto4 = ("https://i.ibb.co/y6cdp2X/ezgif-com-gif-maker-3.png","https://i.ibb.co/sjcgTHr/ezgif-com-gif-maker-4.png","https://i.ibb.co/2jvwXdf/ezgif-com-gif-maker-5.png","https://i.ibb.co/CstR9Q1/ezgif-com-gif-maker-6.png","https://i.ibb.co/RBW4LBr/ezgif-com-gif-maker-7.png")
                        f3 = random.choice(foto1)
                        f4 = random.choice(foto2)
                        data = {     
                                "type": "flex",
                                "altText": "Tertangkap kamera",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/kcxnLKc/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:1",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/4YrS5Cv/ezgif-com-gif-maker-4.png",
                "size": "full",
                "aspectRatio": "2:1",
                "aspectMode": "cover",
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/DYBJ14f/ezgif-com-gif-maker-1.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "40px",
                    "height": "40px",
                    "cornerRadius": "100px",
                    "borderWidth": "1px",
                    "borderColor": warnanya1,
                    "offsetTop": "10px",
                    "offsetStart": "10px"
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "60px",
                "cornerRadius": "100px",
                "offsetTop": "0px",
                "offsetStart": "-7px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/DYBJ14f/ezgif-com-gif-maker-1.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": cover,
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "40px",
                    "height": "40px",
                    "borderWidth": "1px",
                    "borderColor": warnanya1,
                    "cornerRadius": "100px",
                    "offsetTop": "10px",
                    "offsetStart": "10px"
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "60px",
                "cornerRadius": "100px",
                "offsetTop": "0px",
                "offsetEnd": "-7px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "time:"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "bold",
                    "style": "normal"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "15px",
                "backgroundColor": "#ff0000",
                "borderWidth": "1px",
                "borderColor": warnanya1,
                "cornerRadius": "5px",
                "offsetTop": "1px",
                "offsetStart": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "⏰:"+ datetime.strftime(timeNow,'%H:%M'),
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "bold",
                    "style": "normal"
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "15px",
                "backgroundColor": "#0000ff",
                "borderWidth": "1px",
                "borderColor": warnanya1,
                "cornerRadius": "5px",
                "offsetTop": "17px",
                "offsetStart": "46px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "{}".format(cl.getContact(op.param2).displayName),
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "4px"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "15px",
                "cornerRadius": "5px",
                "offsetTop": "33px",
                "offsetStart": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Nah Keciduk 😂",
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "1px",
                    "offsetStart": "2px"
                  }
                ],
                "position": "absolute",
                "width": "156px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": warnanya1,
                "cornerRadius": "5px",
                "offsetTop": "53px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "76px",
            "borderWidth": "2px",
            "borderColor": warnanya1,
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": f2,
                "size": "md",
                "aspectRatio": "2:2",
                "aspectMode": "cover",
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "80px",
            "offsetTop": "0px",
            "offsetStart": "0px"
          }
        ],
        "paddingAll": "0px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                        cl.postTemplate(op.param1, data)

        #===cctv
        if op.type == 55:
            if cctm['cyduk1'][op.param1]==True:
                if op.param1 in cctm['point1']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctm['sidermem1'][op.param1]:
                        pass
                    else:
                        cctm['sidermem1'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        contact = cl.getContact(op.param2)
                        cover = cl.getProfileCoverURL(op.param2)
                        tz = pytz.timezone("Asia/Jakarta")
                        timeNow = datetime.now(tz=tz)
                        warna1 = ("#00ff00","#ffff00","#0000ff","#ff00ff","#00FFFF","#800000","#FF7F00","#BF00FF")
                        warnanya1 = random.choice(warna1)
                        kata1 = ("Ngintip aja loe","sini kakak gabung kita","kerjaannya ngintip bae bunting kapok","peluk sini sayang dari pada ngintip bae","cctv i love you muah muah")
                        katanya1 = random.choice(kata1)
                        foto1 = ("https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png","https://i.ibb.co/Xs9Jtyr/ezgif-com-gif-maker.png","https://i.ibb.co/r4NMzr2/ezgif-com-gif-maker-1.png","https://i.ibb.co/rFfr3N4/ezgif-com-gif-maker-2.png","https://i.ibb.co/2WwgNBX/ezgif-com-gif-maker-3.png")
                        foto2 = ("https://i.ibb.co/sjcgTHr/ezgif-com-gif-maker-4.png","https://i.ibb.co/2jvwXdf/ezgif-com-gif-maker-5.png","https://i.ibb.co/CstR9Q1/ezgif-com-gif-maker-6.png","https://i.ibb.co/RBW4LBr/ezgif-com-gif-maker-7.png","https://i.ibb.co/S3rvN6v/ezgif-com-gif-maker-1.png","https://i.ibb.co/fv78YKD/ezgif-com-gif-maker-2.png","https://i.ibb.co/y6cdp2X/ezgif-com-gif-maker-3.png")
                        f1 = random.choice(foto1)
                        f2 = random.choice(foto2)
                        data = {
                                "type": "flex",
                                "altText": "Tertangkap cctv",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/8MKgPwd/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:2",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "SIDER GROUP",
                    "size": "xs",
                    "color": "#ffffcc",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "30px"
                  }
                ],
                "position": "absolute",
                "width": "148px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "5px",
                "offsetTop": "1px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "⏰:"+ datetime.strftime(timeNow,'%H:%M:%S'),
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "regular"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "15px",
                "backgroundColor": "#0000ff",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "3px",
                "offsetTop": "22px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "📅:"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "regular"
                  }
                ],
                "position": "absolute",
                "width": "80px",
                "height": "15px",
                "backgroundColor": "#ff0000",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "3px",
                "offsetTop": "22px",
                "offsetEnd": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "70px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "2px",
                "offsetTop": "38px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": cover,
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "70px",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "2px",
                "offsetTop": "38px",
                "offsetEnd": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Nama:{}".format(cl.getContact(op.param2).displayName),
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "regular"
                  }
                ],
                "position": "absolute",
                "width": "148px",
                "height": "15px",
                "backgroundColor": "#bbcf00",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "3px",
                "offsetTop": "105px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": katanya1,
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "regular",
                    "offsetStart": "4px"
                  }
                ],
                "position": "absolute",
                "width": "148px",
                "height": "18px",
                "backgroundColor": "#bbcf00",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "3px",
                "offsetTop": "120px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": f2,
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "150px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/p0n6d89/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "150px",
                "height": "150px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "140px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "8px",
            "offsetTop": "3px",
            "offsetStart": "3px",
            "backgroundColor": "#03303acc"
          }
        ],
        "paddingAll": "0px",
        "height": "150px",
        "borderWidth": "2px",
        "borderColor": "#000000",
        "cornerRadius": "10px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                        cl.postTemplate(op.param1,data)
#========={{{{{MENTION}}}}}===========
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if settings ["Aip"] == True:
                if msg.text in [".tes","/malam","!otong","!curut","Cleanse","!cleanse",".cleanse","zona","!kickall",".kickall","/semangat","Ratakan","bubarkan","Nuke","nuke",".sapu","Bypass","#nenen",".bypass","#bypass","#jancok","hancurkan","!malam","/joss",".malam","bubar","Bubar","86"]:
                    cl.kickoutFromGroup(receiver,[sender])
            if wait["selfbot"] == True:
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          cl.kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              cl.kickoutFromGroup(msg.to, [msg._from])
                          except:
                              try:
                                  cl.kickoutFromGroup(msg.to, [msg._from])
                              except:
                                  try:
                                  	cl.kickoutFromGroup(msg.to, [msg._from])
                                  except:
                                      pass
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if wait["detectMention"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data = {
                                "type": "flex",
                                "altText": "Adventure",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/y8qYcrc/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "4:2",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "size": "full",
                "aspectRatio": "2:2",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "{} ".format(contact.displayName),
                    "size": "xxs",
                    "color": "#ff0000",
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "15px",
                "offsetTop": "35px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "width": "50px",
            "height": "50px",
            "borderWidth": "1px",
            "borderColor": "#ff0000",
            "cornerRadius": "5px",
            "offsetTop": "1px",
            "offsetStart": "1px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/YdckhVT/ezgif-com-gif-maker-3.png",
                "size": "xl",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-20px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "20px",
            "offsetTop": "32px",
            "offsetStart": "52px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "RESPON",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "70px",
            "height": "15px",
            "offsetTop": "1px",
            "offsetStart": "55px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "⏰"+ datetime.strftime(timeNow,'%H:%M:%S'),
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "80px",
            "height": "15px",
            "offsetTop": "13px",
            "offsetStart": "85px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/m01bc4N/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "2:2",
                "aspectMode": "cover",
              }
            ],
            "position": "absolute",
            "width": "20px",
            "height": "20px",
            "offsetTop": "20px",
            "offsetStart": "58px",
            "cornerRadius": "100px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "📅"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "100px",
            "height": "15px",
            "offsetTop": "27px",
            "offsetStart": "85px"
          }
        ],
        "paddingAll": "0px",
        "height": "60px",
        "borderWidth": "1px",
        "borderColor": "#ff0000",
        "cornerRadius": "10px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                           break
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                if msg._from not in Bots:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           sendTextTemplate1(msg.to,"j̸͟͞a̸͟͞n̸͟͞g̸͟͞a̸͟͞n̸͟͞ t̸͟͞a̸͟͞g̸͟͞ g̸͟͞u̸͟͞a̸͟͞ n̸͟͞a̸͟͞n̸͟͞t̸͟͞i̸͟͞ k̸͟͞e̸͟͞j̸͟͞i̸͟͞t̸͟͞a̸͟͞k̸͟͞")
                           cl.kickoutFromGroup(msg.to, [msg._from])
                           break
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if wait["detectMention2"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data = {
                                "type": "flex",
                                "altText": "Transfer file",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/kG1XcH8/ezgif-com-gif-maker-3.png",
                "size": "full",
                "aspectRatio": "2:6",
                "aspectMode": "cover",
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/C9rVynb/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:6",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "140px",
                "height": "420px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "420px",
            "borderWidth": "1px",
            "borderColor": "#ccbbbb",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "38px",
                    "height": "38px",
                    "cornerRadius": "3px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "width": "40px",
                "height": "40px",
                "offsetTop": "2px",
                "offsetStart": "3px",
                "cornerRadius": "3px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/Jk9Pkf8/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "6:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "👥:{}".format(contact.displayName),
                        "size": "xxs",
                        "color": "#ffffff",
                        "weight": "bold",
                        "style": "italic",
                        "offsetTop": "2px",
                        "offsetStart": "2px"
                      }
                    ],
                    "position": "absolute",
                    "width": "103px",
                    "height": "20px",
                    "backgroundColor": "#0000ff",
                    "borderWidth": "1px",
                    "borderColor": "#000000",
                    "cornerRadius": "3px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "105px",
                "height": "22px",
                "offsetTop": "20px",
                "offsetStart": "42px",
                "cornerRadius": "3px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "RESPON TAG2",
                    "size": "xs",
                    "color": "#ff00ff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "10px"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "20px",
                "offsetTop": "2px",
                "offsetStart": "45px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "46px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "428px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                           break
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if wait["detectMention3"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data ={
                                "type": "flex",
                                "altText": "file diterima",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "kilo",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/jL4PSkw/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/kG1XcH8/ezgif-com-gif-maker-3.png",
                "size": "full",
                "aspectRatio": "8:3",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                    "size": "full",
                    "aspectRatio": "3:3",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "90px",
                "height": "80px",
                "offsetTop": "6px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/VTbqbfS/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "90px",
                "height": "90px",
                "borderWidth": "1px",
                "borderColor": "#ccbbcc",
                "cornerRadius": "5px",
                "offsetTop": "2px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "RESPON TAG3 ",
                    "size": "xs",
                    "color": "#ffcc00",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "20px",
                    "offsetTop": "1px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/NSZp2hg/ezgif-com-gif-maker-1.png",
                        "size": "sm",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover",
                        "offsetTop": "-15px"
                      }
                    ],
                    "position": "absolute",
                    "width": "50px",
                    "height": "20px",
                    "offsetEnd": "0px"
                  }
                ],
                "position": "absolute",
                "width": "158px",
                "height": "20px",
                "backgroundColor": "#ffffff",
                "borderWidth": "1px",
                "borderColor": "#000000",
                "cornerRadius": "5px",
                "offsetTop": "1px",
                "offsetEnd": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/jL4PSkw/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "8:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "⏰:"+ datetime.strftime(timeNow,'%H:%M:%S'),
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic"
                      }
                    ],
                    "position": "absolute",
                    "width": "70px",
                    "height": "12px",
                    "backgroundColor": "#0000ff",
                    "offsetTop": "1px",
                    "offsetStart": "1px",
                    "cornerRadius": "5px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "📅:"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                        "size": "xxs",
                        "color": "#000000",
                        "weight": "bold",
                        "style": "italic"
                      }
                    ],
                    "position": "absolute",
                    "width": "83px",
                    "height": "12px",
                    "backgroundColor": "#ff0000",
                    "cornerRadius": "5px",
                    "offsetTop": "1px",
                    "offsetStart": "73px"
                  }
                ],
                "position": "absolute",
                "width": "158px",
                "height": "14px",
                "cornerRadius": "5px",
                "offsetTop": "22px",
                "offsetEnd": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/jL4PSkw/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "8:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "👥:{}".format(contact.displayName),
                        "size": "xs",
                        "color": "#ffffff",
                        "weight": "bold",
                        "style": "italic",
                        "offsetStart": "3px"
                      }
                    ],
                    "position": "absolute",
                    "width": "156px",
                    "height": "18px",
                    "backgroundColor": "#000000",
                    "cornerRadius": "5px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "158px",
                "height": "20px",
                "cornerRadius": "5px",
                "offsetTop": "36px",
                "offsetEnd": "1px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/jL4PSkw/ezgif-com-gif-maker.png",
                    "size": "full",
                    "aspectRatio": "8:2",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Nah kang tag minta didesahin ngetag mulu",
                        "size": "xxs",
                        "color": "#ffffff",
                        "weight": "bold",
                        "style": "italic",
                        "wrap": True,
                        "offsetStart": "2px"
                      }
                    ],
                    "position": "absolute",
                    "width": "156px",
                    "height": "28px",
                    "backgroundColor": "#000000",
                    "cornerRadius": "5px",
                    "offsetTop": "1px",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "158px",
                "height": "30px",
                "cornerRadius": "5px",
                "offsetTop": "60px",
                "offsetEnd": "1px"
              }
            ],
            "position": "absolute",
            "width": "254px",
            "height": "94px",
            "borderWidth": "1px",
            "borderColor": "#ccbbcc",
            "cornerRadius": "5px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/v4B1b8Z/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "6:3",
                "aspectMode": "cover",
              }
            ],
            "position": "absolute",
            "width": "260px",
            "height": "100px"
          }
        ],
        "paddingAll": "0px",
        "height": "100px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~doramy",
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                           break
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if wait["detectMention6"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data ={
                                "type": "flex",
                                "altText": "kode qr Terbuka",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/tMhnGgQ/ezgif-com-gif-maker-3.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
            "offsetTop": "-20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Ojo tag wae ngeyel jewer",
                "size": "xs",
                "color": "#000000",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "offsetTop": "190px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(contact.displayName),
                "size": "xs",
                "color": "#000000",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "offsetTop": "210px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                           break
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if wait["detectMention4"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           timeNow = datetime.now(tz=tz)
                           warna1 = ("#00ff00","#C0C0C0","#ffff00","#0000ff","#ff00ff","#00FFFF","#800000","#FF7F00","#BF00FF")
                           warnanya1 = random.choice(warna1)
                           data = {
                                "type": "flex",
                                "altText": "membagikan foto",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "kilo",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://i.ibb.co/VLdrdQq/20210622-000521.jpg",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                "size": "full",
                "aspectRatio": "2:3",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/1MtTKGV/ezgif-com-gif-maker-1.png",
                    "size": "full",
                    "aspectRatio": "2:3",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "80px",
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "height": "80px",
            "width": "70px",
            "offsetTop": "20px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "⏰:"+ datetime.strftime(timeNow,'%H:%M'),
                "size": "xxs",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "60px",
            "height": "15px",
            "offsetTop": "20px",
            "offsetStart": "83px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "📅:"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                "size": "xxs",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "80px",
            "height": "80px",
            "offsetTop": "20px",
            "offsetStart": "145px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/BC8wZcz/ezgif-com-gif-maker.png",
                "size": "xl",
                "aspectRatio": "12:4",
                "aspectMode": "cover",
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "60px",
            "offsetTop": "38px",
            "offsetStart": "80px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Nama:{} ".format(contact.displayName),
                "size": "xxs",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "250px",
            "height": "20px",
            "offsetTop": "103px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "RESPON4",
                "size": "xs",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "100px",
            "height": "20px",
            "offsetTop": "1px",
            "offsetStart": "90px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/s27pKM4/ezgif-com-gif-maker-2.png",
                "size": "full",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
              }
            ],
            "position": "absolute",
            "width": "260px",
            "height": "120px",
            "offsetTop": "0px",
            "offsetStart": "0px"
          }
        ],
        "paddingAll": "0px",
        "height": "120px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                           break
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if wait["detectMention5"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data ={
                                "type": "flex",
                                "altText": "Membagikan file",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/xS9HQkk/ezgif-com-gif-maker-4.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/01_1_cafe.png",
                    "size": "full",
                    "aspectRatio": "2:3",
                    "aspectMode": "cover"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:3",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "73px",
                    "height": "68px",
                    "offsetTop": "0px",
                    "offsetStart": "0px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:3",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "73px",
                    "height": "68px",
                    "offsetTop": "0px",
                    "offsetStart": "74px"
                  }
                ],
                "position": "absolute",
                "width": "149px",
                "height": "70px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "5px",
                "offsetTop": "2px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Respon5",
                    "size": "xxs",
                    "color": "#00ff00",
                    "weight": "bold",
                    "gravity": "top"
                  },
                  {
                    "type": "text",
                    "text": "{} ".format(contact.displayName),
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "20px",
                "offsetTop": "2px",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "{} ".format(contact.displayName),
                    "size": "xxs",
                    "color": "#0000ff",
                    "weight": "bold",
                    "gravity": "top"
                  }
                ],
                "position": "absolute",
                "width": "100px",
                "height": "20px",
                "offsetTop": "55px",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": ""+ datetime.strftime(timeNow,'%H:%M:%S'),
                    "size": "xxs",
                    "color": "#00ff00",
                    "weight": "bold",
                    "gravity": "top"
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "20px",
                "offsetTop": "2px",
                "offsetStart": "100px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [],
                "position": "absolute",
                "width": "100px",
                "height": "20px",
                "offsetTop": "57px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "height": "76px",
            "width": "155px",
            "borderWidth": "1px",
            "borderColor": "#000000",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px",
            "backgroundColor": "#000000"
          }
        ],
        "paddingAll": "0px",
        "height": "80px"
      }
    },
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/xS9HQkk/ezgif-com-gif-maker-4.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://i.ibb.co/52S6dFQ/06-07-47-04480c1db38387429fdfd024c63b667e.jpg",
                "size": "full",
                "aspectRatio": "2:3",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Apa seh tag Bae kangen ya",
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "bold",
                    "gravity": "top"
                  },
                  {
                    "type": "text",
                    "text": "Kalau kangen pm aja kita ",
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "bold",
                    "gravity": "top"
                  },
                  {
                    "type": "text",
                    "text": "Kita kojom terus pacaran",
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "bold",
                    "gravity": "top"
                  },
                  {
                    "type": "text",
                    "text": "putra selfbot",
                    "size": "xxs",
                    "color": "#ff0000",
                    "weight": "bold",
                    "gravity": "top",
                    "offsetTop": "3px",
                    "offsetStart": "70px"
                  }
                ],
                "position": "absolute",
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "156px",
            "height": "76px",
            "borderWidth": "4px",
            "borderColor": "#000000",
            "cornerRadius": "10px",
            "offsetTop": "2px",
            "offsetStart": "2px"
          }
        ],
        "paddingAll": "0px",
        "height": "80px"
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                           break
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if wait["detectMention7"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data ={
                                "type": "flex",
                                "altText": "Terus tag aja",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/nzNSsZn/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:3",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "71px",
                    "height": "100px",
                    "offsetTop": "0px",
                    "offsetStart": "0px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
                        "size": "full",
                        "aspectRatio": "2:3",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "71px",
                    "height": "100px",
                    "offsetTop": "0px",
                    "offsetStart": "71px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/nzNSsZn/ezgif-com-gif-maker.png",
                        "size": "full",
                        "aspectRatio": "6:2",
                        "aspectMode": "cover",
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Ada sayang ada aku selalu disini untukmu",
                            "size": "xxs",
                            "color": "#ffffff",
                            "weight": "bold",
                            "style": "italic",
                            "gravity": "top",
                            "offsetStart": "5px",
                            "wrap": True,
                          }
                        ],
                        "position": "absolute",
                        "width": "136px",
                        "height": "37px",
                        "backgroundColor": "#000000",
                        "borderWidth": "1px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "0px",
                        "offsetTop": "2px",
                        "offsetStart": "2px"
                      }
                    ],
                    "position": "absolute",
                    "width": "142px",
                    "height": "50px",
                    "borderWidth": "1px",
                    "borderColor": "#ff0000",
                    "cornerRadius": "0px",
                    "offsetTop": "100px",
                    "offsetStart": "0px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/zGHy4Bf/ezgif-com-gif-maker-2-1.png",
                        "size": "sm",
                        "aspectRatio": "6:2",
                        "aspectMode": "cover",
                      }
                    ],
                    "position": "absolute",
                    "width": "100px",
                    "height": "100px",
                    "offsetTop": "70px",
                    "offsetStart": "25px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "👥{}".format(contact.displayName),
                        "size": "xxs",
                        "color": "#ff0000",
                        "weight": "bold",
                        "style": "italic",
                        "gravity": "top"
                      },
                      {
                        "type": "separator",
                        "color": "#ff0000",
                        "margin": "xs"
                      }
                    ],
                    "position": "absolute",
                    "width": "142px",
                    "height": "20px",
                    "offsetTop": "80px",
                    "offsetStart": "5px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Respon7",
                        "size": "xxs",
                        "color": "#ff0000",
                        "weight": "bold",
                        "style": "italic",
                        "gravity": "top",
                        "offsetStart": "20px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "image",
                            "animated": True,
                            "url": "https://i.ibb.co/nzNSsZn/ezgif-com-gif-maker.png",
                            "size": "full",
                            "aspectRatio": "2:2",
                            "aspectMode": "cover",
                          }
                        ],
                        "position": "absolute",
                        "width": "10px",
                        "height": "10px",
                        "borderWidth": "1px",
                        "borderColor": "#000000",
                        "cornerRadius": "100px",
                        "offsetTop": "2px",
                        "offsetStart": "5px"
                      }
                    ],
                    "position": "absolute",
                    "width": "120px",
                    "height": "20px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "⏰"+ datetime.strftime(timeNow,'%H:%M:%S'),
                        "size": "xxs",
                        "color": "#ff0000",
                        "weight": "bold",
                        "style": "italic"
                      }
                    ],
                    "position": "absolute",
                    "width": "90px",
                    "height": "15px",
                    "offsetTop": "0px",
                    "offsetStart": "80px"
                  }
                ],
                "position": "absolute",
                "width": "144px",
                "height": "144px",
                "borderWidth": "1px",
                "borderColor": "#ff0000",
                "cornerRadius": "0px",
                "offsetTop": "2px",
                "offsetStart": "2px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "150px",
            "backgroundColor": "#111111",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "0px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure ™",
                "size": "xxs",
                "color": "#000000",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "80px",
            "height": "15px",
            "offsetEnd": "0px",
            "offsetTop": "148px"
          }
        ],
        "paddingAll": "0px",
        "height": "160px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://line.me/ti/p/~do1si",
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                           break
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if wait["detectMention8"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data ={
                                "type": "flex",
                                "altText": "RESPON TAG 8",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/5nwSnJd/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                    "size": "full",
                    "aspectRatio": "2:3",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "90px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "offsetTop": "2px",
                "offsetStart": "2px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "RESPON8",
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "10px",
                    "offsetTop": "3px"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "20px",
                "backgroundColor": "#00ff00",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "offsetTop": "2px",
                "offsetEnd": "3px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "⏰:"+ datetime.strftime(timeNow,'%H:%M:%S'),
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "3px"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "20px",
                "backgroundColor": "#ffff00",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "offsetTop": "25px",
                "offsetEnd": "3px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "??:"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "xxs",
                    "color": "#000000",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "3px"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "20px",
                "backgroundColor": "#ff0000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "offsetTop": "48px",
                "offsetEnd": "3px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "TDK_BOTZ",
                    "size": "xs",
                    "color": "#000000",
                    "weight": "bold",
                    "style": "italic",
                    "offsetStart": "1px"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "20px",
                "backgroundColor": "#0000ff",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "offsetTop": "71px",
                "offsetEnd": "3px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "👥{}".format(contact.displayName),
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "3px"
                  }
                ],
                "position": "absolute",
                "width": "144px",
                "height": "20px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "offsetTop": "94px",
                "offsetEnd": "3px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Ada apa seh tag aku mulu kangen ya?? Sini kalau kangen kita kojom yuk!!!!",
                    "size": "xs",
                    "offsetTop": "2px",
                    "offsetStart": "2px",
                    "wrap": True,
                    "weight": "bold",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "144px",
                "height": "58px",
                "backgroundColor": "#ffffff",
                "borderWidth": "1px",
                "borderColor": "#ff0000",
                "cornerRadius": "4px",
                "offsetTop": "117px",
                "offsetEnd": "2px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "180px",
            "borderWidth": "1px",
            "borderColor": "#ffffff",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/yWDBPDP/ezgif-com-gif-maker-6-1-1.png",
                "size": "full",
                "aspectRatio": "2:4",
                "aspectMode": "cover",
              }
            ],
            "position": "absolute",
            "width": "160px",
            "height": "190px",
            "offsetTop": "0px",
            "offsetStart": "0px"
          }
        ],
        "paddingAll": "0px",
        "height": "190px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                           break
               if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                 if wait["detectMention9"] == True:
                   contact = cl.getContact(msg._from)
                   tz = pytz.timezone("Asia/Jakarta")
                   timeNow = datetime.now(tz=tz)
                   cover = cl.getProfileCoverURL(sender)
                   name = re.findall(r'@(\w+)', msg.text)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in mid:
                           data ={
                                "type": "flex",
                                "altText": "RESPON 09",
                                "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/9NGJ4fd/ezgif-com-gif-maker-1.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:2",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/2PzJWmL/ezgif-com-gif-maker.png",
                "size": "xxl",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/2PzJWmL/ezgif-com-gif-maker.png",
                    "size": "xxl",
                    "aspectRatio": "8:3",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/F7kkchB/ezgif-com-gif-maker-4.png",
                        "size": "sm",
                        "aspectRatio": "6:4",
                        "aspectMode": "cover",
                        "offsetTop": "-20px"
                      }
                    ],
                    "position": "absolute",
                    "width": "146px",
                    "height": "26px",
                    "offsetTop": "0px",
                    "offsetStart": "0px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/cNNRQk4/ezgif-com-gif-maker.png",
                        "size": "sm",
                        "aspectRatio": "6:4",
                        "aspectMode": "cover",
                        "offsetTop": "-10px"
                      }
                    ],
                    "position": "absolute",
                    "width": "146px",
                    "height": "26px",
                    "offsetTop": "0px",
                    "offsetStart": "0px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/d2wWZL9/ezgif-com-gif-maker-2.png",
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover",
                      }
                    ],
                    "position": "absolute",
                    "width": "24px",
                    "height": "24px",
                    "borderWidth": "1px",
                    "borderColor": "#00ff00",
                    "cornerRadius": "2px",
                    "offsetTop": "0px",
                    "offsetStart": "1px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/d2wWZL9/ezgif-com-gif-maker-2.png",
                        "size": "full",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover",
                      }
                    ],
                    "position": "absolute",
                    "width": "24px",
                    "height": "24px",
                    "borderWidth": "1px",
                    "borderColor": "#00ff00",
                    "cornerRadius": "2px",
                    "offsetTop": "0px",
                    "offsetEnd": "1px"
                  }
                ],
                "position": "absolute",
                "width": "146px",
                "height": "26px",
                "borderWidth": "1px",
                "borderColor": "#00ff00",
                "cornerRadius": "3px",
                "offsetTop": "1px",
                "offsetStart": "3px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": ":"+ datetime.strftime(timeNow,'%H:%M:%S'),
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "18px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/yRWGpFs/ezgif-com-gif-maker-5.png",
                        "size": "md",
                        "aspectRatio": "2:2",
                        "aspectMode": "cover",
                        "offsetTop": "-2px",
                        "offsetStart": "2px"
                      }
                    ],
                    "position": "absolute",
                    "width": "18px",
                    "height": "18px",
                    "offsetTop": "0px",
                    "offsetStart": "0px"
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "20px",
                "backgroundColor": "#0000ff",
                "borderWidth": "1px",
                "borderColor": "#00ff00",
                "cornerRadius": "3px",
                "offsetTop": "28px",
                "offsetStart": "3px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": ":"+ datetime.strftime(timeNow,'%Y-%m-%d'),
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "13px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/9rcfswg/ezgif-com-gif-maker-6.png",
                        "size": "xl",
                        "aspectRatio": "4:4",
                        "aspectMode": "cover",
                        "offsetTop": "-1px",
                        "offsetStart": "-1px"
                      }
                    ],
                    "position": "absolute",
                    "width": "18px",
                    "height": "18px",
                    "offsetTop": "0px",
                    "offsetStart": "0px"
                  }
                ],
                "position": "absolute",
                "width": "75px",
                "height": "20px",
                "backgroundColor": "#ff0000",
                "borderWidth": "1px",
                "borderColor": "#00ff00",
                "cornerRadius": "3px",
                "offsetTop": "28px",
                "offsetEnd": "3px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "50px",
                "height": "50px",
                "borderWidth": "1px",
                "borderColor": "#00ff00",
                "cornerRadius": "3px",
                "offsetTop": "50px",
                "offsetStart": "3px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "👥{}".format(contact.displayName),
                    "size": "xxs",
                    "color": "#ffffff",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px"
                  }
                ],
                "position": "absolute",
                "width": "95px",
                "height": "20px",
                "backgroundColor": "#77778888",
                "borderWidth": "1px",
                "borderColor": "#00ff00",
                "cornerRadius": "2px",
                "offsetTop": "50px",
                "offsetEnd": "3px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/cJVnCt2/ezgif-com-gif-maker-4.png",
                        "size": "xxl",
                        "aspectRatio": "6:4",
                        "aspectMode": "cover",
                        "offsetTop": "-12px",
                        "offsetStart": "-5px"
                      }
                    ],
                    "position": "absolute",
                    "width": "90px",
                    "height": "28px",
                    "offsetTop": "0px",
                    "offsetStart": "0px"
                  }
                ],
                "position": "absolute",
                "width": "95px",
                "height": "28px",
                "backgroundColor": "#000000",
                "borderWidth": "1px",
                "borderColor": "#00ff00",
                "cornerRadius": "2px",
                "offsetTop": "71px",
                "offsetEnd": "3px"
              }
            ],
            "position": "absolute",
            "width": "154px",
            "height": "104px",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "8px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "height": "110px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                           cl.postTemplate(to, data)
                           break

               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"「Cek ID Sticker」\n°❂° STKID : " + msg.contentMetadata["STKID"] + "\n°❂° STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n°❂° STKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"°❂° Nama : " + msg.contentMetadata["displayName"] + "\n°❂° MID : " + msg.contentMetadata["mid"] + "\n°❂° Status Msg : " + contact.statusMessage + "\n°❂° Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
#======like'post========
        if op.type == 25 or op.type == 26:
            try:
                msg = op.message
                text = str(msg.text)
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                terminal = command(text)
                for terminal in terminal.split(" & "):
                    setKey = settings["keyCommand"].title()
                    if settings["setKey"] == False:
                        setKey = ''
                    if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                        if msg.toType == 0:
                            if sender != cl.profile.mid:
                                to = sender
                            else:
                                to = receiver
                        elif msg.toType == 1:
                            to = receiver
                        elif msg.toType == 2:
                            to = receiver
                        if msg.contentType == 0:
                            if to in offbot:
                                return
                        elif msg.contentType == 16:
                            if settings["checkPost"] == True:
                                try:
                                    ret_ = "╔══[ Details Post ]"
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        contact = client.getContact(sender)
                                        auth = "\n╠❂🇮🇩➢ Penulis : {}".format(str(contact.displayName))
                                    else:
                                        auth = "\n╠❂??🇩➢ Penulis : {}".format(str(msg.contentMetadata["serviceName"]))
                                    purl = "\n╠❂🇮🇩➢ URL : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                                    ret_ += auth
                                    ret_ += purl
                                    if "mediaOid" in msg.contentMetadata:
                                        object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                                        if msg.contentMetadata["mediaType"] == "V":
                                            if msg.contentMetadata["serviceType"] == "GB":
                                                ourl = "\n╠❂🇮🇩➢ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                                murl = "\n╠❂🇮🇩➢ Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                                            else:
                                                ourl = "\n╠❂🇮🇩➢ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                                murl = "\n╠❂🇮🇩➢ Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                                            ret_ += murl
                                        else:
                                            if msg.contentMetadata["serviceType"] == "GB":
                                                ourl = "\n╠❂🇮🇩➢ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                            else:
                                                ourl = "\n╠❂🇮🇩➢ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                        ret_ += ourl
                                    if "stickerId" in msg.contentMetadata:
                                        stck = "\n╠❂🇮🇩➢ Stiker : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                                        ret_ += stck
                                    if "text" in msg.contentMetadata:
                                        text = "\n╠❂🇮🇩➢ Tulisan :\n╠❂🇮🇩➢ {}".format(str(msg.contentMetadata["text"]))
                                        ret_ += text
                                    ret_ += "\n╚══[ Finish ]"
                                    sendpostTemplate(to, data)
                                except:
                                    cl.sendReplyMessage(msg.id, to, "Mantabb KEREN...")
                            if msg.toType in (2,1,0):
                                purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                                adw = cl.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                                adws = cl.createComment(purl[0], purl[1], settings["commentPost"])
                                cl.sendMessage(to, "")
            except Exception as error:
                logError(error)                        
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 and msg.toType == 2:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            elif msg.toType == 1:
                to = receiver
            elif msg.toType == 2:
                to = receiver
            if msg.contentType == 0:
                to = receiver
            if msg.contentType == 16:
              if settings["checkPost"] == True:
                url = msg.contentMetadata["postEndUrl"]
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                cl.likePost(url[25:58], url[66:], likeType=1004)
                cl.createComment(url[25:58], url[66:], wait["comment"])
                cover = cl.getProfileCoverURL(sender)
                data = {
                                "type": "flex",
                                "altText": "ʟɪᴋᴇ ᴅᴏɴᴇ",
                                "contents": {
"type": "carousel",
"contents": [
{
"type": "bubble",
"size": "nano",
"body": {
"backgroundColor": "#ff0000",
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 1
"animated": True,
"url": "https://i.ibb.co/8MKgPwd/Cieeeenyolong-punyak-WW-ya.png",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "4:4",
"gravity": "bottom",
"action": {
"uri": "line://nv/profilePopup/mid=u064a9d67622be19e915197ffad4bd99d",
"type": "uri",
}
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": cover, #"https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus),
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:2",
"offsetTop": "0px",
"action": {
"uri": "https://i.ibb.co/3zMNx9J/ezgif-com-gif-maker-1.png",
"type": "uri",
}}],
"position": "absolute",
"cornerRadius": "8px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "110px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus),
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:2",
"offsetTop": "0px",
"action": {
"uri": "line://nv/profilePopup/mid=u064a9d67622be19e915197ffad4bd99d",
"type": "uri",
}}],
"position": "absolute",
"cornerRadius": "8px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "110px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "🕘 "+ datetime.strftime(timeNow,'%H:%M:%S'),
"weight": "bold",
"color": "#ffff00",
"align": "center",
"size": "xxs",
"offsetTop": "3px"
}
],
"position": "absolute",
"cornerRadius": "7px",
"offsetTop": "9px",
#"backgroundColor": "#33ffff",
"offsetStart": "7px",
"height": "20px",
"width": "75px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #weh
{
"type": "image",
"url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
"size": "full",
"action": {
"type": "uri",
"uri": "http://wa.me/+6285707063716",   
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
"size": "xl",
"action": {
"type": "uri",
"uri": "Https://smule.com/_BowWow",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
"size": "xl",
"action": {
"type": "uri",
"uri": "line://nv/cameraRoll/multi"
},
"flex": 0
},{
"type": "image",
 "url": "https://i.ibb.co/ZHtFDts/20190427-185307.png", #chathttps://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
"size": "xl",
"action": {
"type": "uri",
"uri": "line://nv/chat",
},
"flex": 0
}
],
"position": "absolute",
"offsetTop": "9px",
"offsetStart": "90px",
"height": "200px",
"width": "25px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "Kang Post",
"weight": "bold",
"color": "#ffff00",
"align": "center",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "7px",
"offsetTop": "84px",
#"backgroundColor": "#ff0000",
"offsetStart": "7px",
"height": "15px",
"width": "75px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "📆 "+ datetime.strftime(timeNow,'%Y-%m-%d'),
"weight": "bold",
"color": "#ffff00",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "7px",
"offsetTop": "98px",
#"backgroundColor": "#0000ff",
"offsetStart": "7px",
"height": "15px",
"width": "85px"
}
],
#"backgroundColor": "#ff0000",
"paddingAll": "0px"
}
},
]
}
}
                cl.postTemplate(to, data)
            if msg.contentType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"STKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"Nama : " + msg.contentMetadata["displayName"] + "\nMID : " + msg.contentMetadata["mid"] + "\nStatus Msg : " + contact.statusMessage + "\nPicture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
               if msg.contentType == 13:
                if msg._from in admin:
                  if wait["invite"] == True:
                    msg.contentType = 0
                    contact = cl.getContact(msg.contentMetadata["mid"])
                    invite = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if invite in wait["blacklist"]:
                            sendTextTemplate1(msg.to, "ʟɪsᴛ ʙʟ")
                            break
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                         for target in targets:
                             try:
                                  cl.findAndAddContactsByMid(target)
                                  cl.inviteIntoGroup(msg.to,[target])
                                  ryan = cl.getContact(target)
                                  zx = ""
                                  zxc = ""
                                  zx2 = []
                                  xpesan =  "「 sᴜᴋsᴇs ɪɴᴠɪᴛᴇ 」\nɴᴀᴍᴀ"
                                  ret_ = "ᴋᴇᴛɪᴋ ɪɴᴠɪᴛᴇ ᴏғғ ᴊɪᴋᴀ sᴜᴅᴀʜ ᴅᴏɴᴇ"
                                  ry = str(ryan.displayName)
                                  pesan = ''
                                  pesan2 = pesan+"@x\n"
                                  xlen = str(len(zxc)+len(xpesan))
                                  xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                  zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                  zx2.append(zx)
                                  zxc += pesan2
                                  text = xpesan + zxc + ret_ + ""
                                  cl.sendMessage(msg.to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                  wait["invite"] = False
                                  break
                             except:
                                  sendTextTemplate1(msg.to,"ᴀɴᴅᴀ ᴛᴇʀᴋᴇɴᴀ sᴛʀᴜᴋ")
                                  wait["invite"] = False
                                  break
                                  
               if msg.contentType == 13:
                 if wait["Invi"] == True:
                        _name = msg.contentMetadata["displayName"]
                        invite = msg.contentMetadata["mid"]
                        groups = cl.getGroup(msg.to)
                        pending = groups.invitee
                        targets = []
                        for s in groups.members:
                            if _name in s.displayName:
                                cl.sendMessage(msg.to,"-> " + _name + " was here")
                                wait["Invi"] = False
                                break         
                            else:
                                targets.append(invite)
                        if targets == []:
                            pass
                        else:
                            for target in targets:
                                cl.findAndAddContactsByMid(target)
                                cl.inviteIntoGroup(msg.to,[target])
                                sendTextTemplate901(msg.to,"ᴅᴏɴᴇ ᴊᴇᴘɪᴛ ᴊᴏᴍʙʟᴏ\n➡" + _name)
                                wait["Invi"] = False
                                break
#=============MEDIA FOTOBOT=============

               if msg.contentType == 2:
                   if msg._from in admin:
                       if msg._from in settings["ChangeVideoProfilevid"]:
                            settings["ChangeVideoProfilePicture"][msg._from] = True
                            del settings["ChangeVideoProfilevid"][msg._from]
                            cl.downloadObjectMsg(msg_id,'path','video.mp4')
                            sendTextTemplate1(msg.to,"Send gambarnya...")
               if msg.contentType == 1:
                   if msg._from in admin:
                       if msg._from in settings["ChangeVideoProfilePicture"]:
                            del settings["ChangeVideoProfilePicture"][msg._from]
                            cl.downloadObjectMsg(msg_id,'path','image.jpg')
                            cl.nadyacantikimut('video.mp4','image.jpg')
                            sendTextTemplate1(msg.to,"ᴠɪᴅᴇᴏ ᴘʀᴏғɪʟᴇ ᴅᴏɴᴇ")
               if msg.contentType == 1:
                  if msg._from in admin:
                     if settings["Addimage"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         images[settings["Addimage"]["name"]] = str(path)
                         f = codecs.open("image.json","w","utf-8")
                         json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                         sendTextTemplate1(msg.to, "ᴅᴏɴᴇ ɢᴀᴍʙᴀʀ {}".format(str(settings["Addimage"]["name"])))
                         settings["Addimage"]["status"] = False
                         settings["Addimage"]["name"] = ""
               if msg.contentType == 2:
                  if msg._from in admin:
                     if settings["Addvideo"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         videos[settings["Addvideo"]["name"]] = str(path)
                         f = codecs.open("video.json","w","utf-8")
                         json.dump(videos, f, sort_keys=True, indent=4, ensure_ascii=False)
                         sendTextTemplate1(msg.to, "Berhasil menambahkan video {}".format(str(settings["Addvideo"]["name"])))
                         settings["Addvideo"]["status"] = False
                         settings["Addvideo"]["name"] = ""
               if msg.contentType == 7:
                  if msg._from in admin:
                     if settings["Addsticker"]["status"] == True:
                         stickers[settings["Addsticker"]["name"]] = {"STKID":msg.contentMetadata["STKID"],"STKPKGID":msg.contentMetadata["STKPKGID"]}
                         f = codecs.open("sticker.json","w","utf-8")
                         json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                         sendTextTemplate1(msg.to, "ᴅᴏɴᴇ sᴛɪᴄᴋᴇʀ {}".format(str(settings["Addsticker"]["name"])))
                         settings["Addsticker"]["status"] = False
                         settings["Addsticker"]["name"] = ""
               if msg.contentType == 3:
                  if msg._from in admin:
                     if settings["Addaudio"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         audios[settings["Addaudio"]["name"]] = str(path)
                         f = codecs.open("audio.json","w","utf-8")
                         json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                         sendTextTemplate1(msg.to, "Berhasil menambahkan mp3 {}".format(str(settings["Addaudio"]["name"])))
                         settings["Addaudio"]["status"] = False
                         settings["Addaudio"]["name"] = ""
               if msg.contentType == 0:
                  if settings["autoRead"] == True:
                      cl.sendChatChecked(msg.to, msg_id)
                  if text is None:
                      return
                  else:
                         for sticker in stickers:
                            if text.lower() == sticker:
                               sid = stickers[text.lower()]["STKID"]
                               spkg = stickers[text.lower()]["STKPKGID"]
                               cl.sendSticker(to, spkg, sid)
                         for image in images:
                            if text.lower() == image:
                               cl.sendImage(msg.to, images[image])
                         for audio in audios:
                            if text.lower() == audio:
                               cl.sendAudio(msg.to, audios[audio])
                         for video in videos:
                            if text.lower() == video:
                               cl.sendVideo(msg.to, videos[video])
               if msg.contentType == 13:
                 if msg._from in owner:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        sendTextTemplate900(msg.to,"Already in bot")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        sendTextTemplate900(msg.to,"Succes add bot")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        sendTextTemplate900(msg.to,"Succes delete bot")
                    else:
                        wait["dellbots"] = True
                        sendTextTemplate900(msg.to,"Nothing in bot")
#ADD STAFF
               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        sendTextTemplate900(msg.to,"ᴡᴇs ᴊᴀᴅɪ sᴛᴀғғ")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        sendTextTemplate900(msg.to,"ᴅᴏɴᴇ ᴀᴅᴅsᴛᴀғғ")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        sendTextTemplate900(msg.to,"✓sᴛᴀғғ ᴅɪʜᴀᴘᴜs")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        sendTextTemplate900(msg.to,"❎bukan staff")
#ADD ADMIN
               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        cl.sendMessage(msg.to,"Contact itu sudah jadi admin boss")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        cl.sendMessage(msg.to,"ᴅᴏɴᴇ ᴀᴅᴅ ᴀᴅᴍɪɴ")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"ᴀᴅᴍɪɴ ᴅɪʜᴀᴘᴜs")
                    else:
                        wait["delladmin"] = True
                        cl.sendMessage(msg.to,"Contact itu bukan admin")
#ADD BLACKLIST
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        sendTextTemplate1(msg.to,"❎Contact itu sudah ada di blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        sendTextTemplate1(msg.to,"✓Berhasil menambahkan ke blacklist user")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        sendTextTemplate1(msg.to,"✓Berhasil menghapus dari blacklist user")
                    else:
                        wait["dblacklist"] = True
                        sendTextTemplate1(msg.to,"❎Contact itu tidak ada di blacklist")
#TALKBAN
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        sendTextTemplate1(msg.to,"✓Contact itu sudah ada di Talkban")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        sendTextTemplate2(msg.to,"✓Berhasil menambahkan ke Talkban user")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        sendTextTemplate2(msg.to,"✓Berhasil menghapus dari Talkban user")
                    else:
                        wait["Talkdblacklist"] = True
                        sendTextTemplate1(msg.to,"❎Contact itu tidak ada di Talkban")
#UPDATE FOTO
               if msg.contentType == 1:
                 if msg._from in owner:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = cl.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            sendTextTemplate1(msg.to, "Succes add picture")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False
               if msg.contentType == 2:
               	if settings["changevp"] == True:
               		contact = cl.getProfile()
               		path = cl.downloadFileURL("https://obs.line-scdn.net/{}".format(contact.pictureStatus))
               		path1 = cl.downloadObjectMsg(msg_id)
               		settings["changevp"] = False
               		changeVideoAndPictureProfile(path, path1)
               		sendTextTemplate1(to, "ᴅᴏɴᴇ vɪᴅᴇᴏ ᴘʀᴏғɪʟᴇ")
               if msg.contentType == 2:
                 if msg._from in owner or msg._from in admin or msg._from in staff:
                   if settings["groupPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     cl.updateGroupPicture(msg.to, path)
                     sendTextTemplate1(msg.to, "ᴅᴏɴᴇ ᴘɪᴄᴛ ɢʀᴜᴘ")

               if msg.contentType == 1:
                 if msg._from in admin:
                        if mid in Setmain["RAfoto"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][mid]
                            cl.updateProfilePicture(path)
                            sendTextTemplate1(msg.to,"ғᴏᴛᴏ ʙᴇʀʜᴀsɪʟ")
                        if Amid in Setmain["RAfoto"]:
                            path = k1.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][Amid]
                            k1.updateProfilePicture(path1)
                            k1.sendMessage(msg.to,"ғᴏᴛᴏ ʙᴇʀʜᴀsɪʟ ᴅɪ'ʀᴜʙᴀʜ")                       
               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path1 = k1.downloadObjectMsg(msg_id)                    
                     settings["changePicture"] = False
                     k1.updateProfilePicture(path1)
                     k1.sendMessage(msg.to, "✓ᴘʀᴏғɪʟᴇ ᴘʜᴏᴛᴏ\nsᴜᴄᴄᴇssғᴜʟʟʏ ᴄʜᴀɴɢᴇᴅ")                     
               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path5 = cl.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     cl.updateProfilePicture(path)
                     cl.sendMessage(msg.to, "Sukses..")
                     k1.updateProfilePicture(path)
                     k1.sendMessage(msg.to, "Sukses..")                     
               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "bot on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                sendTextTemplate900(msg.to, "ʙᴏᴛ ᴡᴇs ᴏɴ")
                        elif cmd == "bot off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                sendTextTemplate900(msg.to, "ʙᴏᴛ ᴡᴇs ᴍᴏᴅᴀʀ")
                        elif cmd == "cvp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                            	settings["changevp"] = True
                            	cl.sendReplyMessage(msg.id, to, "sʜᴀʀᴇ ᴠɪᴅᴇᴏɴʏᴀ..")
                        elif cmd == "my menu":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               contact = cl.getProfile()
                               mids = [contact.mid]
                               cover = cl.getProfileCoverURL(sender)
                               listTimeLiking = time.time()
                               tz = pytz.timezone("Asia/Jakarta")
                               timeNow = datetime.now(tz=tz)
                               data = {
                                       "type": "flex",
                                       "altText": "🔥Menu bot🔥",
                                       "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/WfHJw7r/ezgif-com-gif-maker-2.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#ffffff",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "\n⚙️ Me\n⚙️ Cvp\n⚙️ Setting\n⚙️ Runtime\n⚙️ Speed-Sp\n⚙️ Tag\n⚙️ Bye\n⚙️ Lvall\n⚙️ Friendlist\n⚙️ Gruplist\n⚙️ Open [qr]\n⚙️ Close [qr]\n⚙️ Set tag: [text]\n⚙️ Set tag2: [text]\n⚙️ Rtag: [Nogc]\n⚙️ Jepit\n⚙️ Block\n⚙️ Addme @\n⚙️ Mybot\n⚙️ Listpending\n⚙️ Blockcontact\n⚙️ Lkstblock", #1
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure_Club",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetStart": "5px",
                "offsetTop": "2px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#00ff00",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/WfHJw7r/ezgif-com-gif-maker-2.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#ffffff",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "\n⚙️ Broadcast: [text]\n⚙️ Ceksider\n⚙️ Cekleave\n⚙️ Cekpesan\n⚙️ Cekrespon\n⚙️ Cekrespon2\n⚙️ Set sider:\n⚙️ Set pesan:\n⚙️ Set respon:\n⚙️ Set respon2\n⚙️ Set welcome:\n⚙️ Set leave:\n⚙️ Like on/off\n⚙️ On/Off [sider]\n⚙️ Stag: jumlah\n⚙️ Stag @\n⚙️ Call: jumlah\n⚙️ Call\n⚙️ Scallto\n⚙️ Post on/off\n⚙️ Sticker on/off\n⚙️ Invite on/off", #2
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure_Club",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#00ff00",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/WfHJw7r/ezgif-com-gif-maker-2.png",
            "gravity": "top",
            "size": "full",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#ffffff",
            "borderWidth": "1px",
            "borderColor": "#00ff00"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "\n⚙️ Respon2 on/off\n⚙️ Autoadd on/off\n⚙️ Autoleave on/off\n⚙️ Autoblock on/off\n⚙️ Jointicket on/off\n⚙️ Addmp3\n⚙️ Addaudio\n⚙️ Addimg\n⚙️ Dellsticker\n⚙️ Dellaudio\n⚙️ Dellmp3\n⚙️ Dellvideo\n⚙️ Dellimg\n⚙️ Liststicker\n⚙️ Listimage\n⚙️ Listvideo\n⚙️ Listaudio\n⚙️ Listmp3\n⚙️ Lihat [no]\n⚙️ Cctv metro\n⚙️ Smule id\n⚙️ Joox text", #3
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure_Club",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "borderWidth": "2px",
        "borderColor": "#00ff00",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/WfHJw7r/ezgif-com-gif-maker-2.png",
            "gravity": "top",
            "size": "full",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#ffffff",
            "borderWidth": "1px",
            "borderColor": "#00ff00"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "\n⚙️ Youtube text\n⚙️ Yutube text\n⚙️ Getid @\n⚙️ Getmid @\n⚙️ Getbio @\n⚙️ Getinfo @\n⚙️ Getprofile @\n⚙️ Getpicture @\n⚙️ Info @\n⚙️ Kepo @\n⚙️ Ppvideo @\n⚙️ Kontak @\n⚙️ Infomem [no]\n⚙️ Staf @\n⚙️ Stafdell @\n⚙️ Admin @\n⚙️ Admindell @\n⚙️ Reboot\n⚙️ Ban @\n⚙️ Listmid\n⚙️ Addasis\n⚙️ Unsend on/off", #4
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure_Club",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "borderWidth": "2px",
        "borderColor": "#00ff00",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/WfHJw7r/ezgif-com-gif-maker-2.png",
            "size": "full",
            "gravity": "top",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#ffffff",
            "borderWidth": "1px",
            "borderColor": "#00ff00"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "\n⚙️ Bl\n⚙️ Ban:on @\n⚙️ Unban:on @\n⚙️ Unban @\n⚙️ Ban or Bh\n⚙️ Cb\n⚙️ Refresh\n⚙️ Menu js\n⚙️ Menu sticker\n⚙️ Respon on/off \n⚙️ Respon2 on/off \n⚙️ Respon3 on/off\n⚙️ Respon4 on/off\n⚙️ Respon5 on/off\n⚙️ Respon6 on/off\n⚙️ Respon7 on/off\n⚙️ Respon8 on/off\n⚙️ St on/off\n⚙️ Notif on/off\n⚙️ Mp4 text\n⚙️ Mp3 text ", #5
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure_Club",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "borderWidth": "2px",
        "borderColor": "#00ff00",
        "cornerRadius": "10px"
      }
    }
  ]
}
}
                               cl.postTemplate(to, data)
                        elif cmd == "menu js":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               contact = cl.getProfile()
                               mids = [contact.mid]
                               cover = cl.getProfileCoverURL(sender)
                               listTimeLiking = time.time()
                               tz = pytz.timezone("Asia/Jakarta")
                               timeNow = datetime.now(tz=tz)
                               data = {
                                       "type": "flex",
                                       "altText": "Adventure club",
                                       "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/WfHJw7r/ezgif-com-gif-maker-2.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#ffffff",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "\n----------COMAN JS----------\n⚙️ Kiss @\n⚙️ Gkick @\n⚙️ .Gowes [kickall]\n⚙️ .oleng [kickall]\n⚙️ Js / Kjs [kickall] \n⚙️ .jos [💥]\n⚙️ .wow [Ajs kickall]\n⚙️ kickall [no group]\n⚙️ .lokdon [bypass] \n<==========>\n<==CMD AJS==>\n⚙️ Say (invite ajs)\n⚙️ Abye [CancelAjs]\n⚙️ A in [inviteAjs]\n⚙️ A out [out]", #10
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure_Club",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetStart": "5px",
                "offsetTop": "2px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#00ff00",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/WfHJw7r/ezgif-com-gif-maker-2.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:6",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#ffffff",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "\n----------Sticker big----------\n\n✒ Sedih\n✒ Hajar\n✒ Bobok\n✒ Asem\n✒ Assalamualaikum\n✒ Sip\n✒ Nyimak\n✒ Sebel\n✒ Capek\n✒ muach\n✒ Peluk\n✒ Kangen\n✒ Thanks",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure_Club",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#00ff00",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/WfHJw7r/ezgif-com-gif-maker-2.png",
            "gravity": "top",
            "size": "full",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#ffffff",
            "borderWidth": "1px",
            "borderColor": "#00ff00"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "\n---------Sticker big---------\n\n✒ Ok\n✒ Cium\n✒ Asemm\n✒ Adem\n✒ Mmuach\n✒ Bot\n haha\n✒ Wkwk\n✒ Amin\n✒ Kabur\n✒ Siap\n✒ Maaf\n✒ Walaikumsalam\n✒ Absen", #10
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure_Club",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "borderWidth": "2px",
        "borderColor": "#00ff00",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/WfHJw7r/ezgif-com-gif-maker-2.png",
            "gravity": "top",
            "size": "full",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#ffffff",
            "borderWidth": "1px",
            "borderColor": "#00ff00"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "----------Media on----------\n\n⚙️ Ytvid [judul]\n⚙️ Ytaudio [judul]\n⚙️ Joox [judul]\n⚙️ Smule id [no]\n⚙️ Ytmp3 [judul]\n⚙️ Ytmp4 [judul]\n⚙️ set mention: nama\n⚙️ urungchat [Uns] \n⚙️ Sibuk on/off", #5
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure_Club",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "borderWidth": "2px",
        "borderColor": "#00ff00",
        "cornerRadius": "10px"
      }
    },
    {
      "type": "bubble",
      "size": "nano",
      "hero": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/WfHJw7r/ezgif-com-gif-maker-2.png",
            "size": "full",
            "gravity": "top",
            "aspectRatio": "2:6",
            "aspectMode": "cover",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "animated": True,
                "url": "https://i.ibb.co/6tQK6Y2/ezgif-com-gif-maker.png",
                "size": "sm",
                "aspectRatio": "6:4",
                "aspectMode": "cover",
                "offsetTop": "-15px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "20px",
            "backgroundColor": "#ffffff",
            "borderWidth": "1px",
            "borderColor": "#00ff00"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "----------Menu Bot----------\n\n⚙️ My menu\n⚙️ Menu js\n⚙️ Help\n⚙️ Media\n⚙️ Gunakan dengan baik\n⚙️ Diatas sana \n⚙️ Ada Langit\n⚙️ Diatasnya langit\n⚙️ Ada Langit",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "5px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "110px",
            "height": "300px",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "cornerRadius": "2px",
            "offsetTop": "22px",
            "offsetStart": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure_Club",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "2px",
                "offsetStart": "5px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "25px",
            "backgroundColor": "#000000",
            "borderWidth": "1px",
            "borderColor": "#00ff00",
            "offsetTop": "325px",
            "offsetStart": "0px"
          }
        ],
        "borderWidth": "2px",
        "borderColor": "#00ff00",
        "cornerRadius": "10px"
      }
    }
  ]
}
}
                               cl.postTemplate(to, data)
                        elif cmd.startswith("rname "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        cl.renameContact(ls,sep[1])
                                        cl.sendReplyMention(msg_id, to, "Succes change @! display name to {}".format(sep[1]), [ls])

                        elif text.lower() == "status":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                md = ""
                                if wait["Busy"] == True: md+="║║⏹️ Mode busy: ✓\n"
                                else: md+="║║⏹️ Mode busy : ❌\n"
                                if wait["nCall"] == True: md+="║║⏹️ Notifcall : ✓\n"
                                else: md+="║║⏹️ Notifcall : ❌\n"
                                if settings["checkPost"] == True: md+="║║⏹️ Post : ✓\n"
                                else: md+="║║⏹️ Post : ❌\n"
                                if settings["Aip"] == True: md+="║║⏹️ Aip : ✓\n"
                                else: md+="║║⏹️ Aip : ❌\n"
                                if wait["voom"] == True: md+="║║⏹️ Timeline : ✓\n"
                                else: md+="║║⏹️ Timeline : ❌\n"
                                if wait["facebook"] == True: md+="║║⏹️ Facebook : ✓\n"
                                else: md+="║║⏹️ Facebook : ❌\n"
                                if wait["contact"] == True: md+="║║⏹️ Contact : ✓\n"
                                else: md+="║║⏹️ Contact : ❌\n"
                                if wait["Mentionkick"] == True: md+="║║⏹️ Notag : ✓\n"
                                else: md+="║║⏹️ Notag : ❌\n"
                                if wait["detectMention"] == True: md+="║║⏹️ Respontag : ✓\n"
                                else: md+="║║⏹️ Respontag : ❌\n"
                                if wait["detectMention2"] == True: md+="║║⏹️ Respontag2 : ✓\n"
                                else: md+="║║⏹️ Respontag2 : ❌\n"
                                if wait["detectMention3"] == True: md+="║║⏹️ Respontag3 : ✓\n"
                                else: md+="║║⏹️ Respontag3 : ❌\n"
                                if wait["detectMention4"] == True: md+="║║⏹️ Respontag4 : ✓\n"
                                else: md+="║║⏹️ Respontag4 : ❌\n"
                                if wait["detectMention5"] == True: md+="║║⏹️ Respontag5 : ✓\n"
                                else: md+="║║⏹️ Respontag5 : ❌\n"
                                if wait["detectMention6"] == True: md+="║║⏹️ Respontag6 : ✓\n"
                                else: md+="║║⏹️ Respontag6 : ❌\n"
                                if wait["detectMention7"] == True: md+="║║⏹️ Respontag7 : ✓\n"
                                else: md+="║║⏹️ Respontag7 : ❌\n"
                                if wait["detectMention8"] == True: md+="║║⏹️ Respontag8 : ✓\n"
                                else: md+="║║⏹️ Respontag8 : ❌\n"
                                if wait["detectMention9"] == True: md+="║║⏹️ Respontag9 : ✓\n"
                                else: md+="║║⏹️ Respontag9 : ❌\n"
                                if wait["Unsend"] == True: md+="║║⏹️ Unsend : ✓\n"
                                else: md+="║║⏹️ Unsend : ❌\n"
                                if settings["autoRead"] == True: md+="║║⏹️ Autoread : ✓\n"
                                else: md+="║║⏹️ Autoread : ❌\n"
                                if wait["autoAdd"] == True: md+="║║⏹️ Autoadd : ✓\n"
                                else: md+="║║⏹️ Autoadd : ❌\n"
                                if wait["autoLeave"] == True: md+="║║⏹️ Autoleave : ✓\n"
                                else: md+="║║⏹️ Autoleave : ❌\n"
                                if wait["autoJoin"] == True: md+="║║⏹️ Autojoin : ✓\n"
                                else: md+="║║⏹️ Autojoin : ❌\n"
                                if wait["sticker"] == True: md+="║║⏹️ Sticker : ✓\n"
                                else: md+="║║⏹️ Sticker ❌\n"
                                if settings["autoJoinTicket"] == True: md+="║║⏹️ Jointicket : ✓\n"
                                else: md+="║║⏹️ Jointicket : ❌\n"
                                if wait["autoReject"] == True: md+="║║⏹️ Autoreject : ✓\n"
                                else: md+="║║⏹️ Autoreject : ❌\n"
                                if wait["autoBlock"] == True: md+="║║⏹️ Autoblock : ✓\n"
                                else: md+="║║⏹️ Autoblock : ❌\n"
                                if wait["ytube"] == True: md+="║║⏹️ YouTube : ✓\n"
                                else: md+="║║⏹️ YouTube : ❌\n"
                                if wait["sharesmule"] == True: md+="║║⏹️ Smule : ✓\n"
                                else: md+="║║⏹️ Smule : ❌\n"
                                if wait["tiktok"] == True: md+="║║⏹️ Tiktok : ✓\n"
                                else: md+="║║⏹️ Tiktok ❌\n"
                                if wait["jumbosticker"] == True: md+="║║⏹️ Sticker big : ✓\n"
                                else: md+="║║⏹️ Sticker big : ❌\n"
                                if wait["welcomeOn"] == True: md+="║║⏹️ Sambutan join : ✓\n"
                                else: md+="║║⏹️ Sambutan join : ❌\n"
                                sendTextTemplate2(msg.to, "╔════════════\n"+ md +"╚════════════\n╔════════════\n║ • ᴀᴅᴠᴇɴᴛᴜʀᴇ_ᴄʟᴜʙ \n╚════════════")

                        elif text.lower() == ".mid" or text.lower() == ".mit":
                            data = {
                            "type": "text",
                            "text": "{}".format(msg._from),
                            "sentBy": {
                            "label": "• ᴀᴅᴠᴇɴᴛᴜʀᴇ •",
                            "iconUrl": "https://i.ibb.co/bNBqP5T/07-39-38-9550611aa1fd2611b1d6f286a4e812bf.gif",
                            "linkUrl": "line://nv/profilePopup/mid=u064a9d67622be19e915197ffad4bd99d"}}
                            cl.postTemplate(to, data)                                                   
                                                     
                        elif text.lower() == "salam" or text.lower() == "assalamualaikum":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "وَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِوَبَرَكَاتُهُ")
                        elif text.lower() == "dor" or text.lower() == "dorr":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "𝐷𝑢ℎ 𝑛𝑔𝑎𝑔𝑒𝑡𝑖𝑛 𝑎𝑗𝑎 😲")                                                       
                        elif text.lower() == "desah on" or text.lower() == "on":
                          if wait["selfbot"] == True:                            
                               cl.sendMessage(msg.to, "ᴀᴜᴛᴏ ᴅᴇsᴀʜ ᴅɪᴍᴜʟᴀɪ ɴɪʜ😝")                                     
                        elif text.lower() == "typo" or text.lower() == "joss":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "Kebiasaan jempolnya ngeluyur bae🤪")                  
                        elif text.lower() == "muach" or text.lower() == "cipok":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "𝘊𝘪𝘶𝘮 𝘑𝘢𝘶𝘩 𝘴𝘦𝘬 😂")                  
                        elif text.lower() == "okey" or text.lower() == "oke":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "𝐎𝐤𝐞𝐲 siap 𝐋𝐮𝐫...👌")                   
                        elif text.lower() == "aa" or text.lower() == "bang":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "ᴇᴀ ᴅᴀʟᴇᴍʙ ɴᴇɴɢ ɢᴇᴜʟɪs..")                  
                        elif text.lower() == "mandi" or text.lower() == "ados":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "ɴᴅᴀɴɢ ᴍᴀɴᴅɪ ʙɪᴀʀ ᴡᴀɴɢɪ😝")                  
                        elif text.lower() == "wc" or text.lower() == "kam":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "ᴍᴇᴛ ɢᴀʙᴜɴɢ ʏᴏ ɢaes🤪 \nᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɴɢᴇɴᴏᴛᴇ🙏")                  
                        elif text.lower() == "salken" or text.lower() == "saltoo":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "sᴀʟᴋᴇɴᴊᴜ ʟᴜʀ , sᴀʟᴋᴏᴍsᴇʟ ᴍᴀɴᴛᴜʟ")                  
                        elif text.lower() == "bobok" or text.lower() == "tidur":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "𝑌𝑢𝑘 𝐵𝑜𝑏𝑜𝑘 𝑆𝑎𝑦😪")                 
                        elif text.lower() == "yank" or text.lower() == "nda":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "ᴀᴅᴀ sᴀʏᴀɴᴋ ᴀᴅᴀ...😍😍")                  
                        elif text.lower() == "sayank" or text.lower() == "tayank":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "𝑌𝑎𝑛𝑘 𝑃𝑎𝑙𝑎𝑚𝑢 𝑃𝑒𝑎𝑛𝑘😂")                   
                        elif text.lower() == "kojom" or text.lower() == "kojom on":
                          if wait["selfbot"] == True:                            
                               cl.sendMessage(msg.to, "ᴀᴜᴛᴏ ᴍᴏᴊᴏᴋ sᴜᴅᴀʜ ᴅɪᴍᴜʟᴀɪ😂")                  
                        elif text.lower() == "nyusu" or text.lower() == "susu":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "ɴʏᴜsᴜ ᴅᴜʟᴜ ʟᴜʀ ʙɪᴀʀ sᴇʜᴀᴛ🍼")                  
                        elif text.lower() == "ngopi" or text.lower() == "kopi":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "ɴɢᴏᴘɪ sᴇᴋ ʏᴜᴋ☕")                  
                        elif text.lower() == "makan" or text.lower() == "sarapan":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "𝐴yo Makan dulu gess🍜")                  
                        elif text.lower() == "asem" or text.lower() == "sem":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "ᴜʜʜ..ʙᴀᴜ ᴀsᴇᴍ ʟᴜ😂")                   
                        elif text.lower() == "malam" or text.lower() == "mlm":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "ᴇᴀ ᴍᴇᴛ ᴍᴀʟᴀᴍ sᴏᴅᴀʀᴀ sᴏᴅᴀʀᴀ🙄")                 
                        elif text.lower() == "pm" or text.lower() == "cek pm":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "ᴄɪᴇ ɴɢᴀᴊᴀᴋ ᴘᴍ ᴀɴ")
                        elif text.lower() == "dudul" or text.lower() == "pekok":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "ᴇʟᴜ ʏᴀɴɢ ᴋᴏᴘʟᴏᴋ😂")                  
                        elif text.lower() == "son" or text.lower() == "sider on":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "sɪᴅᴇʀ ᴍᴜʟᴜ ɪʜʜ ,ɴʏᴇʙᴇʟɪɴ ᴅᴇʜʜ😂")                 
                        elif text.lower() == "asalamualaikum" or text.lower() == "mikum":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "𝐴ssalamualaikum wr.wb sodara sodara")
                        elif text.lower() == "sore" or text.lower() == "petang":
                          if wait["selfbot"] == True:                            
                               cl.sendMessage(msg.to, "sᴏʀᴇ ᴊᴜɢᴀ ᴋᴀᴋᴀᴋ \nᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ᴍᴀɴᴅɪ ᴅᴀʜ sᴏʀᴇ ʟᴏʜ")                 
                        elif text.lower() == "sepi" or text.lower() == "sunyi":
                          if wait["selfbot"] == True:                            
                               cl.sendMessage(msg.to, "ᴇᴀ sᴇᴘɪ ʟᴜʀ ᴘᴀᴅᴀ ᴍᴏᴊᴏᴋ ᴋᴀʏᴀᴋɴʏᴀ😂")                 
                        elif text.lower() == "naik" or text.lower() == "up":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "ɴᴀɪᴋ ᴀᴊᴀ ᴅᴜʟᴜ ɢᴇs🙄")
                        elif text.lower() == "siang" or text.lower() == "panas":
                          if wait["selfbot"] == True:                            
                               cl.sendMessage(msg.to, "Siang juga teman-teman 😘")                  
                        elif text.lower() == "jawab" or text.lower() == "assalamualaikum":
                          if wait["selfbot"] == True:                            
                               cl.sendMessage(msg.to, "Waalaikumsalam wr WB sobatq 🙏")                 
                        elif text.lower() == "anu" or text.lower() == "sue":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "sᴜᴇ ᴏʀᴀ ᴀɴᴜ😂")
                        elif text.lower() == "pagi" or text.lower() == "morning":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "Pagi juga teman teman GokiL q 😆")
                        elif cmd == "blenk":
                          if wait["selfbot"] == True:                            
                               cl.sendMessage(msg.to, "sᴏʀʀʏ ɢᴀᴇs ᴀᴋᴜ ᴘɪɴᴊᴀᴍ ʟᴀʏᴀʀ ʜᴘɴʏᴀ  \n ʟᴏᴀᴅɪɴɢ ʟᴏᴀᴅɪɴɢ.......❌.👁️.★.★.★.??️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.👿.👿.👿 ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.??.👿.")
                        elif cmd == "gelapp":
                          if wait["selfbot"] == True:                            
                               cl.sendMessage(msg.to, "ᴍᴀɴᴛᴀᴘ ᴍᴀɴᴛᴀᴘ ᴍᴀɴᴛᴀᴘ \n sᴏʀʀʏ ʟᴏᴀᴅɪɴɢ .......ʟᴏᴀᴅɪɴɢ..... ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.👿.👿.👿 ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n❌.👁️.★.★.★.??️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.??.👿.")
                        elif text.lower() == "tagall":
                          if wait["selfbot"] == True:
                               cl.sendReplyMessage(msg.id, to, "ɴɢᴇᴛᴀɢ ᴍᴜʟᴜ sɪʜ..")
                        elif text.lower() == "mbot":
                          if wait["selfbot"] == True:
                               cl.sendReplyMessage(msg.id, to, "Aku dah gak punya mbot gess.?")
                        elif text.lower() == "aku" or text.lower() == "aim":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "Aku dan kamu menjadi kita 😆")
                        elif text.lower() == "tutup" or text.lower() == "close":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "Buka in lagi dong 😆")
                        elif text.lower() == "mention" or text.lower() == "mentil":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "Hadirr Lur 😘😘")
                        elif text.lower() == "link" or text.lower() == "lung":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "☛ Masih Belom ada Link Gess \n☛ Tunggu ea😂")
                        elif text.lower() == "mywa" or text.lower() == "wa":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "WA Me : +6285707063716")
                        elif text.lower() == "!rex" or text.lower() == "!rek":
                          if wait["selfbot"] == True:                            
                               cl.sendReplyMessage(msg.id, to, "• ʙᴀɴᴋ - ᴍᴀɴᴅɪʀɪ\n• 1710004924315 \n• ᴀɴ : ᴡɪʙᴏᴡᴏ")
#==========respon sticker===========#                      
                        elif text.lower() == "sedih":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://3.bp.blogspot.com/-OfIz4mSIumw/WbLEZw7l6nI/AAAAAAARd6Y/Dxzos1SA_5MU32bXFTKToLDndM7YpV7WACLcBGAs/s1600/AW529310_04.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data) 
                        
                                    
                        elif text.lower() =="hajar":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/y0wP3fJ/tai-line.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="bobok":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/52002761/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)
                        
                        elif text.lower() =="kiss":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/13386301/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)
                                    
                        elif text.lower() =="asem":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/72847952/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)
                                    
                        elif text.lower() =="assalamualaikum":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://www.linkpicture.com/q/unnamed-1_12.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="sip":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/4976950/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)
                                    
                        elif text.lower() =="nyimak":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/72847962/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)
                                    
                        elif text.lower() =="sebel":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/15417576/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://wa.me/+6285707063716"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)
                                    
                        elif text.lower() =="capek":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/64774429/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://wa.me/+6285707063716"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="kopi":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/64774422/ANDROID/sticker.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://wa.me/+6285707063716"
                                 }                                              
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)
                                    
                        elif text.lower() =="mmuach" or text.lower() =="emuach" or text.lower() =="emmuach":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/27533208/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="peluk":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/20943951/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)
                                    
                        elif text.lower() =="kangen":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/27533210/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="thanks" or text.lower() =="makasi" or text.lower() =="terimakasih":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/27533215/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)
                                    
                        elif text.lower() =="ok" or text.lower() =="oke" or text.lower() =="okay":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/27533213/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="cium":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/52002737/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)
                                    
                        elif text.lower() =="asemm":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://www.linkpicture.com/q/06e3ef23edf41d0fc0f95d8cf30f9aac.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="dudul" or text.lower() =="pekok":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://www.linkpicture.com/q/1e92d8921a24d912c16a9f6af8acc534.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)
                                    
                        elif text.lower() =="adem":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://www.linkpicture.com/q/unnamed_30.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="muach":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/27533209/IOS/sticker_animation@2x.png",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="bot":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://www.linkpicture.com/q/209563.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "https://line.me/ti/p/~hidhayah01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="haha":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/xHDXBrd/AW316783-23.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://wa.me/+6285707063716"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="wkwk":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.pinimg.com/originals/9e/bb/f7/9ebbf7a320a06fb9a254b2f521bbd4ec.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://wa.me/+6285707063716"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="amin":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.pinimg.com/originals/c5/1d/da/c51ddaae928617f00f962eb96fd4af33.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://wa.me/+6285707063716"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="kabur":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/FsTqdpd/fac502b083ab70051050890b99bb6e73.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://wa.me/+6285707063716"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="siap":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/TKZ2KVD/AW316783-09.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://wa.me/+6285707063716"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() =="maaf":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/LJXgPb2/AW316783-21.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://wa.me/+6285707063716"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data) 

                        elif text.lower() =="walaikumsalam":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/cgXn5dL/AW1575362-01.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://wa.me/+6285707063716"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data) 

                        elif text.lower() =="absen":
                        	if wait["jumbosticker"] == True:
                                    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                                    to = msg.to
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(cl.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/Rytk8fV/AW316783-08.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://wa.me/+6285707063716"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    cl.postTemplate(to, data)

                        elif text.lower() == "viruss":
                          if wait["selfbot"] == True:                              
                               cl.sendReplyMessage(msg.id, to, "Assalamu'alaikum...wr...wb...\n.1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.\n TEAM SOAK KILLER\n.1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.\nTEAM SOAK KILLER.1.2.3.4.5.6.7.8.9.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.H.7.I.8.J.9.K.0.A.1.B.2.D.3.E.4.F.5.G.6.")
                               
                        elif ("Gname " in msg.text):
                          if msg._from in admin:
                              X = cl.getGroup(msg.to)
                              X.name = msg.text.replace("Gname ","")
                              cl.updateGroup(X)

                        elif "Gruppict" in msg.text:
                          if msg._from in admin:
                                group = cl.getGroup(msg.to)
                                path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                cl.sendImageWithURL(msg.to,path)

                        elif "Getprofile " in msg.text:
                          if msg._from in admin:
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    try:
                                        profile = cl.getContact(mention['M'])
                                        cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+profile.pictureStatus)
                                    except Exception as e:
                                        pass

                        elif "Getinfo " in msg.text:
                          if msg._from in admin:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            contact = cl.getContact(key1)
                            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            try:
                                sendTextTemplate901(msg.to,"Nama:\n" + contact.displayName)
                                sendTextTemplate901(msg.to,"Bio:\n" + contact.statusMessage)
                                cl.sendImageWithURL(msg.to,image)
                            except:
                                pass

                        elif cmd == 'listblock':
                          if msg._from in admin:
                            blockedlist = cl.getBlockedContactIds()
                            kontak = cl.getContacts(blockedlist)
                            num=1
                            msgs="List Blocked"
                            for ids in kontak:
                                msgs+="\n[%i] %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+="\n\nTotal Blocked : %i" % len(kontak)
                            sendTextTemplate901(to, msgs)

                        elif "Getbio " in msg.text:
                          if msg._from in admin:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            contact = cl.getContact(key1)
                            try:
                                sendTextTemplate901(msg.to,contact.statusMessage)
                            except:
                                sendTextTemplate901(msg.to,"⟦ʙɪᴏ ᴇᴍᴘᴛʏ⟧")

                        elif text.lower() == 'kalender':
                          if msg._from in admin:
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                            hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                            bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                            hr = timeNow.strftime("%A")
                            bln = timeNow.strftime("%m")
                            for i in range(len(day)):
                                if hr == day[i]: hasil = hari[i]
                            for k in range(0, len(bulan)):
                                if bln == str(k): bln = bulan[k-1]
                            readTime = "❂➣ "+ hasil + " : " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\n\n❂➣ Jam : 🔹 " + timeNow.strftime('%H:%M:%S') + " 🔹"
                            sendTextTemplate2(msg.to, readTime)

                        elif cmd == "mybot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': mid}
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': mid}, contentType=13)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Amid}
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': Amid}, contentType=13)                               
                               
                        elif cmd == "myname":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            sendTextTemplate906(to, "[ ᴅɪsᴘʟᴀʏ ɴᴀᴍᴇ ]\n{}".format(contact.displayName))

                        elif cmd == "mybio":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            sendTextTemplate901(to, "[ sᴛᴀᴛᴜs ʟɪɴᴇ ]\n{}".format(contact.statusMessage))

                        elif cmd == "Picture":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            cl.sendImageWithURL(to,"http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus))

                        elif cmd == "myvideo":
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            cl.sendVideoWithURL(to,"http://dl.profile.line-cdn.net/{}/vp".format(contact.pictureStatus))

                        elif cmd == "mycover":
                          if msg._from in admin:
                            channel = cl.getProfileCoverURL(sender)
                            path = str(channel)
                            cl.sendImageWithURL(to, path)

                        elif cmd.startswith("bc: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               tz = pytz.timezone("Asia/Jakarta")
                               timeNow = datetime.now(tz=tz)
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = cl.getGroupIdsJoined()
                               for group in saya:
                                   sendTextTemplate111(group," " + str(pesan))

                        elif cmd.startswith("bc2: "):
                          if wait["selfbot2"] == True:
                            if msg._from in admin:
                               tz = pytz.timezone("Asia/Jakarta")
                               timeNow = datetime.now(tz=tz)
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = cl.getGroupIdsJoined()
                               for group in saya:
                                   cl.sendMessage(msg.to, group," " + str(pesan))

                        elif cmd == "Profile":
                          if msg._from in admin:
                            text = "~ Profile ~"
                            contact = cl.getContact(sender)
                            cover = cl.getProfileCoverURL(sender)
                            result = "╔══[ Details Profile ]"
                            result += "\n├≽ Display Name : @!"
                            result += "\n├≽ Mid : {}".format(contact.mid)
                            result += "\n├≽ Status Message : {}".format(contact.statusMessage)
                            result += "\n├≽ Picture Profile : http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                            result += "\n├≽ Cover : {}".format(str(cover))
                            result += "\n╚══[ Finish ]"
                            cl.sendImageWithURL(to, "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus))
                            cl.sendMentionWithFooter(to, text, result, [sender])

                        elif cmd.startswith("block"):
                          if msg._from in admin:
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.blockContact(ls)
                                cl.generateReplyMessage(msg.id)
                                cl.sendReplyMessage(msg.id, to, "sᴜᴋsᴇs ᴅɪ ʙʟᴏᴄᴋ" + str(contact.displayName) + "ᴡᴇs ᴛᴀᴋ ʙʟᴏᴋɪʀ")

                        elif cmd.startswith("add "):
                          if msg._from in admin:
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.findAndAddContactsByMid(ls)
                                cl.generateReplyMessage(msg.id)
                                cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴀᴅᴅ : " + str(contact.displayName) + "ᴋɪᴛᴀ ʙᴇʀᴛᴇᴍᴀɴ ʏᴀᴄʜ ")

                        elif "Getmid " in msg.text:
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    try:
                                        cl.sendMessage(msg.to,str(mention['M']))
                                    except Exception as e:
                                        pass
                                        
                        elif cmd.startswith(". "):
                             sep = text.split(" ")
                             txt = text.replace(sep[0] + " ","")
                             url = "https://rest.farzain.com/api/special/fansign/cosplay/cosplay.php?apikey=nda12345&text={}".format(txt)
                             cl.sendImageWithURL(to, url)
                        elif cmd.startswith("viloid "):
                             sep = text.split(" ")
                             txt = text.replace(sep[0] + " ","")
                             url = "https://rest.farzain.com/api/special/fansign/indo/viloid.php?apikey=aguzzzz748474848&beta&text={}".format(txt)
                             cl.sendImageWithURL(to, url)

                        elif "Contact: " in msg.text:
                           if msg._from in admin:
                              mmid = msg.text.replace("Contact: ","")
                              msg.contentType = 13
                              msg.contentMetadata = {"mid":mmid}
                              cl.sendMessage(msg.to, None, contentMetadata={'mid': mmid}, contentType=13)
                              path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                              image = 'http://dl.profile.line.naver.jp'+path
                              cl.sendImageWithURL(msg.to, image)

                        elif ', ' in text.lower():
                        	if sender in Bots or sender in Creator or sender in Master:
                	        		sep = text.split(" ")
                		        	search = text.replace(", ","")
                		        	jenis ="https://flamingtext.com/net-fu/proxy_form.cgi?script=water-logo&text="+search+"&_loc=generate&imageoutput=true","https://flamingtext.com/net-fu/proxy_form.cgi?script=runner-logo&text="+search+"&_loc=generate&imageoutput=true"
                		        	anu = random.choice(jenis)
                		        	cl.sendImageWithURL(to, str(anu))

                        elif cmd.startswith("kontak"):
                          if msg._from in admin:
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    cl.sendContact(to,str(ls))

                        elif cmd.startswith("ppvideo"):
                          if msg._from in admin:
                            if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    path = "http://dl.profile.line.naver.jp/{}/vp".format(contact.pictureStatus)
                                    cl.sendVideoWithURL(to, str(path))

                        elif text.lower() == "dell":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)                                   
                                   k1.removeAllMessages(op.param2)                                   
                                   sw.removeAllMessages(op.param2)
                                   cl.sendReplyMessage(msg.id, to,"ᴄʜᴀᴛ ᴡᴇs ʀᴇsɪᴋ..")
                               except:
                                   pass

                        elif ("Info " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               sendTextTemplate901(msg.to, "☛ Nama : "+str(mi.displayName)+"\n☛ Mid : " +key1+"\n☛ Status Msg"+str(mi.statusMessage))
                               sendTextTemplate901(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(cl.getContact(key1)):
                                   cl.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   cl.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                        elif text.lower() == "mykey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sendTextTemplate901(msg.to, "key Now「 " + str(wait["keyCommand"]) + " 」")

                        elif cmd.startswith("setkey "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendTextTemplate901(msg.to, "ɢᴀɢᴀʟ ɴɢᴜʙᴀʜ ᴋᴇʏ")
                               else:
                                   wait["keyCommand"] = str(key).lower()
                                   sendTextTemplate901(msg.to, "sᴜᴋsᴇs ɢᴀɴᴛɪ ᴋᴇʏ「{}」".format(str(key).lower()))
#Sampul pp__
                        elif ("Sampul " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    u = key["MENTIONEES"][0]["M"]
                                    a = cl.getProfileCoverURL(mid=u)
                                    cl.sendImageWithURL(receiver, a)
                                except Exception as e:
                                    cl.sendText(receiver, str(e))

                        elif text.lower() == "resetkey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               wait["keyCommand"]=""
                               sendTextTemplate901(msg.to, "succes resset key command")

                        elif cmd == "reboot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sendTextTemplate1(msg.to, "ʀᴇsᴛᴀʀᴛ ʙᴏᴛ")
                               wait["restartPoint"] = msg.to
                               restartBot()
                               sendTextTemplate901(msg.to, "ᴅᴏɴᴇ ʙᴏs")

                        elif cmd == "bye":
                              if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                cover = cl.getProfileCoverURL(sender)
                                G = cl.getGroup(to)
                                data = {
                                "type": "flex",
                                "altText": "Wassalamu'alaikum",
                                "contents": {
"type": "carousel",
"contents": [
{
"type": "bubble",
"size": "nano",
"body": {
"backgroundColor": "#ff0000",
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 1
"animated": True,
"url": "https://i.ibb.co/2PzJWmL/ezgif-com-gif-maker.png",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "4:4",
"gravity": "bottom",
"action": {
"uri": "http://wa.me/+6285707063716",
"type": "uri",
}
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": cover, #https://obs.line-scdn.net/{}".format(cl.getContact(sender).displayName),
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:2",
"offsetTop": "0px",
"action": {
"uri": "http://www.mawoenabraids.com/images/ajax-circular.gif",
"type": "uri",
}}],
"position": "absolute",
"cornerRadius": "8px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "110px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "image", #Wall 2
"url": "https://obs.line-scdn.net/{}".format(cl.getContact(mid).pictureStatus),
"gravity": "bottom",
"size": "xxl",
"aspectMode": "cover",
"aspectRatio": "2:2",
"offsetTop": "0px",
"action": {
"uri": "http://wa.me/+6285707063716",
"type": "uri",
}}],
"position": "absolute",
"cornerRadius": "8px",
"offsetTop": "5px",
"offsetStart": "5px",
"height": "110px",
"width": "110px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "goodbye🖐️",
"weight": "bold",
"color": "#ff0000",
"align": "center",
"size": "xxs",
"offsetTop": "3px"
}
],
"position": "absolute",
"cornerRadius": "7px",
"offsetTop": "9px",
#"backgroundColor": "#33ffff",
"offsetStart": "7px",
"height": "20px",
"width": "80px"
},
{
"type": "box",
"layout": "vertical",
"contents": [ #weh
{
"type": "image",
"url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
"size": "full",
"action": {
"type": "uri",
"uri": "http://wa.me/+6285707063716",   
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
"size": "xl",
"action": {
"type": "uri",
"uri": "Https://smule.com/_BowWow",
},
"flex": 0
},{
"type": "image",
"url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
"size": "xl",
"action": {
"type": "uri",
"uri": "line://nv/cameraRoll/multi"
},
"flex": 0
},{
"type": "image",
 "url": "https://i.ibb.co/ZHtFDts/20190427-185307.png", #chathttps://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
"size": "xl",
"action": {
"type": "uri",
"uri": "line://nv/chat",
},
"flex": 0
}
],
"position": "absolute",
"offsetTop": "9px",
"offsetStart": "90px",
"height": "200px",
"width": "25px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "?? "+ datetime.strftime(timeNow,'%H:%M:%S'),
"weight": "bold",
"color": "#ff00ff",
"align": "center",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "7px",
"offsetTop": "87px",
#"backgroundColor": "#ff0000",
"offsetStart": "1px",
"height": "15px",
"width": "75px"
},
{
"type": "box",
"layout": "vertical",
"contents": [
{
"type": "text",
"text": "📆 "+ datetime.strftime(timeNow,'%Y-%m-%d'),
"weight": "bold",
"color": "#ff00ff",
"size": "xxs",
"offsetTop": "0px"
}
],
"position": "absolute",
"cornerRadius": "7px",
"offsetTop": "98px",
#"backgroundColor": "#0000ff",
"offsetStart": "7px",
"height": "15px",
"width": "90px"
}
],
#"backgroundColor": "#ff0000",
"paddingAll": "0px"
}
},
]
}
}
                                cl.postTemplate(to, data)
                                cl.leaveGroup(to)

                        elif text.lower() == "byeall":
                            if msg._from in admin:
                                gid = cl.getGroupIdsJoined()
                                for i in gid:
                                    k1.leaveGroup(i)
                                    sw.leaveGroup(i)
                                    cl.sendMessage(msg.to, "ᴋɪᴛᴀ ᴘᴀᴍɪᴛ ʙᴏss..")

                        elif text.lower() == "rjall":
                            if msg._from in admin:
                                ginvited = cl.getGroupIdsInvited()
                                if ginvited != [] and ginvited != None:
                                    for gid in ginvited:
                                        cl.rejectGroupInvitation(gid)
                                    sendTextTemplate900(msg.to, "Succes Cancell {} Invite Grup".format(str(len(ginvited))))
                                else:
                                    sendTextTemplate900(msg.to, "Nothing Invited")

                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "🔽ʙᴏᴛ ʀᴜɴ : " +waktu(eltime)
                               sendTextTemplate900(msg.to,bot)

                        elif cmd == "pendingan":
                          if wait["selfbot"] == True:
                            if msg.toType == 2:
                                group = cl.getGroup(to)
                                ret_ = "╭───「 ᴘᴇɴᴅɪɴɢᴀɴ 」"
                                no = 0
                                if group.invitee is None or group.invitee == []:
                                    return cl.sendReplyMessage(msg_id, to, "ᴋᴏsᴏɴɢ ʙᴏs..")
                                else:
                                    for pending in group.invitee:
                                        no += 1
                                        ret_ += "\n├≽ {}. {}".format(str(no), str(pending.displayName))
                                    ret_ += "\n╰───「 Total {} Pending 」".format(str(len(group.invitee)))
                                    #cl.sendReplyMessage(msg_id, to, str(ret_))
                                    data = {
                                        "type": "text",
                                        "text": "{}".format(str(ret_)),
                                        "sentBy": {
                                            "label": "Adventure",
                                            "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                            "linkUrl": "http://wa.me/+6285707063716"
                                        }
                                    }
                                    cl.postTemplate(to, data)



                        elif cmd == "listmem":
                          if msg._from in admin:
                            if msg.toType == 2:
                                group = cl.getGroup(to)
                                num = 0
                                ret_ = "╔══[ List Member ]"
                                for contact in group.members:
                                    num += 1
                                    ret_ += "\n╠ {}. {}".format(num, contact.displayName)
                                ret_ += "\n╚══[ Total {} Members]".format(len(group.members))
                                sendTextTemplate002(to, ret_)

                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = cl.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                cl.sendMessage(msg.to, "  •⌻「Grup Info」⌻•\n\n Nama Group : {}".format(G.name)+ "\nID Group : {}".format(G.id)+ "\nPembuat : {}".format(G.creator.displayName)+ "\nWaktu Dibuat : {}".format(str(timeCreated))+ "\nJumlah Member : {}".format(str(len(G.members)))+ "\nJumlah Pending : {}".format(gPending)+ "\nGroup Qr : {}".format(gQr)+ "\nGroup Ticket : {}".format(gTicket))
                                cl.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                cl.sendMessage(msg.to, str(e))

                        elif cmd.startswith("infogrup"):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(danil.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "╔══「 Info Group 」"
                                ret_ += "\n┣[]► Nama Group : {}".format(G.name)
                                ret_ += "\n┣[]► ID Group : {}".format(G.id)
                                ret_ += "\n┣[]► Pembuat : {}".format(gCreator)
                                ret_ += "\n┣[]► Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n┣[]► Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n┣[]► Jumlah Pending : {}".format(gPending)
                                ret_ += "\n┣[]► Group Qr : {}".format(gQr)
                                ret_ += "\n┣[]► Group Ticket : {}".format(gTicket)
                                ret_ += "\n╚══「 Info Finish 」"
                                sendTextTemplate901(to, str(ret_))
                            except:
                                pass

                        elif cmd.startswith("infomem"):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = denal.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n┣[]► "+ str(no) + ". " + mem.displayName
                                sendTextTemplate002(to,"╔══「 Group Info 」\n┣[]► Group Name : " + str(G.name) + "\n┣══「Member List」" + ret_ + "\n╚══「Total %i Members」" % len(G.members))
                            except:
                                pass
                        elif cmd == "flist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getAllContactIds()
                               for i in gid:
                                   G = cl.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠[]► " + str(a) + ". " +G.displayName+ "\n"
                               sendTextTemplate002(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")
                        elif cmd == "gl1":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = k1.getGroupIdsJoined()
                               for i in gid:
                                   G = k1.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "┣[]► " + str(a) + ". " +G.name+ "\n"
                               k1.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "gl2":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = sw.getGroupIdsJoined()
                               for i in gid:
                                   G = sw.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "┣[]► " + str(a) + ". " +G.name+ "\n"
                               sw.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd.startswith("k1 in"):
                             if msg._from in admin:
                                sep = msg.text.split(" ")
                                number = msg.text.replace(sep[0] + " ","")
                                bolo = k1.getGroupIdsJoined()
                                try:
                                    group = bolo[int(number)-1+0]
                                    G = k1.getGroup(group)
                                    gid = G.id
                                    no = 0 + 1
                                    k1.findAndAddContactsByMid(sender)
                                    k1.inviteIntoGroup(gid, [sender])
                                    k1.sendMessage(to,"sᴜᴄᴄᴇss ɪɴᴠɪᴛᴇ: "+str(G.name))
                                except Exception as e:
                                    k1.sendMessage(msg.to, str(e))
                        elif cmd.startswith("sw in "):
                             if msg._from in admin:
                                sep = msg.text.split(" ")
                                number = msg.text.replace(sep[0] + " ","")
                                bolo = sw.getGroupIdsJoined()
                                try:
                                    group = bolo[int(number)-1+0]
                                    G = sw.getGroup(group)
                                    gid = G.id
                                    no = 0 + 1
                                    sw.findAndAddContactsByMid(sender)
                                    sw.inviteIntoGroup(gid, [sender])
                                    sw.sendMessage(to,"sᴜᴄᴄᴇss ɪɴᴠɪᴛᴇ: "+str(G.name))
                                except Exception as e:
                                    sw.sendMessage(msg.to, str(e))

                        elif cmd == "addbot":
                            try:
                                cl.sendMessage(msg.to, "ᴛᴜɴɢɢᴜ 5 ᴍᴇɴɪᴛ..")
                                cl.findAndAddContactsByMid(Amid)
                                time.sleep(5)
                                cl.findAndAddContactsByMid(Zmid)
                                time.sleep(5)
                                k1.findAndAddContactsByMid(mid)
                                time.sleep(5)
                                k1.findAndAddContactsByMid(Zmid)
                                time.sleep(5)
                                sw.findAndAddContactsByMid(mid)
                                time.sleep(5)
                                sw.findAndAddContactsByMid(Amid)
                                time.sleep(5)
                                cl.sendMessage(to, "sᴜᴄᴄᴇss ✓") 
                                k1.sendMessage(to, "sᴜᴄᴄᴇss ✓")
                                sw.sendMessage(to, "sᴜᴄᴄᴇss ✓")
                            except:
                                cl.sendMessage(to, "sᴜᴄᴄᴇss ✓") 
                                k1.sendMessage(to, "sᴜᴄᴄᴇss ✓")
                                sw.sendMessage(to, "sᴜᴄᴄᴇss ✓")

                        if cmd == "friend1": 
                          if msg._from in admin:
                            contactlist = k1.getAllContactIds()
                            kontak = k1.getContacts(contactlist)
                            num=1
                            msgs="『FRIENDLIST』\n\n"
                            for ids in kontak:
                                msgs+="\n%i. %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+="\n\nTotal Friend : %i" % len(kontak)
                            k1.sendMessage(to, msgs)
                        if cmd == "friend2": 
                          if msg._from in admin:
                            contactlist = sw.getAllContactIds()
                            kontak = sw.getContacts(contactlist)
                            num=1
                            msgs="『FRIENDLIST』\n\n"
                            for ids in kontak:
                                msgs+="\n%i. %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+="\n\nTotal Friend : %i" % len(kontak)
                            sw.sendMessage(to, msgs)

                        elif "Invite " in msg.text:
                            if msg._from in admin:                                                                                                                                       
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]                                                                                                                                
                               targets = []
                               for x in key["MENTIONEES"]:                                                                                                                                  
                                   targets.append(x["M"])
                               for target in targets:                                                                                                                                       
                                   try:
                                      cl.findAndAddContactsByMid(target)
                                      cl.inviteIntoGroup(msg.to,[target])
                                   except:
                                       pass

                        elif cmd == "gl":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsJoined()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "┣[]► " + str(a) + ". " +G.name+ "\n"
                               cl.sendMessage(msg.to,"╔══[ ᴍʏ ɢʀᴏᴜᴘ ]\n║\n"+ma+"║\n╚══[ ᴛᴏᴛᴀʟ ɢᴄ「"+str(len(gid))+"」ʀᴏᴏᴍ ]")

                        elif cmd == "link":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   cl.updateGroup(X)
                                gurl = cl.reissueGroupTicket(msg.to)
                                cl.sendMessage(msg.to,"line://ti/g/" + gurl)

                        elif cmd == "open":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   if X.preventedJoinByTicket == True:
                                       X.preventedJoinByTicket = False
                                       cl.updateGroup(X)
                                gurl = cl.reissueGroupTicket(msg.to)
                                cl.sendMessage(msg.to, "ɢʀᴏᴜᴘ : "+str(X.name)+ "\nʟɪɴᴋ ɢᴄ : http://line.me/R/ti/g/"+gurl)

                        elif cmd == "close":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   cl.updateGroup(X)
                                   sendTextTemplate900(msg.to, "ʟɪɴᴋ ᴅɪᴛᴜᴛᴜᴘ..")

                        elif cmd == "reject":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              ginvited = cl.getGroupIdsInvited()
                              if ginvited != [] and ginvited != None:
                                  for gid in ginvited:
                                      cl.rejectGroupInvitation(gid)
                                  sendTextTemplate900(to, "ᴛᴏᴛᴀʟ {} ɢʀᴏᴜᴘ".format(str(len(ginvited))))
                              else:
                                  sendTextTemplate900(to, "ʙᴇʀsɪʜ")
#===========BOT UPDATE============#
                        elif cmd == "upgrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                cl.sendMessage(msg.to,"☛ sᴇɴᴅ ᴘɪᴄᴛᴜʀᴇ")

                        elif cmd == "foto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAfoto"][mid] = True
                                sendTextTemplate1(msg.to,"☛ sᴇɴᴅ ᴘɪᴄᴛᴜʀᴇ")
                        elif cmd == "foto1":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAfoto"][Amid] = True
                                k1.sendMessage(msg.to,"☛ sᴇɴᴅ ᴘɪᴄᴛᴜʀᴇ")      
                        elif cmd == "foto2":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAfoto"][Zmid] = True
                                sw.sendMessage(msg.to,"☛ sᴇɴᴅ ᴘɪᴄᴛᴜʀᴇ")
                        elif cmd.startswith("myname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                cl.sendMessage(msg.to,"Nama diganti jadi " + string + "")
                        elif cmd.startswith("name1: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = k1.getProfile()
                                profile.displayName = string
                                k1.updateProfile(profile)
                                k1.sendMessage(msg.to,"Nama diganti jadi " + string + "")       
                        elif cmd.startswith("name2: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = sw.getProfile()
                                profile.displayName = string
                                sw.updateProfile(profile)
                                sw.sendMessage(msg.to,"Nama diganti jadi " + string + "")
                        elif cmd == "s on":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              wait["cctv"] == False
                              wait["cctm"] == True
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  sendTextTemplate900(msg.to, "►ᴅᴇᴛᴇᴄᴛ ᴄᴄᴛᴠ ᴏɴ►")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == "s off":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              wait["cctv"] == True
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  sendTextTemplate900(msg.to, "►sɪᴅᴇʀ ᴡᴇs ᴏғғ►")
                              else:
                                  sendTextTemplate900(msg.to, "☑️ Done off")       
                        elif cmd == "s2 on":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              wait["cctm"] == False
                              wait["cctv"] == True
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  sendTextTemplate900(msg.to, "►sɪᴅᴇʀ2 ɴʏᴀʟᴀ ʙᴏs►")
                                  del cctm['point1'][msg.to]
                                  del cctm['sidermem1'][msg.to]
                                  del cctm['cyduk1'][msg.to]
                              except:
                                  pass
                              cctm['point1'][msg.to] = msg.id
                              cctm['sidermem1'][msg.to] = ""
                              cctm['cyduk1'][msg.to]=True

                        elif cmd == "s2 off":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              wait["cctm"] == True
                              if msg.to in cctm['point1']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctm['cyduk1'][msg.to]=False
                                  sendTextTemplate900(msg.to, "►sɪᴅᴇʀ2 ᴍᴏᴅᴀʀ►")
                              else:
                                  sendTextTemplate900(msg.to, "☑️Done off")
#_______________[ Remote Sider to Group ]____________#
                        elif text.lower().startswith("son "):
                         if msg._from in admin:
                           sep = text.split(" ")
                           query = text.replace(sep[0] + " ","")
                           groups = cl.getGroupIdsJoined()
                           listGroup = groups[int(query)-1]
                           G = cl.getGroup(listGroup)
                           try:
                               tz = pytz.timezone("Asia/Jakarta")
                               timeNow = datetime.now(tz=tz)
                               sendTextTemplate011(to, "sᴜᴄᴄᴇs ɴʏɪᴅᴇʀ ᴏɴ ᴛᴏ "+str(G.name))
                               del cctv['point'][listGroup]
                               del cctv['sidermem'][listGroup]
                               del cctv['cyduk'][listGroup]
                           except:
                               pass
                           cctv['point'][listGroup] = msg.id
                           cctv['sidermem'][listGroup] = ""
                           cctv['cyduk'][listGroup]=True

                        elif text.lower().startswith("soff "):
                         if msg._from in admin:
                           sep = text.split(" ")
                           query = text.replace(sep[0] + " ","")
                           groups = cl.getGroupIdsJoined()
                           listGroup = groups[int(query)-1]
                           G = cl.getGroup(listGroup)
                           try:
                               tz = pytz.timezone("Asia/Jakarta")
                               timeNow = datetime.now(tz=tz)
                               sendTextTemplate011(to, "ᴅᴏɴᴇ ᴏғғ sɪᴅᴇʀ ᴛᴏ "+str(G.name))
                               cctv['point'][listGroup] = msg.id
                               cctv['sidermem'][listGroup] = ""
                               cctv['cyduk'][listGroup]=False
                           except:
                               pass
#_______________[ Remote Sider to Group ]____________#
                        elif text.lower().startswith("s2on "):
                         if msg._from in admin:
                           sep = text.split(" ")
                           query = text.replace(sep[0] + " ","")
                           groups = cl.getGroupIdsJoined()
                           listGroup = groups[int(query)-1]
                           G = cl.getGroup(listGroup)
                           try:
                               tz = pytz.timezone("Asia/Jakarta")
                               timeNow = datetime.now(tz=tz)
                               sendTextTemplate011(to, "ᴅᴏɴᴇ ᴏɴ sɪᴅᴇʀ2 ᴛᴏ "+str(G.name))
                               del cctm['point1'][listGroup]
                               del cctm['sidermem1'][listGroup]
                               del cctm['cyduk1'][listGroup]
                           except:
                               pass
                           cctm['point1'][listGroup] = msg.id
                           cctm['sidermem1'][listGroup] = ""
                           cctm['cyduk1'][listGroup]=True

                        elif text.lower().startswith("s2off "):
                         if msg._from in admin:
                           sep = text.split(" ")
                           query = text.replace(sep[0] + " ","")
                           groups = cl.getGroupIdsJoined()
                           listGroup = groups[int(query)-1]
                           G = cl.getGroup(listGroup)
                           try:
                               tz = pytz.timezone("Asia/Jakarta")
                               timeNow = datetime.now(tz=tz)
                               sendTextTemplate011(to, "ᴅᴏɴᴇ ᴏғғ sɪᴅᴇʀ2 ᴛᴏ "+str(G.name))
                               cctm['point1'][listGroup] = msg.id
                               cctm['sidermem1'][listGroup] = ""
                               cctm['cyduk1'][listGroup]=False
                           except:
                               pass
#=========== [ Hiburan] ============#
                        elif cmd.startswith("cctv metro"):
                          if msg._from in admin:
                            ret_ = "Daftar Cctv Pantura\n"
                            ret_ += "248 = Alternatif - Cibubur\n119 = Ancol - bandara\n238 = Asia afrika - Bandung"
                            ret_ += "\n276 = Asia afrika - Sudirman\n295 = Bandengan - kota\n294 = Bandengan - Selatan"
                            ret_ += "\n102 = Buncit raya\n272 = Bundaran - HI\n93 = Cideng barat\n289 = Cikini raya"
                            ret_ += "\n175 = Ciloto - Puncak\n142 = Daan mogot - Grogol\n143 = Daan mogot - Pesing"
                            ret_ += "\n204 = Mangga besar\n319 = Margaguna raya\n326 = Margonda raya\n309 = Mas Mansyur - Tn. Abang"
                            ret_ += "\n64 = Matraman\n140 = Matraman - Salemba\n284 = Metro Pdk. Indah\n191 = MT Haryono - Pancoran\n160 = Pancoran barat"
                            ret_ += "\n331 = Pejompongan - Slipi\n332 = Pejompongan - Sudirman\n312 = Perempatan pramuka\n171 = Permata hijau - Panjang"
                            ret_ += "\n223 = Pramuka - Matraman\n222 = Pramuka raya\n314 = Pramuka raya - jl. Tambak\n313 = Pramuka - Salemba raya\n130 = Puncak raya KM84"
                            ret_ += "\n318 = Radio dalam raya\n328 = RS Fatmawati - TB\n274 = Senayan city\n132 = Slipi - Palmerah\n133 = Slipi - Tomang"
                            ret_ += "\n162 = S Parman - Grogol\n324 = Sudirman - Blok M\n18 = Sudirman - Dukuh atas\n325 = Sudirman - Semanggi\n112 = Sudirman - Setiabudi"
                            ret_ += "\n246 = Sudirman - Thamrin\n320 = Sultan agung - Sudirman\n100 = Suryo pranoto\n220 = Tanjung duren\n301 = Tol kebon jeruk"
                            ret_ += "\n41 = Tomang/Simpang\n159 = Tugu Pancoran\n205 = Yos Sudarso - Cawang\n206 = Yos Sudarso - Tj. Priuk"
                            ret_ += "\nUntuk melihat cctv,\nKetik Lihat (Nomer)"                            
                            sendTextTemplate2(to, ret_)

                        elif cmd.startswith("lihat"):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            cct = msg.text.replace(sep[0] + " ","")
                            with requests.session() as s:
                                s.headers['user-agent'] = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
                                r = s.get("http://lewatmana.com/cam/{}/bundaran-hi/".format(urllib.parse.quote(cct)))
                                soup = BeautifulSoup(r.content, 'html5lib')
                                try:
                                    ret_ = "LIPUTAN CCTV TERKINI \nDaerah "
                                    ret_ += soup.select("[class~=cam-viewer-title]")[0].text
                                    ret_ += "\nCctv update per 5 menit"
                                    vid = soup.find('source')['src']
                                    ret = "Ketik Lihat nomer cctv selanjutnya"
                                    sendTextTemplate1(to, ret_)
                                    cl.sendVideoWithURL(to, vid)
                                except:
                                    sendTextTemplate901(to, "🚦ᴋᴏsᴏɴɢ ʙᴏss...")

#=======================COMAND UNSEND===============#                                    
                        elif cmd.startswith("uns"):
                         if wait["selfbot"] == True:
                          if msg._from in admin:
                                sep = msg.text.split(" ")
                                args = msg.text.replace(sep[0] + " ","")
                                mes = 0
                                cl.unsendMessage(msg.id)
                                try:
                                   mes = int(args)
                                except:
                                    mes = 1
                                M = cl.getRecentMessagesV2(to, 1001)
                                MId = []
                                for ind,i in enumerate(M):
                                    if ind == 0:
                                        pass
                                    else:
                                        if i._from == cl.profile.mid:
                                            MId.append(i.id)
                                def unsMes(id):
                                    cl.unsendMessage(id)
                                for i in MId:
                                    thread2 = threading.Thread(target=unsMes, args=(i,))
                                    thread2.start()
                                    thread2.join()
#============Comen Tag=========
                        elif text.lower() == Setmain["mentionTag"]:
                          if wait["selfbot"] == True:
                           if msg._from in admin or msg._from in staff:
                            group = cl.getGroup(to);midMembers = [contact.mid for contact in group.members]
                            data = [contact.mid for contact in group.members]
                            k = len(data)//20
                            for aa in range(k+1):
                                if aa == 0:dd= "╭─「 ᴀʙsᴇɴᴛ ᴍᴇᴍʙᴇʀ 」─";no=aa
                                else:dd = ' ';no=aa*20
                                msgas = dd
                                for i in data[aa*20 : (aa+1)*20]:
                                    no+=1
                                    if no == len(data):msgas+='\n├{}. @!\n╰─「 Adventure 」─'.format(no)
                                    else:msgas+='\n├{}. @!'.format(no)
                                cl.sendReplyMention(msg_id,to, msgas, data[aa*20 : (aa+1)*20])
                                        
                        elif msg.text.lower().startswith("tag "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               query = text.replace(sep[0] + " ","")
                               groups = cl.getGroupIdsJoined()
                               try:
                                  listGroup = groups[int(query)-1]
                                  group = cl.getGroup(listGroup)
                                  data = [contact.mid for contact in group.members]
                                  k = len(data)//20
                                  sendTextTemplate906(msg.to, "ᴅᴏɴᴇ ᴛᴀɢᴀʟʟ\nᴅɪ ɢᴄ : "+str(group.name ))
                                  for aa in range(k+1):
                                          if aa == 0:dd= "╭─「 ᴘᴇɴᴜɴɢɢᴜ ɢʀᴏᴜᴘ 」─";no=aa
                                          else:dd = ' ';no=aa*20
                                          msgas = dd
                                          for i in data[aa*20 : (aa+1)*20]:
                                                  no += 1
                                                  if no == len(data):msgas+='\n├{}. @!\n╰─「 Adventure 」─'.format(no)
                                                  else:msgas+='\n├{}. @!'.format(no)
                                          cl.sendMention(group.id, msgas, data[aa*20 : (aa+1)*20])
                               except Exception as error:
                                      logError(error)
                               pass
                        
                        elif text.lower().startswith('tag '):
                          if msg._from in admin:
                            sep = text.split(" ")
                            num = int(sep[1])                           
                            for var in range(0,num):
                               sendMentionPutra(to, to, "", "")
                        elif cmd == "." or cmd == "note":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                #cl.unsendMessage(msg.id)
                                #time.sleep(0.3)
                                NoteCreate(to,cmd,msg)
                        elif cmd == "ngenote" or cmd == "dinote":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                #cl.unsendMessage(msg.id)
                                #time.sleep(0.3)
                                NoteCreate(to,cmd,msg)
 #===========COMEND EXECUTE======
                        elif cmd.startswith('exc\n'):
                         if wait["selfbot"] == True:
                          if msg._from in admin:
                            try:
                               sep = text.split('\n')
                               putra = text.replace(sep[0] + '\n','')
                               exec(putra)
                            except Exception as e:
                               cl.sendReplyMessage(msg.id,to, "[ INFO ] Error :sᴄʀɪᴘᴛ sᴀʟᴀʜ ᴘᴇᴀ😲😭😩\n" + str(e))      
                         
                        elif cmd in ('sem','yank','purel','halo','tag'):
                              if msg._from in admin:
                                try:group = cl.getGroup(to);midMembers = [contact.mid for contact in group.members]
                                except:group = cl.getRoom(to);midMembers = [contact.mid for contact in group.contacts]
                                midSelect = len(midMembers)//20
                                for mentionMembers in range(midSelect+1):
                                    no = 0
                                    ret_ = "╭━━━━━╦════════╦━━━━━╮\n│╭━━━━━━━━━━━━━━━━━━━╮\n╠❂࿇➢Daftar_member\n│╰━━━━━━━━━━━━━━━━━━━╯\n│╭━━━━━━━━━━━━━━━━━━━╮"
                                    dataMid = []
                                    if msg.toType == 2:
                                        for dataMention in group.members[mentionMembers*20 : (mentionMembers+1)*20]:
                                            dataMid.append(dataMention.mid)
                                            no += 1
                                            ret_ += "\n"+"╠❂➢ {}. @!".format(str(no))
                                        ret_ += "\n│╰━━━━━━━━━━━━━━━━━━━╯\n│╭━━━━━━━━━━━━━━━━━━━╮\n╠❂࿇➢Total :{}Tersangka\n│╰━━━━━━━━━━━━━━━━━━━╯\n╰━━━━━╩════════╩━━━━━╯".format(str(len(dataMid)))
                                        cl.sendReplyMention(msg_id, to, ret_, dataMid)
                                    else:
                                        for dataMention in group.contacts[mentionMembers*20 : (mentionMembers+1)*20]:
                                            dataMid.append(dataMention.mid)
                                            no += 1
                                            ret_ += "\n"+"╠❂➢ {}. @!".format(str(no))
                                        ret_ += "\n│╰━━━━━━━━━━━━━━━━━━━━╯\n│╭━━━━━━━━━━━━━━━━━━━╮\n╠❂࿇➢Total:{}Tersangka\n│╰━━━━━━━━━━━━━━━━━━━━╯\n╰━━━━━╩════════╩━━━━━╯".format(str(len(dataMid)))
                                        cl.sendReplyMention(msg_id, to, ret_, dataMid)
                        elif cmd == "😂" or text.lower() == 'cipok':
                           if wait["selfbot"] == True:
                            if msg._from in admin:
                             group = cl.getGroup(msg.to)
                            nama = [contact.mid for contact in group.members]
                            k = len(nama)//20
                            for a in range(k+1):
                                txt = u''
                                s=0
                                b=[]
                                for i in group.members[a*20 : (a+1)*20]:
                                    b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                    s += 7
                                    txt += u'@Zero \n'
                                cl.sendReplyMessage(msg.id, to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)

                        elif (wait["NGENTOT"] == cmd):
                           if wait["selfbot"] == True:
                            if msg._from in admin:
                             group = cl.getGroup(msg.to)
                            nama = [contact.mid for contact in group.members]
                            k = len(nama)//20
                            for a in range(k+1):
                                txt = u''
                                s=0
                                b=[]
                                for i in group.members[a*20 : (a+1)*20]:
                                    b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                    s += 7
                                    txt += u'@Zero \n'
                                cl.sendMessage(msg.to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)

                        elif 'setmen: ' in cmd:
                           if msg._from in admin:
                              spl = cmd.replace('setmen: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti Set Tagall")
                              else:
                                  wait["NGENTOT"] = spl
                                  cl.sendMessage(msg.to, "「 sᴇᴛ ᴛᴀɢ 」\nɢᴀɴᴛɪ ᴊᴀᴅɪ :\n\n「{}」".format(str(spl)))

                        elif (wait["JANJUK"] == cmd):
                           if wait["selfbot"] == True:
                              if msg._from in admin:
                                try:group = cl.getGroup(to);midMembers = [contact.mid for contact in group.members]
                                except:group = cl.getRoom(to);midMembers = [contact.mid for contact in group.contacts]
                                midSelect = len(midMembers)//20
                                for mentionMembers in range(midSelect+1):
                                    no = 0
                                    ret_ = "╭━━━━━╦════════╦━━━━━╮\n│╭━━━━━━━━━━━━━━━━━━━╮\n╠❂࿇➢Daftar_member\n│╰━━━━━━━━━━━━━━━━━━━╯\n│╭━━━━━━━━━━━━━━━━━━━╮"
                                    dataMid = []
                                    if msg.toType == 2:
                                        for dataMention in group.members[mentionMembers*20 : (mentionMembers+1)*20]:
                                            dataMid.append(dataMention.mid)
                                            no += 1
                                            ret_ += "\n"+"╠❂➢ {}. @!".format(str(no))
                                        ret_ += "\n│╰━━━━━━━━━━━━━━━━━━━╯\n│╭━━━━━━━━━━━━━━━━━━━╮\n╠❂࿇➢Total :{}Tersangka\n│╰━━━━━━━━━━━━━━━━━━━╯\n╰━━━━━╩════════╩━━━━━╯".format(str(len(dataMid)))
                                        cl.sendReplyMention(msg_id, to, ret_, dataMid)
                                    else:
                                        for dataMention in group.contacts[mentionMembers*20 : (mentionMembers+1)*20]:
                                            dataMid.append(dataMention.mid)
                                            no += 1
                                            ret_ += "\n"+"╠❂➢ {}. @!".format(str(no))
                                        ret_ += "\n│╰━━━━━━━━━━━━━━━━━━━━╯\n│╭━━━━━━━━━━━━━━━━━━━╮\n╠❂࿇➢Total:{}Tersangka\n│╰━━━━━━━━━━━━━━━━━━━━╯\n╰━━━━━╩════════╩━━━━━╯".format(str(len(dataMid)))
                                        cl.sendReplyMention(msg_id, to, ret_, dataMid)

                        elif 'set tag2: ' in cmd:
                           if msg._from in admin:
                              spl = cmd.replace('set tag2: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti Set Tagall")
                              else:
                                  wait["JANJUK"] = spl
                                  cl.sendMessage(msg.to, "「Set Msg」\nSet Tagall diganti jadi :\n\n「{}」".format(str(spl)))

                        if cmd in [".speed","sp","speed",".sp"] or cmd== "spd":
                         if msg._from in admin:
                          wowo = time.time()
                          cl.getProfile() 
                          boww = time.time() - wowo
                          cl.sendMention(msg.to, "• User @!   \n• Speed : %.4f ♪"%(boww),[mid])
                          
                        elif cmd.startswith("cache"):
                            if msg._from in admin:
                                process = os.popen('echo 1 > /proc/sys/vm/drop_caches\necho 2 > /proc/sys/vm/drop_caches\necho 3 > /proc/sys/vm/drop_caches\n')
                                a = process.read()
                                cl.sendReplyMessage(msg.id, to, "ᴄᴀᴄʜᴇ ᴠᴘs ᴡᴇs ʀᴇsɪᴋ..")
                                process.close()
                                
                        elif text.lower() == "screen":
                            if msg._from in admin:
                                proses = os.popen("screen -list")
                                a = proses.read()
                                cl.sendMessage(to, "{}\nᴀᴅᴠᴇɴᴛᴜʀᴇ_ʙᴏᴛ".format(str(a)), contentMetadata = {'AGENT_ICON': 'http://dl.profile.line-cdn.net/'+cl.getContact(mid).pictureStatus, 'AGENT_NAME': '「 LIST SCREEN 」', 'AGENT_LINK': 'https://line.me/ti/p/{}'.format(cl.getUserTicket().id)})
                                proses.close()

                        elif cmd.startswith("clone "):
                           if msg._from in admin:
                             if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    contact = mention["M"]
                                    break
                                try:
                                    cl.cloneContactProfile(contact)
                                    ryan = cl.getContact(contact)
                                    zx = ""
                                    zxc = ""
                                    zx2 = []
                                    xpesan =  "「 Clone Profile 」\nTarget nya "
                                    ret_ = "Berhasil clone profile target"
                                    ry = str(ryan.displayName)
                                    pesan = ''
                                    pesan2 = pesan+"@x \n"
                                    xlen = str(len(zxc)+len(xpesan))
                                    xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    text = xpesan + zxc + ret_ + ""
                                    cl.sendMessage(to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                except:
                                    cl.sendMessage(msg.to, "Gagal clone profile")
                        elif text.lower() == 'restore':
                           if msg._from in admin:
                              try:
                                  clProfile.displayName = str(myProfile["displayName"])
                                  clProfile.statusMessage = str(myProfile["statusMessage"])
                                  clProfile.pictureStatus = str(myProfile["pictureStatus"])
                                  cl.updateProfileAttribute(8, clProfile.pictureStatus)
                                  cl.updateProfile(clProfile)
                                  cl.sendMessage(msg.to, sender, "「 Restore Profile 」\nNama ", " \nBerhasil restore profile")
                              except:
                                  cl.sendMessage(msg.to, "Gagal restore profile")

                        elif cmd.startswith('gift'):
                         if wait["selfbot"] == True:
                          if msg._from in admin:
                             cl.sendReplyMessage(msg.id, to, text=None, contentMetadata={'PRDID': '350d37d6-bfc9-44cb-a0d1-cf17ae3657db','PRDTYPE': 'THEME','MSGTPL': '5'}, contentType=9)

                        elif cmd.startswith("timeline: "):
                            if msg._from in admin:
                               try:
                                   sep = text.split(' ')
                                   putra = text.replace(sep[0] + " ","")
                                   cl.createGroupPost(to, str(putra))
                                   cl.sendMention(to, "•ᴜsᴇʀ : @! \n•ᴛʏᴘᴇ : ᴛɪᴍᴇ ʟɪɴᴇ🤗\n•ᴍᴇsᴀɢᴇ : {}".format(str(ardian))+"\n•sᴛᴀᴛᴜs : sᴜᴄsᴇs", [sender])
                               except Exception as e:
                                   cl.sendText(to, str(e))

                        elif cmd.startswith("lihat note"):
                            if msg._from in admin:
                               data = cl.getGroupPost(to)
                               if data['result'] != []:
                                        no = 0
                                        a = " 「 Result Note 」\n "
                                        for i in data['result']['feeds']:
                                            no += 1
                                            gtime = i['post']['postInfo']['createdTime']
                                            try:
                                                c = str(i['post']['userInfo']['nickname'])
                                            except:
                                                c = "Tidak Diketahui"
                                            a +="\n" + str(no) + ". ● Penulis : "+c
                                            a +="\n     ● Total Like : "+str(i['post']['postInfo']['likeCount'])
                                            a +="\n     ● Total Comment : "+str(i['post']['postInfo']['commentCount'])
                                            a +="\n     ● Created at : "+str(timeago.format(datetime.now(),gtime/1000)) + "\n"
                                        b ="\n●  Total "+str(data['result']['homeInfo']['postCount'])+" Note"
                                        b += "\n●  Selanjutnya Cek note [num]"
                                        sendTextTemplate901(to, a+b,)
                        elif cmd.startswith("cek note "):
                            if msg._from in admin:
                               proses = text.split(" ")
                               korban = text.replace(proses[0] + " ","")
                               korban2 = korban.split()
                               num = int(korban2[1])
                               data = cl.getGroupPost(to)
                               try:
                                   grupnya = data['result']['feeds'][num - 1]
                                   try:
                                       c = str(grupnya['post']['userInfo']['nickname'])
                                   except:
                                       c = "Tidak Diketahui"
                                   a ="\n● Penulis: "+c
                                   try:
                                      g= str(grupnya['post']['contents']['text'])
                                   except:
                                      g="None"
                                   a +="\n● Total Like: "+str(grupnya['post']['postInfo']['likeCount'])
                                   a +="\n● Total Comment: "+str(grupnya['post']['postInfo']['commentCount'])
                                   gtime = grupnya['post']['postInfo']['createdTime']
                                   a +="\n● Created "+str(timeago.format(datetime.now(),gtime/1000))
                                   a +="\n● Groups: "+cl.getGroup(msg.to).name
                                   a +="\n● Deskripsi: \n\n"+g
                                   try:
                                      for c in grupnya['post']['contents']['media']:
                                          params = {'userMid': mid, 'oid': c['objectId']}
                                          path = cl.server.urlEncode(cl.server.LINE_OBS_DOMAIN, '/myhome/h/download.nhn', params)
                                      z = "「 Detail Note 」\n"
                                      z += "● Urutan: {}".format(str(num))
                                      sendTextTemplate901( to, z+a,)
                                      if c['type'] == 'PHOTO':
                                           cl.sendImageWithURL(to, path,)
                                      else:
                                           pass
                                      if c['type'] == 'VIDEO':
                                           cl.sendVideoWithURL(to,path)
                                      else:
                                           pass
                                   except:
                                       z = "「 Detail Note 」\n"
                                       z += "● Urutan: {}".format(str(num))
                                       sendTextTemplate901( to, z+a,)
                               except Exception as e:
                                    cl.sendMessage(to,"「 Result Error 」\n"+str(e))
                        elif cmd.startswith("chat "):
                            if msg._from in admin:
                                proses = text.split(" ")
                                korban = text.replace(proses[0] + " ","")
                                korban2 = korban.split(" ")
                                ardian = korban2[1]
                                jumlah = int(korban2[0])
                                if jumlah <= 1000:
                                        for var in range(0,jumlah):
                                                cl.sendMessage(msg.to, putra)
                                else:
                                        cl.sendText(msg.to,"Jumlah melebihi 1000")

                        elif cmd.startswith("? "):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            query = msg.text.replace(sep[0] + " ","")
                            ard = "https://flamingtext.com/net-fu/proxy_form.cgi?script=water-logo&text="+query+"&_loc=generate&imageoutput=true","https://flamingtext.com/net-fu/proxy_form.cgi?script=runner-logo&text="+query+"&_loc=generate&imageoutput=true"
                            putra = random.choice(ard)
                            cl.sendImageWithURL(to, str(putra))

                        elif cmd.startswith("cekdate: "):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            tanggal = msg.text.replace(sep[0] + " ","")
                            r=requests.get('https://script.google.com/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&nama=ervan&tanggal='+tanggal)
                            data=r.text
                            data=json.loads(data)
                            ardian = "╔═[Information]═\n╠═════════"
                            lahir = "\n╠ Lahir: "+ data["data"]["lahir"]
                            usia = "\n╠ Umur: "+ data["data"]["usia"]
                            ultah = "\n╠ Birthday: "+ data["data"]["ultah"]
                            zodiak = "\n╠ Zodiak: "+ data["data"]["zodiak"]
                            iesme = "\n╠═════════\n╚═[「 The drug killer」]═"
                            sendTextTemplate901(msg.to, putra+lahir+usia+ultah+zodiak+iesme)
                        elif cmd.startswith("asmaulhusna "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              sep = msg.text.split(" ")
                              txt = msg.text.replace(sep[0] + " ","")
                              url = requests.get("http://api.aladhan.com/asmaAlHusna/{}".format(txt))
                              data = url.json()
                              result = "~ Asma Allah ke {} = ~ {} ~".format(txt,data["data"][0]["name"])
                              result += "\n~Artinya =~ {} ~".format(data["data"][0]["en"]["meaning"])
                              sendTextTemplate901(to, result)
                        elif cmd.startswith("stag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              sep = msg.text.split(" ")
                              num = int(sep[1])                           
                              if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                  names = re.findall(r'@(\w+)', text)
                                  mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                  mentionees = mention['MENTIONEES']
                                  lists = []
                                  for mention in mentionees:
                                      if mention["M"] not in lists:
                                          lists.append(mention["M"])
                                  for ls in lists:
                                      for var in range(0,num):
                                          cl.sendMention(to, "@!", [ls])
                        elif msg.text.lower().startswith("scall "):
                          if msg._from in admin:
                             sep = msg.text.split(" ")
                             num = int(sep[1])
                             cl.sendMention(to, "•ᴜsᴇʀ : @! \n•ᴛʏᴘᴇ : sᴘᴀᴍ ᴄᴀʟʟ ᴛᴏ ᴛᴀʀɢᴇᴛ\n•Jᴜᴍʟᴀʜ : {}".format(str(num))+"\n•sᴛᴀᴛᴜs : sᴜᴄsᴇs", [sender])
                             try:
                                 if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                                     names = re.findall(r'@(\w+)', text)
                                     mention = eval(msg.contentMetadata['MENTION'])
                                     mentionees = mention['MENTIONEES']
                                     lists = []
                                     for mention in mentionees:
                                         if mention["M"] not in lists:
                                             lists.append(mention["M"])
                                     for ls in lists:
                                         for var in range(0,num):
                                             group = cl.getGroup(to)
                                             members = [ls]
                                             contact = cl.getContact(ls)
                                             mids = [contact.mid]
                                             cl.acquireGroupCallRoute(msg.to)
                                             cl.inviteIntoGroupCall(to, contactIds=members)
                             except:
                                 pass                                             
                        elif cmd.startswith("scall1 "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                             if msg.toType == 2:
                                sep = msg.text.split(" ")
                                strnum = msg.text.replace(sep[0] + " ","")
                                num = int(strnum)
                                sendTextTemplate906(to, "•ᴜsᴇʀ : @! \n•ᴛʏᴘᴇ : sᴘᴀᴍ ᴄᴀʟʟ ᴍᴇᴍʙᴇʀ\n•Jᴜᴍʟᴀʜ : {}".format(str(num))+"\n•sᴛᴀᴛᴜs : sᴜᴄsᴇs", [sender])
                                for var in range(0,num):
                                    group = cl.getGroup(to)
                                    members = [mem.mid for mem in group.members]
                                    cl.acquireGroupCallRoute(to)
                                    cl.inviteIntoGroupCall(to, contactIds=members)                               
#===========COMEN PANGGILAN======
                        elif cmd.startswith("tag: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                sendTextTemplate906(msg.to,"Spamtag Diubah Menjadi " +strnum)
                        elif cmd.startswith("call: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                sendTextTemplate906(msg.to,"Spamcall Diubah Menjadi " +strnum)
                        elif cmd.startswith("tag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []                                
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(wait["limit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                cl.sendMessage1(msg)
                                            except Exception as e:
                                                cl.sendText(msg.to,str(e))
                                    else:
                                        cl.sendMessage(msg.to,"Jumlah melebihi 1000")                          
                        elif msg.text.lower().startswith("call "):
                          if msg._from in admin:
                           if msg.contentMetadata is not None and 'MENTION' in msg.contentMetadata:
                               names = re.findall(r'@(\w+)', text)
                               mention = eval(msg.contentMetadata['MENTION'])
                               mentionees = mention['MENTIONEES']
                               lists = []
                               for mention in mentionees:
                                   if mention["M"] not in lists:
                                       lists.append(mention["M"])
                               for ls in lists:
                                   contact = cl.getContact(ls)                          
                                   jmlh = int(wait["limit"])
                                   sendTextTemplate906(msg.to, "Succes {} Call Grup".format(str(wait["limit"])))
                                   if jmlh <= 1000:
                                     for x in range(jmlh):
                                         try:
                                             mids = [contact.mid]
                                             cl.acquireGroupCallRoute(msg.to)
                                             cl.inviteIntoGroupCall(msg.to,mids)
                                         except Exception as e:
                                             cl.sendMessage(msg.to,str(e))
                                     else:
                                         sendTextTemplate901(msg.to,"")
                        elif cmd == "call":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                             if msg.toType == 2:
                                group = cl.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(wait["limit"])
                                sendTextTemplate906(msg.to, "Panggilan gaib {} x done in".format(str(wait["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                        cl.acquireGroupCallRoute(to)
                                        cl.inviteIntoGroupCall(to, contactIds=members)
                                     except Exception as e:
                                        cl.sendText(msg.to,str(e))
                                else:
                                    sendTextTemplate906(msg.to,"Jumlah melebihi batas")

#==========Comen ajs masuk==={{{
                        elif cmd.startswith("ajsname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = k1.getProfile()
                                profile.displayName = string
                                k1.updateProfile(profile)
                                k1.sendMessage(msg.to,"✓sᴜᴄᴄᴇss " + string + "")
                                                                                                                 
                        elif cmd == "ajsfoto1":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changePicture"] = True
                                k1.sendMessage(msg.to,"📷 Kirim Fotonya...")                        
                                                        
                        elif cmd == "say":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                cl.unsendMessage(msg.id)
                                time.sleep(0.3)
                                try:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.inviteIntoGroup(msg.to, [Amid,Zmid])
                                    #sendTextTemplate906(msg.to,"𝑮𝒓𝒐𝒖𝒑 𝑵𝒂𝒎𝒆 :\n"+str(ginfo.name)+"\n𝑨𝒏𝒕𝒊 𝒋𝒔 𝑹𝒆𝒂𝒅𝒚..")
                                except:
                                    pass             
                        elif cmd == "!go":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                cl.unsendMessage(msg.id)
                                time.sleep(0.3)
                                try:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.inviteIntoGroup(msg.to, [Amid,Zmid])
                                    #sendTextTemplate906(msg.to,"𝑮𝒓𝒐𝒖𝒑 ??𝒂𝒎𝒆 :\n"+str(ginfo.name)+"\n𝑨𝒏??𝒊 𝒋𝒔 𝑹𝒆𝒂𝒅𝒚..")
                                except:
                                    pass
                        elif cmd == "out":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)                                
                                k1.leaveGroup(msg.to)
                                sw.leaveGroup(msg.to)
                                
                        elif cmd == "!in":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.inviteIntoGroup(msg.to, [Amid])
                                    k1.acceptGroupInvitation(msg.to)
                                    cl.inviteIntoGroup(msg.to, [Zmid])
                                    sw.acceptGroupInvitation(msg.to)
                                except:
                                    pass            
                        elif cmd == "abye":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.cancelGroupInvitation(msg.to, [Amid])
                                    cl.cancelGroupInvitation(msg.to, [Zmid])
                                    #sendTextTemplate906(msg.to,"[ ɴᴀᴍᴀ ɢʀᴏᴜᴘ ]\n"+str(ginfo.name)+"\nᴅᴏɴᴇ ᴋɪᴄᴋᴇʀ ᴀᴋᴛɪᴠᴇ ᴊs")
                                except:
                                    pass                          
                                
                        elif cmd == "k in":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = cl.getGroup(msg.to, [Amid,Zmid])
                                    cl.inviteIntoGroup(msg.to)
                                    k1.acceptGroupInvitation(msg.to)
                                    sw.acceptGroupInvitation(msg.to)
                                    sw.leaveGroup(msg.to)
                                    cl.inviteIntoGroup(msg.to, [Zmid])
                                except:
                                    pass             
                        elif cmd == "a out":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)                                
                                k1.leaveGroup(msg.to)                          
                                
                        elif cmd == "a in":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.inviteIntoGroup(msg.to, [Amid])
                                    k1.acceptGroupInvitation(msg.to)
                                    
                                except:
                                    pass

#===========REMOTE JS============#
                        elif cmd == ".wow":
                              if msg._from in settings["owner"]:
                                G = cl.getGroup(msg.to)
                                ginfo = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                sw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                cl.sendMessage(msg.to, ".sorry")
                                helpMessage2 = infomeme()
                                cl.sendMessage(msg.to, str(helpMessage2))
                                xyz = cl.getGroup(to)
                                if xyz.invitee == None:pends = []
                                else:pends = [c.mid for c in xyz.invitee]
                                targp = []
                                for x in pends:
                                  if x not in staff:
                                    if x not in admin:
                                      if x not in owner:
                                        if x not in creator:
                                          targp.append(x)
                                mems = [c.mid for c in xyz.members]
                                targk = []
                                for x in mems:
                                  if x not in staff:
                                    if x not in admin:
                                      if x not in owner:
                                        if x not in creator:
                                          targk.append(x)
                                imnoob = 'dual.js gid={} token={}'.format(to, cl.authToken)
                                for x in targp:imnoob += ' uid={}'.format(x)
                                for x in targk:imnoob += ' uik={}'.format(x)
                                execute_js(imnoob)    
                        elif text.lower() == Setmain["roySruduk"]:
                         if msg._from in admin:
                          xyz = cl.getGroup(to)
                          mem = [c.mid for c in xyz.members]
                          targets = []
                          for x in mem:
                            if x not in ["u268d41d7aeac51df11cb9b8715b251a8",cl.profile.mid]:targets.append(x)
                          if targets:
                            lolz = 'simple.js gid={} token={} app={}'.format(to, cl.authToken, "DESKTOPWIN\t5.20.2\tWindows\t10")
                            for target in targets:
                              lolz += ' uid={}'.format(target)
                            success = execute_js(lolz)
                            if success:cl.sendMention(to, "•ᴜsᴇʀ : @! \n•ᴛʏᴘᴇ : ᴍisɪᴏɴ js room👍\n•Jᴜᴍʟᴀʜ : %i" % len(targets)+"\n•sᴛᴀᴛᴜs : sᴜᴄsᴇs", [sender])
                            else:cl.sendMessage(to, "Failed kick %i members." % len(targets))
                          else:cl.sendMessage(to, "Target not found.")
                        elif text.lower() == Setmain["roySruduk"]:
                         if msg._from in admin:
                          xyz = cl.getGroup(to)
                          if xyz.invitee == None:pends = []
                          else:pends = [c.mid for c in xyz.invitee]
                          targp = []
                          for x in pends:
                            if x not in staff:
                              if x not in admin:
                                if x not in owner:
                                  if x not in creator:
                                    targp.append(x)
                          mems = [c.mid for c in xyz.members]
                          targk = []
                          for x in mems:
                            if x not in staff:
                              if x not in admin:
                                if x not in owner:
                                  if x not in creator:
                                    targk.append(x)
                          lolz = 'dual.js gid={} token={}'.format(to, cl.authToken)
                          for x in targp:lolz += ' uid={}'.format(x)
                          for x in targk:lolz += ' uik={}'.format(x)
                          execute_js(lolz)
                        elif cmd.startswith("bypass "):
                          if msg._from in admin:
                           separate = text.split(" ")
                           number = text.replace(separate[0] + " ","")
                           groups = cl.getGroupIdsJoined()
                           listGroup = groups[int(number)-1]
                           x = cl.getGroup(listGroup)
                           if x.invitee == None:nama = []
                           else:nama = [contact.mid for contact in x.invitee]
                           targets = []
                           for a in nama:
                           	if a not in ["u268d41d7aeac51df11cb9b8715b251a8",cl.profile.mid]:targets.append(a) 
                           nami = [contact.mid for contact in x.members]
                           targetk = []
                           lolz = 'dual.js gid={} token={}'.format(x.id, cl.authToken)
                           for a in nami:
                           	if a not in ["u268d41d7aeac51df11cb9b8715b251a8",cl.profile.mid]:targetk.append(a) 
                           for y in targets:
                           	lolz += ' uid={}'.format(y)
                           for y in targetk:
                           	lolz += ' uik={}'.format(y)
                           cl.sendMessage(to,'Waiting proses...')
                           print(lolz)
                           success = execute_js(lolz)
                           if success:
                           	cl.sendMention(to, "•ᴜsᴇʀ : @! \n•ᴛʏᴘᴇ : ᴍisɪᴏɴ bypas ᴛᴀʀɢᴇᴛ🤗\n•Jᴜᴍʟᴀʜ : %i" % len(targets)+"\n•sᴛᴀᴛᴜs : sᴜᴄsᴇs", [sender])
                           else:
                           	cl.sendMessage(to,'error')

                        elif cmd.startswith("kickall "):
                          if msg._from in admin:
                           separate = text.split(" ")
                           number = text.replace(separate[0] + " ","")
                           groups = cl.getGroupIdsJoined()
                           listGroup = groups[int(number)-1]
                           x = cl.getGroup(listGroup)
                           if x.members == None:nama = []
                           else:nama = [contact.mid for contact in x.members]
                           targets = []
                           for a in nama:
                           	if a not in ["u268d41d7aeac51df11cb9b8715b251a8",cl.profile.mid]:targets.append(a)
                           if targets:
                            lolz = 'simple.js gid={} token={}'.format(x.id, cl.authToken)
                            for target in targets:
                              lolz += ' uid={}'.format(target)
                            success = execute_js(lolz)
                            if success:cl.sendMention(to, "•ᴜsᴇʀ : @! \n•ᴛʏᴘᴇ : ᴍisɪ js room👍\n•Jᴜᴍʟᴀʜ : %i" % len(targets)+"\n•sᴛᴀᴛᴜs : sᴜᴄsᴇs", [sender])
                            else:cl.sendMessage(to, "Failed kick %i members." % len(targets))
                        elif cmd.startswith("lock "):
                          if msg._from in admin:
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = cl.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           imnoob = 'simple.js gid={} token={} app={}'.format(to, cl.authToken, "DESKTOPWIN\t5.20.2\tWindows\t10")
                           for x in members:
                               contact = cl.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                                   #print(testt)
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return cl.sendMessage(to,"not found name "+midn)
                           for target in targets:
                             imnoob += ' uid={}'.format(target)
                           success = execute_js(imnoob)
                        elif cmd == ".gowes":
                          if msg._from in admin:
                           cl.unsendMessage(msg.id)
                           time.sleep(0.3)
                           xyz = cl.getGroup(to)
                           mem = [c.mid for c in xyz.members]
                           targets = []
                           for x in mem:
                             if x not in ["ud9d27e76bcbf2a8a5bb324c09cf2cd29",cl.profile.mid]:targets.append(x)
                           if targets:
                             imnoob = 'simple.js gid={} token={} app={}'.format(to, cl.authToken, "DESKTOPWIN\t5.20.2\tWindows\t1")
                             for target in targets:
                               imnoob += ' uid={}'.format(target)
                             success = execute_js(imnoob)
                             if success:eric.sendMessage(to, "Success kick %i members." % len(targets))
                             else:cl.sendMessage(to, "Failed kick %i members." % len(targets))
                           else:cl.sendMessage(to, "Target not found.")
                        elif cmd == ".lokdon":
                          if msg._from in admin:
                           xyz = cl.getGroup(to)
                           if xyz.invitee == None:pends = []
                           else:pends = [c.mid for c in xyz.invitee]
                           targp = []
                           for x in pends:
                             if x not in ["ud9d27e76bcbf2a8a5bb324c09cf2cd29",cl.profile.mid]:targp.append(x)
                           mems = [c.mid for c in xyz.members]
                           targk = []
                           for x in mems:
                             if x not in ["ud9d27e76bcbf2a8a5bb324c09cf2cd29",cl.profile.mid]:targk.append(x)
                           imnoob = 'dual.js gid={} token={}'.format(to, cl.authToken)
                           for x in targp:imnoob += ' uid={}'.format(x)
                           for x in targk:imnoob += ' uik={}'.format(x)
                           execute_js(imnoob)
                        elif cmd.startswith("@kick "):
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = cl.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           imnoob = 'simple.js gid={} token={} app={}'.format(to, cl.authToken, "DESKTOPWIN\t5.20.2\tWindows\t1")
                           for x in members:
                               contact = cl.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                                   #print(testt)
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return cl.sendMessage(to,"not found name "+midn)
                           for target in targets:
                             imnoob += ' uid={}'.format(target)
                           success = execute_js(imnoob)
         
                        elif cmd == ".jos" or cmd == ".oleng":
                          if msg._from in admin:
                            xyz = cl.getGroup(to)
                            if xyz.invitee == None:pends = []
                            else:pends = [c.mid for c in xyz.invitee]
                            targp = []
                            for x in pends:
                            	if x not in admin:
                                    targp.append(x)
                            mems = [c.mid for c in xyz.members]
                            targk = []
                            for x in mems:
                            	if x not in admin:
                                    targk.append(x)
                            imnoob = 'simple.js gid={} token={} app={}'.format(to, cl.authToken, "DESKTOPWIN\t5.20.2\tWindows\t10")
                            for x in targp:imnoob += ' uid={}'.format(x)
                            for x in targk:imnoob += ' uik={}'.format(x)
                            execute_js(imnoob)
                        elif cmd == "kjs":
                          if msg._from in admin:
                           #cl.unsendMessage(msg.id)
                           #time.sleep(0.3)
                           xyz = k1.getGroup(to)
                           mem = [c.mid for c in xyz.members]
                           targets = []
                           for x in mem:
                             if x not in ["ud9d27e76bcbf2a8a5bb324c09cf2cd29",k1.profile.mid]:targets.append(x)
                           if targets:
                             imnoob = 'simple.js gid={} token={} app={}'.format(to, k1.authToken, "DESKTOPWIN\t5.20.2\tWindows\t10")
                             for target in targets:
                               imnoob += ' uid={}'.format(target)
                             success = execute_js(imnoob)
                             if success:eric.sendMessage(to, "Success kick %i members." % len(targets))
                             else:k1.sendMessage(to, "Failed kick %i members." % len(targets))
                           else:k1.sendMessage(to, "Target not found.")
#===========Protection============#
                        elif 'Welcome ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "Welcome Msg sudah aktif"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Welcome Msg diaktifkan\nDi Group : " +str(ginfo.name)
                                  sendTextTemplate906(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Welcome Msg dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Welcome Msg sudah tidak aktif"
                                    sendTextTemplate906(msg.to, "「Dinonaktifkan」\n" + msgs)
                                    
                        elif 'Proqr ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Proqr ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = "Protect url sudah aktif"
                                  else:
                                       protectqr.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect url diaktifkan\nDi Group : " +str(ginfo.name)
                                  sendTextTemplate906(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect url dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect url sudah tidak aktif"
                                    sendTextTemplate906(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Prokick ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Prokick ','')
                              if spl == 'on':
                                  if msg.to in protectkick:
                                       msgs = "Protect kick sudah aktif"
                                  else:
                                       protectkick.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect kick diaktifkan\nDi Group : " +str(ginfo.name)
                                  sendTextTemplate906(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect kick dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect kick sudah tidak aktif"
                                    sendTextTemplate906(msg.to, "「Dinonaktifkan」\n" + msgs)
                                    
                        elif 'Proinvite ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Proinvite ','')
                              if spl == 'on':
                                  if msg.to in protectinvite:
                                       msgs = "Protect invite sudah aktif"
                                  else:
                                       protectinvite.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect invite diaktifkan\nDi Group : " +str(ginfo.name)
                                  sendTextTemplate906(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect invite dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect invite sudah tidak aktif"
                                    sendTextTemplate906(msg.to, "「Dinonaktifkan」\n" + msgs)           

                        elif 'Projoin ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Projoin ','')
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = "Protect join sudah aktif"
                                  else:
                                       protectjoin.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect join diaktifkan\nDi Group : " +str(ginfo.name)
                                  sendTextTemplate906(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect join dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect join sudah tidak aktif"
                                    sendTextTemplate906(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Procancel ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Procancel ','')
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "Protect cancel sudah aktif"
                                  else:
                                       protectcancel.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect cancel diaktifkan\nDi Group : " +str(ginfo.name)
                                  sendTextTemplate906(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect cancel dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect cancel sudah tidak aktif"
                                    sendTextTemplate906(msg.to, "「Dinonaktifkan」\n" + msgs)
                                                                                                                                                     
                        elif 'Allpro ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Allpro ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = ""
                                  else:
                                       protectqr.append(msg.to)
                                  if msg.to in protectkick:
                                      msgs = ""
                                  else:
                                  	protectinvite.append(msg.to)
                                  if msg.to in protectkick:
                                      msgs = ""
                                  else:
                                      protectkick.append(msg.to)
                                  if msg.to in protectjoin:
                                      msgs = ""
                                  else:
                                      protectjoin.append(msg.to)
                                  if msg.to in protectcancel:
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "Semua protect sudah on\nDi Group : " +str(ginfo.name)
                                  else:
                                      protectcancel.append(msg.to)
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "Berhasil mengaktifkan semua protect\nDi Group : " +str(ginfo.name)
                                  sendTextTemplate906(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                    else:
                                    	msgs = ""
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Berhasil menonaktifkan semua protect\nDi Group : " +str(ginfo.name)
                                    else:
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Semua protect sudah off\nDi Group : " +str(ginfo.name)
                                    sendTextTemplate906(msg.to, "「Dinonaktifkan」\n" + msgs)            
#===============Coment kick one============
                        elif ("Kiss" in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in admin:
                                       try:
                                       	cl.kickoutFromGroup(msg.to,[target])
                                       except:
                                           sendTextTemplate900(msg.to,"Sorry kaki saya struk..")

                        elif "Gkick " in msg.text:
                           if msg._from in admin:
                              key = eval(msg.contentMetadata["MENTION"])
                              key["MENTIONEES"][0]["M"]                                                                                                                                
                              targets = []
                              for x in key["MENTIONEES"]:
                                  targets.append(x["M"])
                              for target in targets:                                                                                                                                       
                                  try:
                                      cl.kickoutFromGroup(msg.to,[target])
                                      cl.findAndAddContactsByMid(target)
                                      cl.inviteIntoGroup(msg.to,[target])
                                      cl.cancelGroupInvitation(msg.to,[target])
                                  except:
                                      pass
                                      
                        elif cmd == "gelapp":
                          if wait["selfbot"] == True:                            
                               cl.sendMessage(msg.to, "ngeblank ya brooo maaf broo layar hpnya aq pinjam bentar    ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.👿.👿.👿 ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.")
                        elif cmd == "blenkk":
                          if wait["selfbot"] == True:                            
                               cl.sendMessage(msg.to, "nyaman nyaman nyaman nyaman nyaman nyaman    ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.👿.👿.👿 ❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.👿.👿.\n❌.👁️.★.★.★.👁️.❌.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.0.S.1.☆.👿.??.👿.")
#========COMEN RESPON======#
                        elif msg.text in ["Kempit"]:
                            if msg._from in admin:
                                wait["Invi"] = True
                                sendTextTemplate900(msg.to,"sᴇɴᴅ ᴄᴏɴᴛᴀᴄᴛ")
                        elif msg.text in ["Kempit off"]:
                            if msg._from in admin:
                                wait["Invi"] = False
                                sendTextTemplate900(msg.to,"Gak jadi ngempit Lur")        
                        elif cmd == "r on" or text.lower() == 'respon on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = True
                                wait["detectMention2"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "r2 on" or text.lower() == 'respon2 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention2"] = True
                                wait["detectMention"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ2 ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "r off" or text.lower() == 'respon off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "r2 off" or text.lower() == 'respon2 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention2"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ2 ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "r3 on" or text.lower() == 'respon3 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention3"] = True
                                wait["detectMention2"] = False
                                wait["detectMention"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ3 ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "r3 off" or text.lower() == 'respon3 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention3"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ3 ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "r4 on" or text.lower() == 'respon4 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention4"] = True
                                wait["detectMention3"] = False
                                wait["detectMention2"] = False
                                wait["detectMention"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ4 ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "r4 off" or text.lower() == 'respon4 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention4"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ4 ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "r5 on" or text.lower() == 'respon5 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention5"] = True
                                wait["detectMention4"] = False
                                wait["detectMention3"] = False
                                wait["detectMention2"] = False
                                wait["detectMention"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ5 ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "r5 off" or text.lower() == 'respon5 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention5"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ5 ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "r6 on" or text.lower() == 'respon6 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention6"] = True
                                wait["detectMention7"] = False
                                wait["detectMention5"] = False
                                wait["detectMention4"] = False
                                wait["detectMention3"] = False
                                wait["detectMention2"] = False
                                wait["detectMention"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ6 ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "r6 off" or text.lower() == 'respon6 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention6"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ6 ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "r7 on" or text.lower() == 'respon7 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention7"] = True
                                wait["detectMention8"] = False
                                wait["detectMention6"] = False
                                wait["detectMention5"] = False
                                wait["detectMention4"] = False
                                wait["detectMention3"] = False
                                wait["detectMention2"] = False
                                wait["detectMention"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ7 ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "r7 off" or text.lower() == 'respon7 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention7"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ7 ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "r8 on" or text.lower() == 'respon8 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention8"] = True
                                wait["detectMention7"] = False
                                wait["detectMention6"] = False
                                wait["detectMention5"] = False
                                wait["detectMention4"] = False
                                wait["detectMention3"] = False
                                wait["detectMention2"] = False
                                wait["detectMention"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ8 ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "r8 off" or text.lower() == 'respon8 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention8"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ8 ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "r9 on" or text.lower() == 'respon9 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention9"] = True
                                wait["detectMention8"] = False
                                wait["detectMention7"] = False
                                wait["detectMention6"] = False
                                wait["detectMention5"] = False
                                wait["detectMention4"] = False
                                wait["detectMention3"] = False
                                wait["detectMention2"] = False
                                wait["detectMention"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ9 ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "r9 off" or text.lower() == 'respon9 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention9"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ9 ᴍᴏᴅᴇ ᴏғғ") 
                                #==
                        elif cmd == "sm on" or text.lower() == '!smule on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sharesmule"] = True                          
                                cl.sendReplyMessage(msg.id, to, "notif smule on")

                        elif cmd == "sm off" or text.lower() == '!smule off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sharesmule"] = False
                                cl.sendReplyMessage(msg.id, to, "Smule off")
                        elif cmd == "notag on" or text.lower() == 'notag on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = True
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴᴛᴀɢ ᴋɪᴄᴋ ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "notag off" or text.lower() == 'notag off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴᴛᴀɢ ᴋɪᴄᴋ ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                sendTextTemplate900(msg.to,"ʀᴇsᴘᴏɴ ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                sendTextTemplate900(msg.to,"ᴀᴜᴛᴏᴊᴏɪɴ ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                sendTextTemplate900(msg.to,"ᴀᴜᴛᴏᴊᴏɪɴ ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "notif on" or text.lower() == 'notif on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["nCall"] = True
                                sendTextTemplate900(msg.to,"notifcall ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "notif off" or text.lower() == 'notif off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["nCall"] = False
                                sendTextTemplate900(msg.to,"notifcall ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                sendTextTemplate900(msg.to,"ʟᴇᴀᴠᴇ ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                sendTextTemplate900(msg.to,"ʟᴇᴀᴠᴇ ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                sendTextTemplate900(msg.to,"ᴀᴅᴅ ᴍᴏᴅᴇ ᴏn")
                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                sendTextTemplate900(msg.to,"ᴀᴅᴅ ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = True
                                sendTextTemplate900(msg.to,"sᴛɪᴄᴋᴇʀ ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = False
                                sendTextTemplate900(msg.to,"sᴛɪᴄᴋᴇʀ ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "stc on" or text.lower() == 'st on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["jumbosticker"] = True
                                sendTextTemplate900(msg.to,"sᴛɪᴄᴋᴇʀ ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "stc off" or text.lower() == 'st off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["jumbosticker"] = False
                                sendTextTemplate900(msg.to,"sᴛɪᴄᴋᴇʀ ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = True
                                sendTextTemplate900(msg.to,"ᴊᴏɪɴᴛɪᴄᴋᴇᴛ ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = False
                                sendTextTemplate900(msg.to,"ᴊᴏɪɴᴛɪᴄᴋᴇᴛ ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "autoblock on" or text.lower() == 'autoblock on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = True
                                sendTextTemplate900(msg.to,"ʙʟᴏᴄᴋ ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "autoblock off" or text.lower() == 'autoblock off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoBlock"] = False
                                sendTextTemplate900(msg.to,"ʙʟᴏᴄᴋ ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "post on" or text.lower() == 'post on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["checkPost"] = True
                                sendTextTemplate900(msg.to,"ᴀᴜᴛᴏ ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "post off" or text.lower() == 'post off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["checkPost"] = False
                                sendTextTemplate900(msg.to,"ᴀᴜᴛᴏ ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "like on" or text.lower() == 'like on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["likeon"] = True
                                sendTextTemplate900(msg.to,"ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "like off" or text.lower() == 'like off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["likeon"] = False
                                sendTextTemplate900(msg.to,"ᴘᴏsᴛ ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "sambutan on" or text.lower() == 'wlcm on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["welcomeOn"] = True
                                sendTextTemplate900(msg.to,"welcome ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "sambutan off" or text.lower() == 'wlcm off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["welcomeOn"] = False
                                sendTextTemplate900(msg.to,"welcome ᴍᴏᴅᴇ ᴏғғ")   
                        elif cmd == "yt on" or text.lower() == 'ytube on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["ytube"] = True
                                sendTextTemplate900(msg.to,"linkyt ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "yt off" or text.lower() == 'ytube off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["ytube"] = False
                                sendTextTemplate900(msg.to,"linkyt ᴍᴏᴅᴇ ᴏғғ")         
                        elif cmd == "bck on" or text.lower() == 'backup on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["backup"] = True
                                sendTextTemplate900(msg.to,"Backup ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "bck off" or text.lower() == 'backup off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["backup"] = False
                                sendTextTemplate900(msg.to,"Backup ᴍᴏᴅᴇ ᴏғғ")                 
                        elif cmd == "smul on" or text.lower() == 'sml on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sharesmule"] = True
                                sendTextTemplate900(msg.to,"linksmule ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "smul off" or text.lower() == 'sml off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sharesmule"] = False
                                sendTextTemplate900(msg.to,"linksmule ᴍᴏᴅᴇ ᴏғғ")   
                        elif cmd == "leave on" or text.lower() == 'bye on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["leaveMsg"] = True
                                sendTextTemplate900(msg.to,"leave ᴍᴏᴅᴇ ᴏɴ")
                        elif cmd == "leave off" or text.lower() == 'bye off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["leaveMsg"] = False
                                sendTextTemplate900(msg.to,"leave ᴍᴏᴅᴇ ᴏғғ")
                        elif cmd == "invite on" or text.lower() == 'invite on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = True
                                sendTextTemplate900(msg.to, "ᴋɪʀɪᴍ ᴋᴏɴᴛᴀᴋ'ɴʏᴀ")
                        elif cmd == "invite off" or text.lower() == 'invite off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = False
                                sendTextTemplate900(msg.to,"ɪɴᴠɪᴛᴇ ᴄᴏɴᴛᴀᴄᴛ ᴏɴ")
                        if cmd == "unsend on":
                            if msg._from in admin:
                                wait["Unsend"] = True
                                sendTextTemplate900(msg.to, "Unsend mode on")
                        if cmd == "unsend off":
                            if msg._from in admin:
                                wait["Unsend"] = False
                                sendTextTemplate900(msg.to, "Unsend mode off")                                 
                        elif "autoreject " in msg.text.lower():
                            xpesan = msg.text.lower()
                            xres = xpesan.replace("autoreject ","")
                            if xres == "off":
                                wait['autoReject'] = False
                                sendTextTemplate900(msg.to,"❎Reject already Off")
                            elif xres == "on":
                                wait['autoReject'] = True
                                sendTextTemplate900(msg.to,"✓Reject already On")
                        elif cmd == "blockspam on":
                           if msg._from in admin:
                               wait["spamcall"] = True
                               cl.sendMention(to, "•ᴜsᴇʀ : @! \n•ᴛʏᴘᴇ : ᴅᴇᴛᴇᴄᴛ sᴘᴀᴍ ᴄᴀʟʟ\n•sᴛᴀᴛᴜs : ᴏɴ♪", [sender])
                        elif cmd == "blockspam off":
                           if msg._from in admin:
                               wait["spamcall"] = False
                               cl.sendMention(to, "•ᴜsᴇʀ : @! \n•ᴛʏᴘᴇ : ᴅᴇᴛᴇᴄᴛ sᴘᴀᴍ ᴄᴀʟʟ\n•sᴛᴀᴛᴜs : ᴏғғ♪", [sender])        
                        elif cmd == "sibuk on":
                           if msg._from in admin:
                               wait["Busy"] = True
                               cl.sendMention(to, "•ᴜsᴇʀ : @! \n•ᴛʏᴘᴇ : ᴀᴜᴛoᴍᴀᴛɪ ᴄʜᴀᴛ ʀᴇᴘʟʏ\n•sᴛᴀᴛᴜs : ᴏɴ♪", [sender])
                        elif cmd == "sibuk off":
                           if msg._from in admin:
                               wait["Busy"] = False
                               cl.sendMention(to, "•ᴜsᴇʀ : @! \n•ᴛʏᴘᴇ : ᴀᴜᴛoᴍᴀᴛɪ ᴄʜᴀᴛ ʀᴇᴘʟʏ\n•sᴛᴀᴛᴜs : ᴏғғ♪", [sender])     
                        elif cmd == "tok on" or text.lower() == 'tik on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["tiktok"] = True
                                cl.sendReplyMessage(msg.id, to, "Respon tiktok ON")
                        elif cmd == "tok off" or text.lower() == 'tok off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["tiktok"] = False
                                cl.sendReplyMessage(msg.id, to, "Respon tiktok OFF")
                        elif cmd == "fb on" or text.lower() == 'fb on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["facebook"] = True
                                cl.sendReplyMessage(msg.id, to, "Respon Facebook ON")
                        elif cmd == "fb off" or text.lower() == 'fb off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["facebook"] = False
                                cl.sendReplyMessage(msg.id, to, "Respon Facebook OFF")
                        elif cmd == "ip on" or text.lower() == 'aip on':
                          if settings["selfbot"] == True:
                            if msg._from in admin:
                                wait["Aip"] = True
                                cl.sendReplyMessage(msg.id, to, "Respon Larangan ON")
                        elif cmd == "ip off" or text.lower() == 'aip off':
                          if settings["selfbot"] == True:
                            if msg._from in admin:
                                wait["Aip"] = False
                                cl.sendReplyMessage(msg.id, to, "Respon Larangan OFF")
#==================================#
                        elif cmd == "refresh" or text.lower() == 'ger':
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                #sendTextTemplate900(msg.to,"Clean..")
                                cl.sendReplyMessage(msg.id, to,"• Sweger Masee...")
#===========ADMIN ADD============#
                        elif ("Aadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           cl.sendReplyMessage(msg.id, to, "Berhasil nambahin admin")
                                       except:
                                           pass
                        elif ("Sadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff.append(target)
                                           sendTextTemplate900(msg.to,"✓Berhasil menambahkan staff")
                                       except:
                                           pass
                        elif ("Adell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           admin.remove(target)
                                           cl.sendReplyMessage(msg.id, to, "Succes delete admin")
                                       except:
                                           pass
                        elif ("Sdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Saints:
                                       try:
                                           staff.remove(target)
                                           sendTextTemplate900(msg.to,"✓Berhasil menghapus admin")
                                       except:
                                           pass               
                 
                        elif cmd.startswith("joox "):
                          if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                uid= msg.text.replace(sep[0] + " ","")
                                api = imjustgood("Woaini")
                                data = api.joox(format(uid))
                                r = "╭──[  Music joox  ]──"
                                r += "\n├• Title : {}".format(data["result"]["title"])
                                r += "\n├• Singer : {}".format(data["result"]["singer"])
                                r += "\n├• Duration : {}".format(data["result"]["duration"])
                                r += "\n├• Size : {}".format(data["result"]["size"])
                                r += "\n╰──[ The ɑժѵҽղԵꪊƦꫀ ]──"
                                cl.sendReplyMessage(msg.id, to,(r))
                                cl.sendAudioWithURL(to,data["result"]["m4aUrl"])
                            except Exception as error:
                                cl.sendMessage(msg.to, str(error))
                           
#==========Smule respon=========#                               
                        elif "https://www.smule.com" in msg.text.lower():
                            if wait["sharesmule"] == True:
                                time.sleep(0.3)
                                MasWowo = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                                WoyAwo = re.findall(MasWowo, text)
                                WowoGanteng = []
                                for Cuk in WoyAwo:
                                    if Cuk not in WowoGanteng:
                                        WowoGanteng.append(Cuk)
                                for BosAkuAda in WowoGanteng:
                                    CocokKan = BosAkuAda
                                    headers = {
                                        "apikey": "Woaini",
                                        "User-Agent": "Justgood/5.0"
                                    }
                                    main = json.loads(requests.get("https://api.imjustgood.com/smuledl="+CocokKan,headers=headers).text)
                                    cl.sendReplyMessage(msg.id, to, "Sedang didownloads...")
                                    if "video" in main["result"]["type"]:
                                        cl.sendVideoWithURL(to,main["result"]["mp4Url"])
                                    else:
                                        cl.sendAudioWithURL(to,main["result"]["mp3Url"])
#===========COMMAND BLACKLIST============#

                        elif ("Ban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           sendTextTemplate1(msg.to,"✓Berhasil menambahkan blacklist")
                                       except:
                                           pass
                        elif ("Unban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           sendTextTemplate900(msg.to,"✓menghapus blacklist")
                                       except:
                                           pass
                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["wblacklist"] = True
                                cl.sendReplyMessage(msg.id, to,"📲Kirim kontaknya...")
                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["dblacklist"] = True
                                sendTextTemplate900(msg.to,"📲Kirim kontaknya...")
                        elif cmd == "ban" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                sendTextTemplate900(msg.to,"Tak ada daftar buronan")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                sendTextTemplate2(msg.to,"Blacklist User\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))))

                        elif cmd == "bh" or text.lower() == 'bl':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                   sendTextTemplate900(msg.to,"kutang kosong")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = cl.getContact(i)
                                        cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                        elif cmd == "cb" or text.lower() == 'cban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = cl.getContacts(wait["blacklist"])
                              mc = "「%i」Perusuh" % len(ragets)
                              sendTextTemplate900(msg.to,"Dihapus " +mc)
#==========Setting bot========
                        elif cmd.startswith("set js: "):
                           if msg._from in admin:
                              spl = msg.text.replace('set js: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate901(msg.id,to, "Gagal mengganti key Bypass")
                              else:
                                  Setmain["roySruduk"] = spl
                                  sendTextTemplate906(msg.id,to, "Comen js diganti jadi :\n\n「{}」".format(str(spl)))
                                  
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate1(msg.to, "Gagal mengganti Pesan Msg")
                              else:
                                  wait["message"] = spl
                                  sendTextTemplate1(msg.to, "「Pesan Msg」\nPesan Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set mention: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set mention: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate901(msg.to, "Gagal mengganti mention member")
                              else:
                                  Setmain["mentionTag"] = spl
                                  sendTextTemplate901(msg.to, "-- mention--\n•Diganti jadi :\n\n「{}」".format(str(spl)))          
                                  
                        elif 'Set hapus: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set hapus: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate1(msg.to, "Gagal mengganti Pesan clear")
                              else:
                                  wait["dell"] = spl
                                  sendTextTemplate901(msg.to, "「clear」\clearl diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate906(msg.to, "Gagal mengganti Pesan Msg")
                              else:
                                  wait["message"] = spl
                                  sendTextTemplate906(msg.to, "「Pesan Msg」\nPesan Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate906(msg.to, "Gagal mengganti Welcome Msg")
                              else:
                                  wait["welcome"] = spl
                                  sendTextTemplate906(msg.to, "「Welcome Msg」\nWelcome Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set ghost: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set ghost: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate906(msg.to, "Gagal mengganti Ghost Msg")
                              else:
                                  wait["flexghost"] = spl
                                  sendTextTemplate906(msg.to, "「Ghost Msg」\nWelcome Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  
                        elif 'Set autoleave: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set autoleave: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate906(msg.to, "Gagal mengganti Autoleave Msg")
                              else:
                                  wait["autoLave"] = spl
                                  sendTextTemplate906(msg.to, "「Autoleave Msg」\nAutoleave Msg diganti jadi :\n\n「{}」".format(str(spl)))
                                  
                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate906(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag"] = spl
                                  sendTextTemplate906(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set respon2: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon2: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate906(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag2"] = spl
                                  sendTextTemplate906(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif 'Set sider: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set sider: ','')
                              if spl in [""," ","\n",None]:
                                  sendTextTemplate906(msg.to, "Gagal mengganti Sider Msg")
                              else:
                                  wait["mention"] = spl
                                  sendTextTemplate906(msg.to, "「Sider Msg」\nSider Msg diganti jadi :\n\n「{}」".format(str(spl)))
                        elif text.lower() == "cek pesan":
                            if msg._from in admin:
                               sendTextTemplate906(msg.to, "「Pesan Msg」\nPesan Msg mu :\n\n「 " + str(wait["message"]) + " 」")
                        elif text.lower() == "cek welcome":
                            if msg._from in admin:
                               sendTextTemplate906(msg.to, "「Welcome Msg」\nWelcome Msg mu :\n\n「 " + str(wait["welcome"]) + " 」")
                        elif text.lower() == "cek leave":
                            if msg._from in admin:
                               sendTextTemplate906(msg.to, "「Autoleave Msg」\nAutoleave Msg mu :\n\n「 " + str(wait["autoleave"]) + " 」")
                        elif text.lower() == "cek respon":
                            if msg._from in admin:
                               sendTextTemplate906(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag"]) + " 」")
                        elif text.lower() == "cek respon2":
                            if msg._from in admin:
                               sendTextTemplate906(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag2"]) + " 」")
                        elif text.lower() == "cek sider":
                            if msg._from in admin:
                               sendTextTemplate901(msg.to, "「Sider Msg」\nSider Msg mu :\n\n「 " + str(wait["mention"]) + " 」")
#____________youtube,joox,fb,tok respon__________________#
                        elif "youtu.be" in msg.text.lower() or "https://youtube.com/shorts" in msg.text.lower():
                            if wait["ytube"] == True:
                               sep = msg.text.split(" ")
                               uid = msg.text.replace(sep[0]+" ","")
                               api = imjustgood("Woaini")
                               data = api.youtubedl(format(uid))
                               cl.sendVideoWithURL(to,data["result"]["videoUrl"])
                        elif cmd.startswith("jplay "):
                          if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                uid= msg.text.replace(sep[0] + " ","")
                                api = imjustgood("Woaini")
                                data = api.joox(format(uid))
                                r = "╭──[  Music joox  ]───"
                                r += "\n├• Title : {}".format(data["result"]["title"])
                                r += "\n├• Singer : {}".format(data["result"]["singer"])
                                r += "\n├• Duration : {}".format(data["result"]["duration"])
                                r += "\n├• Size : {}".format(data["result"]["size"])
                                r += "\n╰──[ Click audio dibawah ]──"
                                cl.sendReplyMessage(msg.id, to,(r))
                                cl.sendAudioWithURL(to,data["result"]["m4aUrl"])
                            except Exception as error:
                                cl.sendMessage(msg.to, str(error))
                                
                        elif "https://www.facebook.com" in msg.text.lower() or "https://www.facebook watch.com" in msg.text.lower():
                            if wait["facebook"] == True:
                               sep = msg.text.split(" ")
                               uid = msg.text.replace(sep[0]+" ","")
                               api = imjustgood("Woaini")
                               data = api.facebookdl(format(uid))
                               result = "╭──[ Notif Facebook ]───"
                               result += "\n├• ɑժѵҽղԵꪊƦe_club"
                               result += "\n╰──[ waiting download ]─"
                               cl.sendReplyMessage(msg.id, to,(result))
                               cl.sendVideoWithURL(to,data["result"]["videoUrl"])

                        elif "https://vt.tiktok.com" in text.lower():
                            if wait["tiktok"] == True:
                                try:
                                    url = re.search("(?P<url>https?://[^\s]+)", text).group("url")
                                    api     = imjustgood("Woaini")
                                    data    = api.tiktokdl(url)
                                    result = "╭──[ Tiktok Info  ]───"
                                    result += "\n├•Username : {}".format(data["result"]["username"])
                                    result += "\n├•Fullname : {}".format(data["result"]["fullname"])
                                    result += "\n├•Caption : {}".format(data["result"]["caption"])
                                    result += "\n├•Music : {}".format(data["result"]["music"])
                                    result += "\n├•Play : {}".format(data["result"]["play"])
                                    result += "\n├•Share : {}".format(data["result"]["share"])
                                    result += "\n├•Comment : {}".format(data["result"]["comment"])
                                    result += "\n╰──[ The ɑժѵҽղԵꪊƦꫀ ]──"
                                    #result += "\n\nPicture : {}".format(data["result"]["picture"])
                                    voto= "{}".format(data["result"]["thumbnail"])
                                    #result += "\n\nWatermark : {}".format(data["result"]["watermark"])
                                    video = "{}".format(data["result"]["no_watermark"])
                                    cl.sendReplyMessage(msg.id, to,(result))
                                    cl.sendFlexV(to,str(video),voto) #,voto
                                except Exception as error:
                                    cl.sendMessage(to,str(error))
                        elif cmd.startswith("ytmp3 "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              sep = msg.text.split(" ")
                              txt = msg.text.replace(sep[0] + " ","")
                              video = pafy.new(txt)
                              streams = video.streams
                              for s in streams:
                                  sendTextTemplate1010(to, "ʟᴏᴡᴅɪɴɢ...")
                                  cl.sendAudioWithURL(to,str(s.url))
                        elif cmd == ",aku" or text.lower() == ',gw':                            	
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                status = cl.getContact(sender)                   
                                cover = cl.getProfileCoverURL(sender)                             
                                data = {
                                       "type": "flex",
                                       "altText": "inilah aku",
                                       "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "kilo",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/nzNSsZn/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectRatio": "2:4",
                "aspectMode": "cover"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/zGHy4Bf/ezgif-com-gif-maker-2-1.png",
                    "size": "full",
                    "aspectRatio": "8:4",
                    "aspectMode": "cover",
                  },
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/zGHy4Bf/ezgif-com-gif-maker-2-1.png",
                    "size": "full",
                    "aspectRatio": "8:4",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "290px",
                "height": "250px",
                "offsetTop": "20px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/zGHy4Bf/ezgif-com-gif-maker-2-1.png",
                    "size": "full",
                    "aspectRatio": "8:4",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "290px",
                "height": "170px",
                "offsetTop": "274px",
                "offsetStart": "0px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                    "size": "full",
                    "aspectRatio": "2:4",
                    "aspectMode": "cover",
                    "offsetTop": "0px",
                    "offsetStart": "18px"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "image",
                        "animated": True,
                        "url": "https://i.ibb.co/zGHy4Bf/ezgif-com-gif-maker-2-1.png",
                        "size": "md",
                        "aspectRatio": "8:4",
                        "aspectMode": "cover"
                      }
                    ],
                    "position": "absolute",
                    "width": "200px",
                    "height": "200px",
                    "offsetTop": "380px",
                    "offsetStart": "50px"
                  }
                ],
                "position": "absolute",
                "width": "268px",
                "height": "438px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "🎥 Photo Artis LINE 😂 ",
                    "weight": "bold",
                    "color": "#000000",
                    "style": "italic"
                  }
                ],
                "position": "absolute",
                "width": "300px",
                "height": "40px",
                "offsetTop": "410px",
                "offsetStart": "80px"
              }
            ],
            "position": "absolute",
            "width": "290px",
            "height": "438px",
            "borderWidth": "2px",
            "borderColor": "#000000",
            "cornerRadius": "15px",
            "offsetTop": "3px",
            "offsetStart": "3px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#000000",
        "cornerRadius": "15px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                                cl.postTemplate(to, data)
                        elif cmd == "me" or text.lower() == 'my':                            	
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                status = cl.getContact(sender)                   
                                cover = cl.getProfileCoverURL(sender)                             
                                data = {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "kilo",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/0BhBrKQ/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(cl.getContact(msg._from).pictureStatus),
                "size": "full",
                "aspectRatio": "2:3",
                "aspectMode": "cover",
                "gravity": "top"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Name:{}".format(cl.getContact(sender).displayName),
                    "size": "md",
                    "color": "#000000",
                    "weight": "bold",
                    "style": "italic",
                    "offsetTop": "2px",
                    "offsetStart": "5px"
                  }
                ],
                "position": "absolute",
                "width": "285px",
                "height": "30px",
                "backgroundColor": "#bbcc00",
                "offsetTop": "400px",
                "borderWidth": "1px",
                "borderColor": "#000000"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "animated": True,
                    "url": "https://i.ibb.co/2jvwXdf/ezgif-com-gif-maker-5.png",
                    "gravity": "top",
                    "size": "full",
                    "aspectRatio": "2:4",
                    "aspectMode": "cover",
                  }
                ],
                "position": "absolute",
                "width": "285px",
                "height": "429px",
                "borderWidth": "0px",
                "borderColor": "#03333acc"
              }
            ],
            "position": "absolute",
            "width": "285px",
            "height": "433px",
            "borderWidth": "2px",
            "borderColor": "#000000",
            "cornerRadius": "10px",
            "offsetTop": "5px",
            "offsetStart": "5px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "2px",
        "borderColor": "#000000",
        "cornerRadius": "15px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
                                cl.postFlex(to, data)
                        elif cmd == ".media" or text.lower() == '!gw':                            	
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                status = cl.getContact(sender)                   
                                cover = cl.getProfileCoverURL(sender)                             
                                data = {
                                       "type": "flex",
                                       "altText": "The Adventure",
                                       "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/nzNSsZn/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/ZWNYMbJ/images.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "https://youtu.be/bk1Zw-XGunc"
                    }
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "60px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "offsetTop": "1px",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/30yCKNg/images-1.png",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "https://youtu.be/8pU6mshW77c"
                    }
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "70px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "offsetTop": "1px",
                "offsetStart": "75px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/vmyms30/images.jpg",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "https://youtu.be/t2ZpPb9q6JY"
                    }
                  }
                ],
                "position": "absolute",
                "width": "70px",
                "height": "70px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "offsetTop": "65px",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/rcR4R3d/images-1.jpg",
                    "size": "full",
                    "aspectRatio": "2:2",
                    "aspectMode": "cover",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "https://youtu.be/fsBC_A_037c"
                    }
                  }
                ],
                "position": "absolute",
                "width": "60px",
                "height": "60px",
                "borderWidth": "1px",
                "borderColor": "#ffffff",
                "cornerRadius": "4px",
                "offsetTop": "75px",
                "offsetStart": "85px"
              }
            ],
            "position": "absolute",
            "width": "150px",
            "height": "144px",
            "borderWidth": "2px",
            "borderColor": "#000000",
            "cornerRadius": "5px",
            "offsetTop": "5px",
            "offsetStart": "5px",
            "backgroundColor": "#000000"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "Adventure™",
                "size": "xxs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic"
              }
            ],
            "position": "absolute",
            "width": "200px",
            "height": "20px",
            "offsetTop": "140px",
            "offsetStart": "100px"
          }
        ],
        "paddingAll": "0px",
        "height": "153px"
      }
    }
  ]
}
}
                                cl.postTemplate(to, data)
                        elif cmd == "!order" or text.lower() == 'promo':                            	
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                status = cl.getContact(sender)                   
                                cover = cl.getProfileCoverURL(sender)                             
                                data = {
                                       "type": "flex",
                                       "altText": "ɴɢᴇʟᴀᴘᴀᴋ sᴇᴋ ʟᴜʀ",
                                       "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "mega",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "animated": True,
            "url": "https://i.ibb.co/xH92qNk/ezgif-com-gif-maker.png",
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "===============•ɴɢᴇʟᴀᴘᴀᴋ ʟᴜʀ•================",
                "size": "xs",
                "color": "#00ff00",
                "offsetTop": "2px",
                "offsetStart": "5px",
                "weight": "bold",
                "style": "italic"
              },
              {
                "type": "text",
                "text": " 🏷️ • ʟᴏɢɪɴ sʙ ᴏɴʟʏ",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "20px"
              },
              {
                "type": "text",
                "text": " 🏷️ • ʟᴏɢɪɴ sʙ ᴛᴇᴍᴘʟᴀᴛᴇ ғᴜʟʟ",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "20px"
              },
              {
                "type": "text",
                "text": " 🏷️ • ʟᴏɢɪɴ sʙ + ᴀᴊs",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "20px"
              },
              {
                "type": "text",
                "text": " 🏷️ • ᴘʀᴏᴛᴇᴄᴛ ʀᴏᴏᴍ ᴄʜᴀᴛ/sᴍᴜʟᴇ ",
                "size": "xs",
                "weight": "bold",
                "color": "#ffffff",
                "style": "italic",
                "offsetTop": "20px"
              },
              {
                "type": "text",
                "text": "==========================================================================",
                "size": "sm",
                "color": "#00ff00",
                "weight": "bold",
                "style": "italic",
                "wrap": True,
                "offsetTop": "40px"
              },
              {
                "type": "text",
                "text": "============ᴍᴇʟᴀʏᴀɴɪ ᴊᴜɢᴀ===========",
                "color": "#00ff00",
                "size": "xs",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "40px",
                "offsetStart": "20px"
              },
              {
                "type": "text",
                "text": " 🏷️ • ᴘᴇᴍʙᴇᴋᴜᴀɴ ᴘᴇʀᴍᴀɴᴇɴ ᴀᴋᴜɴ sᴍᴜʟᴇ",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "40px"
              },
              {
                "type": "text",
                "text": " 🏷️ • ᴘᴀsᴀɴɢ sᴏɴɢʙᴏᴏᴋ ᴅɪ sᴍᴜʟᴇ ",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "40px"
              },
              {
                "type": "text",
                "text": " 🏷️ • ᴘᴀsᴀɴɢ ᴠɪᴘ sᴍᴜʟᴇ ᴅᴀɴ ᴇᴅɪᴛ ʟᴏɢᴏ ɢs",
                "size": "xs",
                "color": "#ffffff",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "40px"
              }
            ],
            "position": "absolute",
            "width": "300px",
            "height": "450px",
            "backgroundColor": "#01102acc"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "🔸sɪʟᴀʜᴋᴀɴ ʜᴜʙᴜɴɢɪ 📞: +6285707063716 # ʜᴀʀɢᴀ ᴍᴜʀᴍᴇʀ ʙᴇʀsᴀʜᴀʙᴀᴛ🔸",
                "size": "sm",
                "color": "#ffffff",
                "weight": "bold",
                "decoration": "line-through",
                "wrap": True,
              },
              {
                "type": "text",
                "text": "Adventure™",
                "size": "lg",
                "color": "#00ff00",
                "weight": "bold",
                "style": "italic",
                "offsetTop": "70px",
                "offsetStart": "70px"
              }
            ],
            "position": "absolute",
            "width": "300px",
            "height": "200px",
            "offsetTop": "300px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "3px",
        "borderColor": "#000000",
        "cornerRadius": "15px"
      },
      "action": {
        "type": "uri",
        "label": "action",
        "uri": "http://wa.me/+6285707063716",
      }
    }
  ]
}
}
                                cl.postTemplate(to, data)
                        elif cmd == "mempict":
                              if msg._from in admin:
                                  kontak = cl.getGroup(to)
                                  group = kontak.members
                                  picall = []
                                  for ids in group:
                                    if len(picall) >= 400:
                                      pass
                                    else:
                                      picall.append({
                                        "imageUrl": "https://os.line.naver.jp/os/p/{}".format(ids.mid),
                                        "action": {
                                          "type": "uri",
                                          "uri": "http://wa.me/+6285707063716"
                                          }
                                        }
                                      )
                                  k = len(picall)//10
                                  for aa in range(k+1):
                                    data = {
                                      "type": "template",
                                      "altText": "{} membagikan janda".format(cl.getProfile().displayName),
                                      "template": {
                                        "type": "image_carousel",
                                        "columns": picall[aa*10 : (aa+1)*10]
                                      }
                                    }
                                    cl.postTemplate(to, data)
#===========JOIN TICKET============#
                        elif "/ti/g/" in msg.text.lower():
                          if wait["selfbot"] == True:
                            if msg._from in admin or msg._from in owner:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = cl.findGroupByTicket(ticket_id)
                                     cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     sendTextTemplate906(msg.to, "Masuk : %s" % str(group.name))
                                   #  group1 = ka.findGroupByTicket(ticket_id)
#===========add img============#                                                                                
                        elif text.lower() == "cek":
                            if msg._from in admin:
                               try:cl.inviteIntoGroup(to, ["ucebba675be5aa9e5733bfb2084aea5a7"]);has = "OK"
                               except:has = "NOT"
                               try:cl.kickoutFromGroup(to, ["ucebba675be5aa9e5733bfb2084aea5a7"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "☑️ɴᴏʀᴍᴀʟ"
                               else:sil = "❎ᴍɪᴍɪᴛ ʙᴏs"
                               if has1 == "OK":sil1 = "☑️ɴᴏʀᴍᴀʟ"
                               else:sil1 = "❎ᴍɪᴍɪᴛ ʙᴏs"
                               sendTextTemplate006(to, "🔴ᴘᴀɴᴄᴀʟ: {} \n🔴ᴋᴇᴍᴘɪᴛ: {}".format(sil1,sil))                                                                                
                        elif text.lower() == "cekmy":
                            if msg._from in admin:
                               try:cl.inviteIntoGroup(to, ["ucebba675be5aa9e5733bfb2084aea5a7"]);has = "OK"
                               except:has = "NOT"
                               try:cl.kickoutFromGroup(to, ["ucebba675be5aa9e5733bfb2084aea5a7"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "☑️ɴᴏʀᴍᴀʟ"
                               else:sil = "❎ᴍɪᴍɪᴛ ʙᴏs"
                               if has1 == "OK":sil1 = "☑️ɴᴏʀᴍᴀʟ"
                               else:sil1 = "❎ᴍɪᴍɪᴛ ʙᴏs"
                               cl.sendReplyMessage(msg.id, to, "👨‍🦰 ᴘᴀɴᴄᴀʟ : {} \n👨‍🦰 ᴋᴇᴍᴘɪᴛ : {}".format(sil1,sil))
#===============HIBURAN============================#
                        elif cmd.startswith("addmp3 "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in audios:
                                    settings["Addaudio"]["status"] = True
                                    settings["Addaudio"]["name"] = str(name.lower())
                                    audios[str(name.lower())] = ""
                                    f = codecs.open("audio.json","w","utf-8")
                                    json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendTextTemplate1(msg.to,"Silahkan kirim mp3 nya...") 
                                else:
                                    sendTextTemplate1(msg.to, "Mp3 itu sudah dalam list") 
                                
                        elif cmd.startswith("dellmp3 "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name in audios:
                                    cl.deleteFile(audios[str(name.lower())])
                                    del audios[str(name.lower())]
                                    f = codecs.open("audio.json","w","utf-8")
                                    json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendTextTemplate1(msg.to, "Done hapus mp3 {}".format( str(name.lower())))
                                else:
                                    sendTextTemplate1(msg.to, "Mp3 itu tidak ada dalam list") 
                                 
                        elif cmd == "listmp3":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╔═══❲ My Music ❳════\n"
                                for audio in audios:
                                    ret_ += "┣[]◇  " + audio.title() + "\n"
                                ret_ += "╚═══❲ {} Record  ❳════".format(str(len(audios)))
                                sendTextTemplate2(to, ret_)

                        elif cmd.startswith("addsticker "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in stickers:
                                    settings["Addsticker"]["status"] = True
                                    settings["Addsticker"]["name"] = str(name.lower())
                                    stickers[str(name.lower())] = ""
                                    f = codecs.open("Sticker.json","w","utf-8")
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendTextTemplate1(to, "Silahkan kirim stickernya...") 
                                else:
                                    sendTextTemplate1(to, "Sticker itu sudah dalam list") 
                                
                        elif cmd.startswith("dellsticker "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name in stickers:
                                    del stickers[str(name.lower())]
                                    f = codecs.open("sticker.json","w","utf-8")
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendTextTemplate1(to, "Berhasil menghapus sticker {}".format( str(name.lower())))
                                else:
                                    sendTextTemplate1(to, "Sticker ada di list") 
                                                   
                        elif cmd == "liststicker":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╔═══❲ My Sticker ❳════\n"
                                for sticker in stickers:
                                    ret_ += "┣[]◇  " + sticker.title() + "\n"
                                ret_ += "╚═══❲  {} Stickers  ❳════".format(str(len(stickers)))
                                sendTextTemplate2(to, ret_)

                        elif cmd.startswith("addimg "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in images:
                                    settings["Addimage"]["status"] = True
                                    settings["Addimage"]["name"] = str(name.lower())
                                    images[str(name.lower())] = ""
                                    f = codecs.open("image.json","w","utf-8")
                                    json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendTextTemplate1(to, "Silahkan kirim fotonya")
                                else:
                                    sendTextTemplate1(to, "Foto Udah dalam list")

                        elif cmd.startswith("dellimg "):
                            if msg._from in admin:
                               sep = text.split(" ")
                               name = text.replace(sep[0] + " ","")
                               name = name.lower()
                               if name in images:
                                   cl.deleteFile(images[str(name.lower())])
                                   del images[str(name.lower())]
                                   f = codecs.open("image.json","w","utf-8")
                                   json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                   sendTextTemplate1(to, "Berhasil menghapus {}".format( str(name.lower())))
                               else:
                                   sendTextTemplate1(to, "Foto ada dalam list")

                        elif cmd == "listimage":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╭───「 Daftar Image 」\n"
                                for audio in audios:
                                    no += 1
                                    ret_ += str("├≽") + " " + audio.title() + "\n"
                                ret_ += "╰───「 Total {} Image 」".format(str(len(audios)))
                                sendTextTemplate2(to, ret_)
#==============add video==========================================================================
                        elif cmd.startswith("addvideo"):
                            if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in images:
                                    settings["Addvideo"]["status"] = True
                                    settings["Addvideo"]["name"] = str(name.lower())
                                    images[str(name.lower())] = ""
                                    f = codecs.open("video.json","w","utf-8")
                                    json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendTextTemplate1(to, "Silahkan kirim video nya...")
                                else:
                                    sendTextTemplate1(to, "video sudah ada")
                        elif cmd.startswith("dellvideo "):
                            if msg._from in admin:
                               sep = text.split(" ")
                               name = text.replace(sep[0] + " ","")
                               name = name.lower()
                               if name in images:
                                   cl.deleteFile(images[str(name.lower())])
                                   del images[str(name.lower())]
                                   f = codecs.open("video.json","w","utf-8")
                                   json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                   sendTextTemplate1(to, "Berhasil menghapus {}".format( str(name.lower())))
                               else:
                                   sendTextTemplate1(to, "video tidak ada")

                        elif cmd == "listvideo":
                            if msg._from in admin:
                                no = 0
                                ret_ = "╭───「 Daftar Video 」\n"
                                for audio in audios:
                                    no += 1
                                    ret_ += str("├≽") + " " + audio.title() + "\n"
                                ret_ += "╰───「 Total {} Video 」".format(str(len(audios)))
                                sendTextTemplate2(to, ret_)
    except Exception as error:
        print (error)


while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                bot(op)
                # Don't remove this line, if you wan't get error soon!
                oepoll.setRevision(op.revision)
    except Exception as e:
    	logError(e)                      
